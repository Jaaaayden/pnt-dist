/* The Line explorer's graphs (SPEC.md, "Line explorer graphs"): fold equity by
 * bet size, stab folds by flop texture, river bluffs by bet size and c-bets by
 * flop texture, drawn as hand-written SVG over GET /explore/graphs.
 *
 * No chart library and no remote script: the pages also ship inside the
 * extension, which may run neither. The palette is loading.js's; the size ramp
 * and the bluff orange are the explorer's (blue to orange: red and green are
 * money's). postflop.html mounts it and calls load() on every spot change.
 *
 * window.pntGraphs = { mount(root, { onPick }), load({ player, filter, games }), lib }
 * `lib` is the pure part, which pages.test.mjs runs under node.
 */
(() => {
  "use strict";
  const SVG = "http://www.w3.org/2000/svg";
  const SIZES = ["T", "S", "M", "L", "O"];
  const SIZE_WORD = { T: "under ⅕ pot", S: "⅕–½ pot", M: "½–¾ pot", L: "¾ pot–pot", O: "overbet" };
  const STREETS = ["flop", "turn", "river"];
  const STORE = "pnt.explorer.graphs";

  // ---- the pure part ---------------------------------------------------------
  // The x axis of a size graph, in pots: past the largest point, on a quarter,
  // from 1.25 (pot-sized bets in view) to 3 (a jam into a limp stays a dot at
  // the edge, not a squashed axis).
  function xMax(xs) {
    const top = Math.max(0, ...xs.filter(Number.isFinite));
    return Math.min(3, Math.max(1.25, Math.ceil(top * 1.1 * 4) / 4));
  }
  // Ticks for that axis: the button sizes, then whole multiples.
  const TICKS = [[0, "0"], [0.25, "¼"], [0.5, "½"], [0.75, "¾"], [1, "pot"], [1.5, "1.5×"], [2, "2×"], [3, "3×"]];
  const sizeTicks = (max) => TICKS.filter(([v]) => v <= max + 1e-9);
  // A break-even curve as [x, y] points in pots and fractions, `steps` apart.
  function curvePoints(fn, max, steps = 48) {
    const out = [];
    for (let i = 0; i <= steps; i++) { const x = (max * i) / steps; out.push([x, fn(x)]); }
    return out;
  }
  const bluffBreakEven = (s) => s / (1 + s);
  const catcherBreakEven = (s) => s / (1 + 2 * s);
  // The spot and one point's term, ANDed: `,` binds loosest, so the spot's own
  // `|` stays inside it.
  const spotAnd = (spot, term) => [spot, term].map(t => String(t ?? "").trim()).filter(Boolean).join(",");
  const capital = (t) => (t ? t[0].toUpperCase() + t.slice(1) : t);
  // Where an n label goes: above the interval, or below it when the top is near
  // the plot's top edge or `below` asks (y in px, smaller is higher).
  const labelY = (top, bottom, plotTop, below = false, gap = 6) =>
    (below || top - gap - 10 < plotTop ? bottom + gap + 9 : top - gap);
  const lib = { xMax, sizeTicks, curvePoints, bluffBreakEven, catcherBreakEven, spotAnd, capital, labelY };

  if (typeof document === "undefined" || !document.createElement) { window.pntGraphs = { lib }; return; }

  // ---- the look ----------------------------------------------------------------
  const CSS = `
  .pnt-graphs { position: relative; margin-top: 14px; padding: 6px 10px 12px; overflow: visible;
    background: var(--surface); border: 1px solid var(--ring); border-radius: 10px;
    --g1: #86b6ef; --g2: #5598e7; --g3: #2a78d6; --g4: #1c5cab; --g5: #0d366b; --g-bluff: #c27005; --g-wash: rgba(42,120,214,.09); }
  @media (prefers-color-scheme: dark) {
    :root:not([data-theme="light"]) .pnt-graphs { --g1: #184f95; --g2: #256abf; --g3: #3987e5; --g4: #6da7ec; --g5: #b7d3f6; --g-wash: rgba(57,135,229,.10); }
  }
  :root[data-theme="dark"] .pnt-graphs { --g1: #184f95; --g2: #256abf; --g3: #3987e5; --g4: #6da7ec; --g5: #b7d3f6; --g-wash: rgba(57,135,229,.10); }
  .pnt-graphs .g-head { display: flex; flex-wrap: wrap; gap: 4px 12px; align-items: center; padding: 4px 2px 6px; font-size: 13px; color: var(--ink-2); }
  .pnt-graphs .g-toggle { border: 0; background: none; padding: 0; font: 600 14px system-ui, sans-serif; color: var(--ink); cursor: pointer; }
  .pnt-graphs .g-toggle::before { content: "▾ "; color: var(--muted); }
  .pnt-graphs .g-toggle[aria-expanded=false]::before { content: "▸ "; }
  .pnt-graphs .g-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 420px), 1fr)); gap: 12px; align-items: start; }
  .pnt-graphs .g-grid.loading { opacity: .45; transition: opacity .15s; }
  .pnt-graphs .g-card { border: 1px solid var(--ring); border-radius: 8px; padding: 8px 10px 6px; min-width: 0; }
  .pnt-graphs .g-card.wide { grid-column: 1 / -1; }
  .pnt-graphs .g-title { display: flex; flex-wrap: wrap; gap: 4px 10px; align-items: baseline; margin: 0; font-size: 13.5px; font-weight: 600; color: var(--ink); }
  .pnt-graphs .g-title .seg button { font-size: 12px; padding: 2px 8px; }
  .pnt-graphs .g-cap { margin: 2px 0 4px; font-size: 12px; color: var(--ink-2); }
  .pnt-graphs .g-take { margin: 2px 0 2px; font-size: 12.5px; color: var(--ink); }
  .pnt-graphs .g-take.none { color: var(--muted); }
  .pnt-graphs .g-panels { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 320px), 1fr)); gap: 4px 18px; }
  .pnt-graphs .g-sub { margin: 6px 0 0; font-size: 12.5px; font-weight: 600; color: var(--ink-2); }
  .pnt-graphs svg { display: block; width: 100%; overflow: visible; font: 11px system-ui, -apple-system, "Segoe UI", sans-serif; }
  .pnt-graphs svg text { fill: var(--muted); }
  .pnt-graphs svg text.ink { fill: var(--ink-2); }
  .pnt-graphs svg .grid { stroke: var(--grid); stroke-width: 1; }
  .pnt-graphs svg .axis { stroke: var(--axis); stroke-width: 1; }
  .pnt-graphs svg .be { stroke: var(--ink-2); stroke-width: 1.5; fill: none; stroke-dasharray: 4 3; }
  .pnt-graphs svg .wash { fill: var(--g-wash); }
  .pnt-graphs svg .hit { fill: transparent; cursor: pointer; outline: none; }
  .pnt-graphs svg .pt.thin { opacity: .38; }
  .pnt-graphs svg .pt:hover .dot, .pnt-graphs svg .pt:focus-within .dot { stroke: var(--ink); }
  .pnt-graphs svg .seg-r:hover, .pnt-graphs svg .pt:focus-within .seg-r { opacity: .8; }
  .pnt-graphs .g-key { display: flex; flex-wrap: wrap; gap: 2px 10px; font-size: 11.5px; color: var(--ink-2); margin: 2px 0; }
  .pnt-graphs .g-key i { display: inline-block; width: 9px; height: 9px; border-radius: 2px; margin-right: 4px; vertical-align: -1px; }
  .pnt-graphs .g-key i.line { height: 0; width: 14px; border-top: 1.5px dashed var(--ink-2); border-radius: 0; vertical-align: 3px; }
  .pnt-graphs .g-key i.wash { background: var(--g-wash); border: 1px solid var(--ring); }
  .pnt-graphs details { font-size: 12px; color: var(--ink-2); margin-top: 2px; }
  .pnt-graphs details summary { cursor: pointer; color: var(--muted); }
  .pnt-graphs details table { margin-top: 4px; }
  .pnt-graphs details td, .pnt-graphs details th { padding: 3px 6px; font-size: 12px; position: static; }
  .pnt-graphs .hidden { display: none !important; }
  .pnt-graphs .g-tip { position: absolute; z-index: 30; pointer-events: none; max-width: 280px; padding: 6px 9px; border-radius: 7px;
    background: var(--surface); border: 1px solid var(--ring); box-shadow: 0 6px 20px rgba(0,0,0,.18); font-size: 12px; color: var(--ink-2); }
  .pnt-graphs .g-tip b { display: block; color: var(--ink); font-size: 13px; font-weight: 600; }
  .pnt-graphs .g-tip .k { display: inline-block; width: 12px; height: 0; border-top: 2px solid; margin-right: 5px; vertical-align: 3px; }
  `;

  const el = (tag, text, cls) => { const e = document.createElement(tag); if (text != null) e.textContent = text; if (cls) e.className = cls; return e; };
  function s(tag, attrs = {}, text) {
    const e = document.createElementNS(SVG, tag);
    for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, v);
    if (text != null) e.textContent = text;
    return e;
  }
  const pct = (v, dp = 0) => (v == null ? "–" : `${Number(v).toFixed(dp)}%`);
  const signed = (v) => (v == null ? "–" : `${v > 0 ? "+" : ""}${v.toFixed(1)} pts`);
  const nText = (n) => Number(n).toLocaleString();
  const store = () => { try { return JSON.parse(localStorage.getItem(STORE) || "{}"); } catch { return {}; } };
  const keep = (patch) => { try { localStorage.setItem(STORE, JSON.stringify({ ...store(), ...patch })); } catch { /* this visit only */ } };

  let root, grid, tip, onPick, data = null, spot = { player: "", filter: "", games: "play" };
  let street = STREETS.includes(store().street) ? store().street : "flop";
  let open = store().open !== false;

  // ---- the hover layer -----------------------------------------------------------
  // One tooltip for the panel; a point's lines are [value, then labels].
  function showTip(target, lines, ev) {
    tip.replaceChildren();
    const [head, ...rest] = lines;
    tip.append(el("b", head));
    for (const l of rest) tip.append(el("div", l));
    tip.classList.remove("hidden");
    const box = root.getBoundingClientRect();
    const at = ev && ev.clientX != null ? { x: ev.clientX, y: ev.clientY } : (() => {
      const r = target.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top };
    })();
    const w = tip.offsetWidth, h = tip.offsetHeight;
    let x = at.x - box.left + 14, y = at.y - box.top - h - 10;
    if (x + w > box.width - 4) x = at.x - box.left - w - 14;
    if (y < 0) y = at.y - box.top + 16;
    tip.style.left = `${Math.max(4, x)}px`; tip.style.top = `${y}px`;
  }
  const hideTip = () => tip.classList.add("hidden");
  // A point the reader can hover, focus and click: `g` holds its marks, `hit`
  // the transparent target (24px or more), `point` its label and filter.
  function interactive(g, hit, point) {
    hit.setAttribute("class", "hit");
    hit.setAttribute("tabindex", "0");
    hit.setAttribute("role", "button");
    hit.setAttribute("aria-label", point.tip.join(", "));
    hit.addEventListener("pointermove", (e) => showTip(hit, point.tip, e));
    hit.addEventListener("pointerleave", hideTip);
    hit.addEventListener("focus", () => showTip(hit, point.tip));
    hit.addEventListener("blur", hideTip);
    const pick = () => onPick?.({ label: point.label, filter: spotAnd(spot.filter, point.filter) });
    hit.addEventListener("click", pick);
    hit.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } });
    g.appendChild(hit);
  }

  // ---- size scatter: fold or bluff % against a pot fraction and its break-even ----
  // rows: [{x, y, lo, hi, n, judged, letter, tip, label, filter}], y and the
  // interval in %; curve: pot fraction -> fraction.
  function scatter(width, { rows, curve, color, wash, yName }) {
    const H = 214, m = { l: 34, r: 14, t: 12, b: 26 };
    const W = Math.max(260, width);
    const max = xMax(rows.map(r => r.x));
    const X = (v) => m.l + (Math.min(v, max) / max) * (W - m.l - m.r);
    const Y = (p) => m.t + (1 - p / 100) * (H - m.t - m.b);
    const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, height: H, role: "img", "aria-label": yName });
    for (const p of [0, 25, 50, 75, 100]) {
      svg.append(s("line", { x1: m.l, x2: W - m.r, y1: Y(p), y2: Y(p), class: p ? "grid" : "axis" }));
      svg.append(s("text", { x: m.l - 6, y: Y(p) + 3.5, "text-anchor": "end" }, `${p}%`));
    }
    for (const [v, t] of sizeTicks(max)) {
      svg.append(s("line", { x1: X(v), x2: X(v), y1: H - m.b, y2: H - m.b + 4, class: "axis" }));
      svg.append(s("text", { x: X(v), y: H - m.b + 15, "text-anchor": "middle" }, t));
    }
    const pts = curvePoints(curve, max);
    const line = pts.map(([x, y], i) => `${i ? "L" : "M"}${X(x).toFixed(1)},${Y(100 * y).toFixed(1)}`).join("");
    svg.append(s("path", { d: `${line}L${X(max)},${Y(100)}L${X(0)},${Y(100)}Z`, class: "wash" }));
    svg.append(s("text", { x: m.l + 6, y: m.t + 11, class: "ink" }, wash));
    svg.append(s("path", { d: line, class: "be" }));
    // A label within a label's width of the last one goes on the other side.
    let lastX = -Infinity, lastBelow = true;
    for (const r of [...rows].sort((a, b) => a.x - b.x)) {
      if (r.y == null || !Number.isFinite(r.x)) continue;
      const g = s("g", { class: "pt" + (r.judged ? "" : " thin") });
      const cx = X(r.x), cy = Y(r.y);
      if (r.lo != null) g.append(s("line", { x1: cx, x2: cx, y1: Y(r.hi), y2: Y(r.lo), stroke: color, "stroke-width": 1.5, "stroke-linecap": "round" }));
      g.append(s("circle", { cx, cy, r: 4.5, fill: color, stroke: "var(--surface)", "stroke-width": 2, class: "dot" }));
      const top = Y(r.hi ?? r.y), bottom = Y(r.lo ?? r.y);
      const below = X(r.x) - lastX < 46 && !lastBelow;
      const ly = labelY(top, bottom, m.t, below);
      lastX = X(r.x); lastBelow = ly > cy;
      g.append(s("text", { x: cx, y: ly, "text-anchor": "middle", class: "ink" }, `${r.letter} ${nText(r.n)}`));
      interactive(g, s("rect", { x: cx - 13, y: Math.min(top, cy - 13), width: 26, height: Math.max(26, bottom - top) }), r);
      svg.append(g);
    }
    return svg;
  }

  // ---- forest: one row per group, fold % with its interval and its own break-even ----
  // rows: [{label, indent, y, lo, hi, be, n, judged, tip, filter}], % throughout.
  function forest(width, rows, { color }) {
    const RH = 22, m = { l: 96, r: 52, t: 8, b: 24 };
    const W = Math.max(280, width), H = m.t + rows.length * RH + m.b;
    const X = (p) => m.l + (p / 100) * (W - m.l - m.r);
    const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, height: H, role: "img", "aria-label": "fold % by flop texture" });
    for (const p of [0, 25, 50, 75, 100]) {
      svg.append(s("line", { x1: X(p), x2: X(p), y1: m.t, y2: H - m.b, class: p ? "grid" : "axis" }));
      svg.append(s("text", { x: X(p), y: H - m.b + 15, "text-anchor": "middle" }, `${p}%`));
    }
    svg.append(s("text", { x: W - 2, y: m.t + 2, "text-anchor": "end", dy: "-0.2em" }, "n"));
    rows.forEach((r, i) => {
      const cy = m.t + i * RH + RH / 2;
      const g = s("g", { class: "pt" + (r.judged ? "" : " thin") });
      svg.append(s("text", { x: 4 + 12 * (r.indent || 0), y: cy + 4, class: r.indent ? "" : "ink", "font-weight": r.indent ? null : 600 }, r.label));
      if (r.be != null) {
        g.append(s("rect", { x: X(r.be), y: cy - 7, width: X(100) - X(r.be), height: 14, class: "wash", rx: 2 }));
        g.append(s("line", { x1: X(r.be), x2: X(r.be), y1: cy - 8, y2: cy + 8, stroke: "var(--ink-2)", "stroke-width": 2 }));
      }
      if (r.y != null) {
        if (r.lo != null) g.append(s("line", { x1: X(r.lo), x2: X(r.hi), y1: cy, y2: cy, stroke: color, "stroke-width": 1.5, "stroke-linecap": "round" }));
        g.append(s("circle", { cx: X(r.y), cy, r: r.indent ? 3.5 : 4.5, fill: color, stroke: "var(--surface)", "stroke-width": 2, class: "dot" }));
      }
      g.append(s("text", { x: W - 2, y: cy + 4, "text-anchor": "end", class: "ink" }, nText(r.n)));
      interactive(g, s("rect", { x: 0, y: cy - RH / 2, width: W, height: RH }), r);
      svg.append(g);
    });
    return svg;
  }

  // ---- stacked bars: a share of chances per row, split by size ----------------------
  // rows: [{label, total %, parts: [{letter, share, n, tip, filter}], n, judged, tip, filter}]
  function bars(width, rows) {
    const RH = 26, BH = 14, m = { l: 96, r: 86, t: 6, b: 22 };
    const W = Math.max(280, width), H = m.t + rows.length * RH + m.b;
    const X = (p) => m.l + (p / 100) * (W - m.l - m.r);
    const svg = s("svg", { viewBox: `0 0 ${W} ${H}`, height: H, role: "img", "aria-label": "c-bet % by flop texture and size" });
    for (const p of [0, 25, 50, 75, 100]) {
      svg.append(s("line", { x1: X(p), x2: X(p), y1: m.t, y2: H - m.b, class: p ? "grid" : "axis" }));
      svg.append(s("text", { x: X(p), y: H - m.b + 15, "text-anchor": "middle" }, `${p}%`));
    }
    rows.forEach((r, i) => {
      const cy = m.t + i * RH + RH / 2;
      svg.append(s("text", { x: 4, y: cy + 4, class: "ink", "font-weight": 600 }, r.label));
      const g = s("g", { class: "pt" + (r.judged ? "" : " thin") });
      let at = 0;
      const parts = r.parts.filter(p => p.share > 0);
      parts.forEach((p, j) => {
        const x0 = X(at), x1 = X(at + p.share);
        at += p.share;
        // A 2px surface gap between touching segments; the last one's end rounds.
        const w = Math.max(0.5, x1 - x0 - (j < parts.length - 1 ? 2 : 0));
        const seg = s("g", { class: "pt" });
        seg.append(s("rect", { x: x0, y: cy - BH / 2, width: w, height: BH, fill: `var(--g${SIZES.indexOf(p.letter) + 1})`,
          rx: j === parts.length - 1 ? 3 : 0, class: "seg-r" }));
        interactive(seg, s("rect", { x: x0, y: cy - RH / 2, width: Math.max(6, x1 - x0), height: RH }), p);
        g.append(seg);
      });
      svg.append(g);
      const lab = s("text", { x: X(Math.max(at, 0)) + 6, y: cy + 4, class: "ink" }, pct(r.total));
      svg.append(lab);
      const row = s("g", { class: "pt" });
      row.append(s("text", { x: W - 2, y: cy + 4, "text-anchor": "end" }, `of ${nText(r.n)}`));
      interactive(row, s("rect", { x: 0, y: cy - RH / 2, width: m.l, height: RH }), r);
      interactive(row, s("rect", { x: W - m.r + 30, y: cy - RH / 2, width: m.r - 30, height: RH }), r);
      svg.append(row);
    });
    return svg;
  }

  // ---- a table twin, for reading every number without hovering ------------------------
  function numbers(head, rows) {
    const d = el("details");
    d.append(el("summary", "numbers"));
    const t = el("table"), tr = el("tr");
    for (const h of head) tr.append(el("th", h));
    const thead = el("thead"); thead.append(tr); t.append(thead);
    const tb = el("tbody");
    for (const r of rows) { const row = el("tr"); for (const c of r) row.append(el("td", c)); tb.append(row); }
    t.append(tb); d.append(t);
    return d;
  }
  const take = (text, small) => el("p", text ? capital(text) : small, "g-take" + (text ? "" : " none"));
  function card(title, cap, wide) {
    const c = el("div", null, "g-card" + (wide ? " wide" : ""));
    const h = el("h3", null, "g-title"); h.append(el("span", title));
    c.append(h, el("p", cap, "g-cap"));
    return c;
  }
  // A point's hands: its filter lists every bet, the ones you answered too, which
  // what a bet got leaves out (`listed` past `n`).
  const clickWord = (r) => (r.listed != null && r.listed > r.n ? `click: all ${nText(r.listed)}, those you answered too` : "click: these hands");
  const smallNote = (min) => `small sample: under ${min} per point, the dimmed ones`;
  const widthOf = (node) => Math.max(260, Math.floor(node.getBoundingClientRect().width) - 2);

  // ---- graph 1: fold equity by bet size ----------------------------------------------
  function foldCard(d) {
    const c = card("Fold equity by bet size", "Above the dashed line a pure bluff profits, e.g. a ½-pot bet needs 33% folds.", true);
    const seg = el("span", null, "seg");
    seg.setAttribute("role", "group"); seg.setAttribute("aria-label", "Street");
    for (const st of STREETS) {
      const b = el("button", st[0].toUpperCase() + st.slice(1));
      b.type = "button"; b.setAttribute("aria-pressed", st === street);
      b.addEventListener("click", () => { street = st; keep({ street }); paint(); });
      seg.append(b);
    }
    c.querySelector(".g-title").append(seg);
    const g = d.fold_by_size[street];
    const panels = el("div", null, "g-panels");
    const sides = [
      ["bets", "Their bets: everyone folded", "bets_takeaway", "bet", "took the pot"],
      ["faced", "Facing a bet: they folded", "faced_takeaway", "faced", "folded"],
    ];
    const holders = [];
    for (const [key, sub, tk, kind, verb] of sides) {
      const p = el("div");
      p.append(el("p", sub, "g-sub"), take(g[tk], key === "faced" ? "heads-up takeaway needs 10+ decisions a size" : "needs 10+ bets a size"));
      const rows = g[key].map(r => ({
        x: r.median_size, y: r.fold, lo: r.ci?.[0], hi: r.ci?.[1], n: r.n, judged: r.judged, letter: r.letter,
        label: `${street} ${kind} ${r.letter}`, filter: r.filter,
        tip: [`${pct(r.fold, 1)} ${verb}`, `${r.letter} ${SIZE_WORD[r.letter]} · median ${Math.round(100 * (r.median_size ?? 0))}% pot`,
              `n ${nText(r.n)}${r.ci ? ` · 95% ${r.ci[0]}–${r.ci[1]}%` : ""}`,
              `break-even ${pct(r.break_even, 1)} · edge ${signed(key === "bets" ? r.edge : r.overfold)}`,
              ...(r.judged ? [] : ["small sample"]), clickWord(r)],
      }));
      holders.push([p, rows]);
      p.append(el("div", null, "g-plot"));
      p.append(numbers(["size", "n", "fold", "95%", "break-even", "edge"],
        g[key].map(r => [r.letter, nText(r.n), pct(r.fold, 1), r.ci ? `${r.ci[0]}–${r.ci[1]}` : "–", pct(r.break_even, 1),
                         signed(key === "bets" ? r.edge : r.overfold)])));
      panels.append(p);
    }
    c.append(panels, key([["wash", "a pure bluff profits"], ["line", "break-even s/(1+s)"]]),
             el("p", `${smallNote(d.min_sample)}. Multiway a fold is one player's: pick HU for a bluff's real odds.`, "g-cap"));
    c._draw = () => {
      for (const [p, rows] of holders) {
        p.querySelector(".g-plot").replaceChildren(scatter(widthOf(p), {
          rows, curve: bluffBreakEven, color: "var(--accent)", wash: "bluffs profit", yName: "fold % by bet size",
        }));
      }
    };
    return c;
  }
  function key(items) {
    const k = el("div", null, "g-key");
    for (const [cls, text, color] of items) {
      const s1 = el("span"), i = el("i", null, cls);
      if (color) i.style.background = color;
      s1.append(i, text); k.append(s1);
    }
    return k;
  }

  // ---- graph 2: stab fold by texture ----------------------------------------------------
  function stabCard(d) {
    const st = d.stab;
    const c = card("Stab fold by flop texture",
      "Stab = a flop bet into a check by a non-raiser, e.g. the BB bets after the raiser checks. Right of the tick, a pure-bluff stab profits.");
    c.append(take(st.takeaway, `${st.all.n} stabs: needs ${d.min_sample}+`));
    const rows = [];
    const add = (r, label, indent, small) => rows.push({
      label, indent, y: r.fold, lo: r.ci?.[0], hi: r.ci?.[1], be: r.break_even, n: r.n, judged: r.judged,
      filter: r.filter,
      tip: [`${pct(r.fold, 1)} everyone folded`, `${label}${r.letter ? ` · ${SIZE_WORD[r.letter]}` : ""}${r.median_size != null ? ` · median ${Math.round(100 * r.median_size)}% pot` : ""}`,
            `n ${nText(r.n)}${r.ci ? ` · 95% ${r.ci[0]}–${r.ci[1]}%` : ""}`, `break-even ${pct(r.break_even, 1)} · edge ${signed(r.edge)}`,
            ...(small ? [`${small} more in sizes under ${d.min_sample} stabs`] : []), ...(r.judged ? [] : ["small sample"]), clickWord(r)],
    });
    add(st.all, "every flop", 0);
    for (const t of st.textures) {
      add(t, t.label, 0, t.small);
      for (const z of t.sizes) add(z, `${z.letter} ${SIZE_WORD[z.letter]}`, 1);
    }
    const plot = el("div", null, "g-plot");
    c.append(plot, key([["wash", "a pure-bluff stab profits"], ["", "break-even, the tick", "var(--ink-2)"]]),
             numbers(["", "n", "fold", "95%", "break-even", "edge"],
               rows.map(r => [`${r.indent ? "  " : ""}${r.label}`, nText(r.n), pct(r.y, 1), r.lo != null ? `${r.lo}–${r.hi}` : "–", pct(r.be, 1),
                              signed(r.y != null && r.be != null ? r.y - r.be : null)])),
             el("p", `${smallNote(d.min_sample)}; a size gets its own row from ${d.min_sample} stabs.`, "g-cap"));
    c._draw = () => plot.replaceChildren(forest(widthOf(plot), rows, { color: "var(--accent)" }));
    return c;
  }

  // ---- graph 3: river bluffs by bet size ------------------------------------------------
  function riverCard(d) {
    const rr = d.river_range;
    const c = card("River bluffs by bet size",
      "Shown river bets that were bluffs; above the dashed line a bluff-catcher calls profitably, e.g. a pot bet needs 33%.");
    c.append(take(rr.takeaway, `needs ${d.min_sample}+ shown a size`));
    const rows = rr.rows.map(r => ({
      x: r.median_size, y: r.bluff_pct, lo: r.ci?.[0], hi: r.ci?.[1], n: r.shown, judged: r.judged, letter: r.letter,
      label: `river bet ${r.letter}, shown`, filter: r.filter,
      tip: [`${pct(r.bluff_pct, 1)} bluffs`, `${r.letter} ${SIZE_WORD[r.letter]}${r.median_size != null ? ` · median ${Math.round(100 * r.median_size)}% pot` : ""}`,
            `${nText(r.shown)} shown of ${nText(r.n)} bets${r.ci ? ` · 95% ${r.ci[0]}–${r.ci[1]}%` : ""}`,
            `value ${r.mix.value} · marginal ${r.mix.marginal} · bluff ${r.mix.bluff + r.mix.semi_bluff}`,
            `catcher break-even ${pct(r.break_even, 1)} · edge ${signed(r.edge)}`, ...(r.judged ? [] : ["small sample"]), "click: these hands"],
    }));
    const plot = el("div", null, "g-plot");
    c.append(plot, key([["wash", "calling a catcher profits"], ["line", "break-even s/(1+2s)"]]),
             numbers(["size", "shown", "of bets", "bluffs", "95%", "break-even", "edge"],
               rr.rows.map(r => [r.letter, nText(r.shown), nText(r.n), pct(r.bluff_pct, 1), r.ci ? `${r.ci[0]}–${r.ci[1]}` : "–", pct(r.break_even, 1), signed(r.edge)])),
             el("p", `${smallNote(d.min_sample)}. Shown hands lean to value: a folded-to bluff is never seen.`, "g-cap"));
    c._draw = () => plot.replaceChildren(scatter(widthOf(plot), {
      rows, curve: catcherBreakEven, color: "var(--g-bluff)", wash: "calls profit", yName: "river bluff % by bet size",
    }));
    return c;
  }

  // ---- graph 4: c-bets by flop texture ---------------------------------------------------
  function cbetCard(d) {
    const ct = d.cbet_texture;
    const c = card("Flop c-bets by texture", "Bar = how often the raiser c-bet, split by size, e.g. 48% with 18% at M.");
    c.append(take(ct.takeaway, `needs ${d.min_sample}+ chances on two textures`));
    const rows = ct.rows.map(r => ({
      label: r.label, total: r.freq, n: r.opp, judged: r.judged, filter: r.filter,
      tip: [`${pct(r.freq, 1)} c-bet`, `${r.label} flops · ${nText(r.n)} of ${nText(r.opp)} chances${r.ci ? ` · 95% ${r.ci[0]}–${r.ci[1]}%` : ""}`,
            `L or O: ${pct(r.big)} of c-bets${r.median_size != null ? ` · median ${Math.round(100 * r.median_size)}% pot` : ""}`,
            ...(r.unsized ? [`${r.unsized} of unknown size`] : []), ...(r.judged ? [] : ["small sample"]), "click: these chances"],
      parts: r.sizes.map(z => ({
        letter: z.letter, share: z.share ?? 0, n: z.n, label: `${r.label} c-bet ${z.letter}`, filter: z.filter,
        tip: [`${pct(z.share, 1)} of chances`, `${r.label} · c-bet ${z.letter} ${SIZE_WORD[z.letter]}`, `${nText(z.n)} of ${nText(r.opp)}`, "click: these hands"],
      })),
    }));
    const plot = el("div", null, "g-plot");
    c.append(plot, key(SIZES.map((l, i) => ["", `${l} ${SIZE_WORD[l]}`, `var(--g${i + 1})`])),
             numbers(["texture", "chances", "c-bet", "95%", ...SIZES, "L+O of bets"],
               ct.rows.map(r => [r.label, nText(r.opp), pct(r.freq, 1), r.ci ? `${r.ci[0]}–${r.ci[1]}` : "–", ...r.sizes.map(z => pct(z.share)), pct(r.big)])),
             el("p", smallNote(d.min_sample) + " (chances).", "g-cap"));
    c._draw = () => plot.replaceChildren(bars(widthOf(plot), rows));
    return c;
  }

  // ---- the panel -----------------------------------------------------------------------
  let cards = [];
  function paint() {
    hideTip();
    if (!data) return;
    cards = [foldCard(data), stabCard(data), riverCard(data), cbetCard(data)];
    grid.replaceChildren(...cards);
    draw();
  }
  function draw() { if (open) for (const c of cards) c._draw?.(); }

  let seq = 0, ctl = null;
  async function load(next) {
    spot = { ...spot, ...next };
    paintHead();
    if (!open) { data = null; return; }
    const me = ++seq;
    ctl?.abort();
    ctl = new AbortController();
    const q = new URLSearchParams({ games: spot.games || "play" });
    if (spot.player) q.set("player", spot.player);
    if (spot.filter) q.set("filter", spot.filter);
    grid.classList.add("loading");
    if (!data) grid.replaceChildren(pntPage.message("drawing the graphs…"));
    try {
      const d = await pntPage.getJson("/explore/graphs?" + q, { signal: ctl.signal });
      if (me !== seq) return;
      data = d;
      paintHead();
      paint();
    } catch (e) {
      if (me !== seq || e?.name === "AbortError") return;
      data = null;
      grid.replaceChildren(pntPage.message(pntPage.firstLine(e.message || e), "err"));
    } finally {
      if (me === seq) grid.classList.remove("loading");
    }
  }
  function paintHead() {
    const who = spot.player || (data?.without ? `pool without ${data.without}` : "pool");
    root.querySelector(".g-who").textContent = `${who}${spot.filter ? ` · ${spot.filter}` : ""} · follows the spot, not the line`;
  }

  function mount(where, opts = {}) {
    onPick = opts.onPick;
    if (!document.getElementById("pnt-graphs-css")) {
      const st = el("style", CSS); st.id = "pnt-graphs-css"; document.head.append(st);
    }
    root = where;
    root.classList.add("pnt-graphs");
    const head = el("div", null, "g-head");
    const toggle = el("button", "Graphs", "g-toggle");
    toggle.type = "button"; toggle.setAttribute("aria-expanded", open);
    toggle.title = "fold equity, stabs, river bluffs and c-bets for this spot";
    grid = el("div", null, "g-grid");
    grid.hidden = !open;
    toggle.addEventListener("click", () => {
      open = !open; keep({ open });
      toggle.setAttribute("aria-expanded", open); grid.hidden = !open;
      if (open && !data) load({}); else draw();
    });
    head.append(toggle, el("span", "", "g-who muted"));
    tip = el("div", null, "g-tip hidden");
    tip.setAttribute("role", "tooltip");
    root.replaceChildren(head, grid, tip);
    let w = 0, timer = null;
    new ResizeObserver(() => {
      const now = grid.clientWidth;
      if (Math.abs(now - w) < 8) return;
      w = now; clearTimeout(timer); timer = setTimeout(draw, 80);
    }).observe(grid);
  }

  window.pntGraphs = { mount, load, lib };
})();
