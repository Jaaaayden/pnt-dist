/* The one nav strip at the top of every page: Home, Stats, Chart, Line explorer,
 * All-in, Pots, Self-scout, Identities, with the page you are on picked out.
 *
 * Loaded in <head> right after loading.js. It fills <nav class="pnt-nav"
 * id="crumb" data-page="..."> when the page has one, or puts one at the top of
 * <main> (else <body>) when it has not, so a new page needs only the script tag.
 * Each link's id is `<key>link`, which a page sets to carry its spot or player
 * along. pntPage.nav() (loading.js) and window.pntNav() both fill it, once.
 */
(() => {
  "use strict";
  // One list, one order, on every page. [key, path, label].
  const PAGES = [
    ["home", "/", "Home"],
    ["stats", "/stats.html", "Stats"],
    ["chart", "/chart", "Chart"],
    ["postflop", "/postflop", "Line explorer"],
    ["allin", "/allin.html", "All-in"],
    ["pots", "/pots.html", "Pots"],
    ["tendencies", "/tendencies.html", "Self-scout"],
    ["players", "/players.html", "Identities"],
  ];
  // :where() keeps these at no specificity, so a page's own rule wins. The
  // tokens are the palette's (loading.js, or the chart's own), with fallbacks.
  const CSS = `
  :where(.pnt-nav) { display: flex; flex-wrap: wrap; align-items: center; gap: 2px 4px; margin: 0 0 14px;
    padding: 0 0 8px; border-bottom: 1px solid var(--grid, #2c2c2a); font-size: 13px; line-height: 1.3; }
  :where(.pnt-nav) a { color: var(--ink-2, #c3c2b7); text-decoration: none; padding: 3px 10px; border-radius: 999px;
    white-space: nowrap; }
  :where(.pnt-nav) a:hover { color: var(--ink, #fff); background: var(--mid, #383835); }
  :where(.pnt-nav) a:focus-visible { outline: 2px solid var(--accent, #3987e5); outline-offset: 1px; }
  :where(.pnt-nav) a[aria-current=page] { color: var(--ink, #fff); background: var(--mid, #383835); font-weight: 600; }
  :where(.pnt-nav) a:first-child { margin-left: -10px; }
  @media (max-width: 600px) {
    :where(.pnt-nav) { gap: 2px; font-size: 12px; padding-bottom: 6px; margin-bottom: 10px; }
    :where(.pnt-nav) a { padding: 2px 7px; }
    :where(.pnt-nav) a:first-child { margin-left: -7px; }
  }`;

  const t = new URLSearchParams(location.search).get("theme");
  const theme = t === "light" || t === "dark" ? t : null;
  const href = (path) => (theme ? `${path}?theme=${theme}` : path);
  // The page it is on: the box's data-page, else read off the path.
  const keyOf = (box) => {
    if (box.dataset.page) return box.dataset.page;
    const path = location.pathname.replace(/\.html$/, "").replace(/\/+$/, "") || "/";
    const hit = PAGES.find(([, p]) => (p.replace(/\.html$/, "") || "/") === path);
    return hit ? hit[0] : "";
  };

  let styled = false;
  function fill() {
    let box = document.getElementById("crumb");
    if (!box) {
      if (!document.body) return null;
      box = document.createElement("nav");
      box.className = "pnt-nav";
      box.id = "crumb";
      box.setAttribute("aria-label", "pages");
      (document.querySelector("main") || document.body).prepend(box);
    }
    if (box.childElementCount) return box;
    if (!styled) {
      styled = true;
      const s = document.createElement("style");
      s.id = "pnt-nav-style";
      s.textContent = CSS;
      document.head.appendChild(s);
    }
    const here = keyOf(box);
    for (const [key, path, label] of PAGES) {
      const a = document.createElement("a");
      a.id = key + "link";
      a.href = href(path);
      a.textContent = label;
      if (key === here) a.setAttribute("aria-current", "page");
      box.append(a);
    }
    return box;
  }
  window.pntNav = fill;
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fill);
  else fill();
})();
