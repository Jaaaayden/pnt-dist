/* Every page's loading signal: the front page, stats, chart, all-in, pots,
 * tendencies and players all load this first, in <head>.
 *
 * It wraps fetch, so no page has to opt in. While any request is out, a thin bar
 * moves along the top; past PILL_MS a pill counts the seconds, so a slow answer
 * reads as working, not frozen; past SLOW_MS a box says what to try, in order.
 * A request that cannot reach the server at all says so at once. Each clears
 * itself when the requests do.
 *
 * It also holds what every page shares (window.pntPage, at the end): the
 * palette, the Sample banner, ?theme, the number formats, getJson,
 * the Wilson interval and the list-and-replay layout.
 */
(() => {
  "use strict";
  // The palette, light and dark, before the page's own <style>: every page
  // reads these. :where() holds them at no specificity, so a page that sets one
  // of its own still wins (the chart's --flag and deeper --amber). --violet,
  // --amber and --teal are the extra hues a page's headline tiles use.
  const PALETTE = `
  :where(:root) {
    color-scheme: light;
    --page: #f9f9f7; --surface: #fcfcfb; --ink: #0b0b0b; --ink-2: #52514e; --muted: #898781;
    --grid: #e1e0d9; --axis: #c3c2b7; --ring: rgba(11,11,11,0.10); --mid: #f0efec; --accent: #2a78d6;
    --up: #1f7a4d; --down: #b93a39; --violet: #7353c4; --amber: #a86a0c; --teal: #1b7d86;
  }
  @media (prefers-color-scheme: dark) { :where(:root:not([data-theme="light"])) { DARK } }
  :where(:root[data-theme="dark"]) { DARK }`.replaceAll("DARK", `
    color-scheme: dark;
    --page: #0d0d0d; --surface: #1a1a19; --ink: #ffffff; --ink-2: #c3c2b7; --muted: #898781;
    --grid: #2c2c2a; --axis: #383835; --ring: rgba(255,255,255,0.10); --mid: #383835; --accent: #3987e5;
    --up: #4cc38a; --down: #e66e6d; --violet: #a690f2; --amber: #e3a54c; --teal: #4fc0c9;`);
  {
    const s = document.createElement("style");
    s.id = "pnt-palette";
    s.textContent = PALETTE;
    (document.head || document.documentElement).prepend(s);
  }
  const PILL_MS = 2000, SLOW_MS = 20000;
  // Requests nobody is waiting on: the native file picker, which waits on a
  // person, and the chart's chip counts, badges that fill in behind the page.
  const SKIP = [/\/settings\/paths\/browse/, /\/counts(\?|$)/];
  const EMBED = window.parent !== window; // the chart inside the HUD's side panel

  const out = new Map(); // request id -> started at
  let next = 0, down = false, shut = null, ui = null;

  const realFetch = window.fetch.bind(window);
  window.fetch = (input, init) => {
    const url = typeof input === "string" ? input : input?.url || String(input);
    if (SKIP.some((r) => r.test(url))) return realFetch(input, init);
    const id = ++next;
    out.set(id, Date.now());
    paint();
    return realFetch(input, init).then(
      (r) => { settle(id, false); return r; },
      (e) => { settle(id, e?.name !== "AbortError"); throw e; },
    );
  };

  // A failed connection is a TypeError with no response; an abort is the page's
  // own doing (a newer request replaced it), not the server's.
  function settle(id, failed) {
    out.delete(id);
    if (failed) down = true;
    else if (!out.size) down = false;
    paint();
  }

  const CSS = `
  #pnt-load-bar { position: fixed; top: 0; left: 0; right: 0; height: 2px; z-index: 2147483000;
    overflow: hidden; pointer-events: none; opacity: 0; transition: opacity .2s; }
  #pnt-load-bar.on { opacity: 1; }
  #pnt-load-bar::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%;
    background: var(--accent, #3987e5); animation: pnt-load-slide 1.1s ease-in-out infinite; }
  @keyframes pnt-load-slide { from { left: -30%; } to { left: 100%; } }
  #pnt-load-pill { position: fixed; right: 12px; bottom: 12px; z-index: 2147483000; display: none;
    font: 12px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif; color: var(--ink-2, #c3c2b7);
    background: var(--surface, #1a1a19); border: 1px solid var(--ring, rgba(255,255,255,.1));
    border-radius: 999px; padding: 3px 10px; font-variant-numeric: tabular-nums; }
  #pnt-load-pill.on { display: block; }
  #pnt-load-pill::before { content: ""; display: inline-block; width: 8px; height: 8px; margin-right: 6px;
    border-radius: 50%; border: 2px solid var(--accent, #3987e5); border-right-color: transparent;
    vertical-align: -1px; animation: pnt-load-spin .8s linear infinite; }
  @keyframes pnt-load-spin { to { transform: rotate(360deg); } }
  #pnt-load-box { position: fixed; right: 12px; bottom: 44px; z-index: 2147483000; display: none;
    max-width: min(360px, calc(100vw - 24px)); box-sizing: border-box;
    font: 13px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif; color: var(--ink, #fff);
    background: var(--surface, #1a1a19); border: 1px solid var(--down, #e66e6d); border-radius: 10px;
    padding: 10px 12px; box-shadow: 0 4px 18px rgba(0,0,0,.25); }
  #pnt-load-box.on { display: block; }
  #pnt-load-box b { color: var(--down, #e66e6d); }
  #pnt-load-box ol { margin: 6px 0 0; padding-left: 18px; color: var(--ink-2, #c3c2b7); }
  #pnt-load-box li { margin: 3px 0; }
  #pnt-load-box code { font: 12px ui-monospace, Consolas, monospace; background: var(--mid, #383835);
    padding: 1px 5px; border-radius: 4px; color: var(--ink, #fff); }
  #pnt-load-box button { font: inherit; font-size: 12px; color: var(--ink, #fff); background: none; cursor: pointer;
    border: 1px solid var(--ring, rgba(255,255,255,.2)); border-radius: 5px; padding: 0 7px; margin-left: 4px; }
  #pnt-load-box button:hover { border-color: var(--accent, #3987e5); }
  #pnt-load-box .shut { float: right; border: 0; margin: -2px -4px 0 6px; color: var(--muted, #898781); }
  @media (prefers-reduced-motion: reduce) {
    #pnt-load-bar::before { animation: none; left: 0; width: 100%; opacity: .5; }
    #pnt-load-pill::before { animation: none; }
  }`;

  function build() {
    if (ui || !document.body) return ui;
    const style = document.createElement("style");
    style.textContent = CSS;
    document.head.appendChild(style);
    const bar = document.createElement("div"); bar.id = "pnt-load-bar";
    const pill = document.createElement("div"); pill.id = "pnt-load-pill"; pill.setAttribute("role", "status");
    const box = document.createElement("div"); box.id = "pnt-load-box"; box.setAttribute("role", "alert");
    document.body.append(bar, pill, box);
    ui = { bar, pill, box, kind: null };
    return ui;
  }

  const el = (tag, text) => { const n = document.createElement(tag); if (text != null) n.textContent = text; return n; };
  function cmd(text) {
    const span = el("span");
    const copy = el("button", "copy");
    copy.type = "button";
    copy.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(text); copy.textContent = "copied"; } catch { copy.textContent = "select it"; }
    });
    span.append(el("code", text), copy);
    return span;
  }
  function reloadButton() {
    const b = el("button", "Reload page");
    b.type = "button";
    b.addEventListener("click", () => location.reload());
    return b;
  }
  const li = (...parts) => { const l = el("li"); l.append(...parts); return l; };

  function fill(box, kind, secs) {
    box.replaceChildren();
    const x = el("button", "✕");
    x.type = "button"; x.className = "shut"; x.title = "hide this";
    x.addEventListener("click", () => { shut = kind; box.classList.remove("on"); });
    const steps = el("ol");
    if (kind === "down") {
      box.append(x, el("b", "Can't reach the tracker."), " The server has stopped or restarted.");
      steps.append(li("In a terminal: ", cmd("pnt service status")),
        li("Stopped or stuck: ", cmd("pnt service restart")), li("Then ", reloadButton()));
    } else {
      const head = el("b", "Still loading after ");
      const n = el("span", String(secs));
      n.className = "secs";
      head.append(n, " s.");
      box.append(x, head, " A big question on a cold server can take a minute.");
      steps.append(li("Still stuck: ", reloadButton()), li(cmd("pnt service restart"), ", then reload"));
      if (EMBED) steps.append(li("Still stuck in the HUD: the panel's ", el("b", "Reload extension"),
        ", or ↻ on chrome://extensions"));
    }
    box.append(steps);
  }

  function paint() {
    const u = build();
    if (!u) return;
    const now = Date.now();
    const oldest = out.size ? Math.min(...out.values()) : null;
    const age = oldest == null ? 0 : now - oldest;
    u.bar.classList.toggle("on", out.size > 0);
    u.pill.classList.toggle("on", age >= PILL_MS);
    if (age >= PILL_MS) u.pill.textContent = `loading · ${Math.floor(age / 1000)} s`;
    const kind = down ? "down" : age >= SLOW_MS ? "slow" : null;
    if (kind !== shut) shut = null;
    const show = kind && kind !== shut ? kind : null;
    // Filled once per case; after that only the count moves, so a copy button's
    // "copied" survives.
    if (show && show !== u.kind) fill(u.box, show, Math.floor(age / 1000));
    else if (show === "slow") u.box.querySelector(".secs").textContent = String(Math.floor(age / 1000));
    u.kind = show;
    u.box.classList.toggle("on", !!show);
  }

  setInterval(() => { if (out.size || down || ui?.kind) paint(); }, 1000);
  document.addEventListener("DOMContentLoaded", paint);

  // ---- What every page shares: the sample banner, the theme, and the
  // number formats. Exposed as window.pntPage for the page's own script.
  const theme = new URLSearchParams(location.search).get("theme");
  const THEME = theme === "light" || theme === "dark" ? theme : null;
  if (THEME) document.documentElement.dataset.theme = THEME;
  // `path` with `params` and the page's ?theme, which every link carries along.
  const href = (path, params) => {
    const q = new URLSearchParams(params || {});
    if (THEME) q.set("theme", THEME);
    const s = q.toString();
    return s ? path + (path.includes("?") ? "&" : "?") + s : path;
  };

  // :where() keeps these at no specificity, so a page's own rule wins.
  const PAGE_CSS = `
  :where(.pnt-sample) { display: flex; flex-wrap: wrap; align-items: baseline; gap: 4px 12px; margin: 0 0 12px;
    padding: 6px 12px; border-radius: 8px; font-size: 13px; color: var(--ink, #fff);
    border: 1px solid var(--accent, #3987e5); background: color-mix(in srgb, var(--accent, #3987e5) 10%, transparent); }
  :where(.pnt-sample) a { color: var(--accent, #3987e5); }`;
  let pageStyled = false;
  function pageStyle() {
    if (pageStyled) return;
    pageStyled = true;
    const s = document.createElement("style");
    s.textContent = PAGE_CSS;
    document.head.appendChild(s);
  }

  // The one nav is nav.js's, loaded right after this file; the page's script
  // calls this first thing, so the nav's links are there to set.
  const nav = () => (window.pntNav ? window.pntNav() : document.getElementById("crumb"));

  // While the pages show the sample, every page says so, not just the front one
  // (it has a banner of its own, with the switch on it).
  async function sampleBanner() {
    if (EMBED || document.getElementById("sample-banner")) return;
    try {
      const r = await realFetch("/settings/dataset");
      if (!r.ok || (await r.json()).active !== "sample") return;
    } catch { return; }
    pageStyle();
    const b = el("div");
    b.className = "pnt-sample";
    b.id = "pnt-sample";
    b.setAttribute("role", "status");
    const back = el("a", "back to your hands ›");
    back.href = href("/") + "#files-h";
    b.append(el("b", "Sample data"), " anonymized games, not yours.", back);
    const at = document.getElementById("crumb");
    if (at) at.after(b);
    else (document.querySelector("main") || document.body).prepend(b);
  }

  // A page newer than the server answers 404 Not Found on a route it added.
  const OLD_SERVER = "the running server is older than this page: run `pnt service restart`";

  // A failed answer `r`, its JSON `body` already read, as an Error in the
  // server's own words: its `detail`, each message of a 422's list, or the
  // old-server line. For a page that reads the status itself first.
  function httpError(r, body) {
    if (r.status === 404 && body?.detail === "Not Found") return new Error(OLD_SERVER);
    const detail = Array.isArray(body?.detail) ? body.detail.map((d) => d.msg || String(d)).join("; ") : body?.detail;
    return new Error(detail || `${r.status} ${r.statusText}`);
  }

  // GET (or `init`'s method) a JSON route; a failure throws httpError's words.
  async function getJson(url, init = {}) {
    const r = await fetch(url, { ...init, headers: { accept: "application/json", ...init.headers } });
    if (r.ok) return r.json();
    throw httpError(r, await r.json().catch(() => ({})));
  }

  // Wilson 95% interval for a rate of p (0..1) over n chances, as [lo, hi]
  // fractions; null with no chances. Mirrors queries.wilson (SPEC.md,
  // "Confidence intervals"); the HUD's spot.js carries the same copy.
  function wilson(p, n, z = 1.96) {
    if (!(n > 0) || p == null) return null;
    const z2 = z * z;
    const centre = (p + z2 / (2 * n)) / (1 + z2 / n);
    const half = z * Math.sqrt(p * (1 - p) / n + z2 / (4 * n * n)) / (1 + z2 / n);
    return [Math.max(0, centre - half), Math.min(1, centre + half)];
  }

  // A rate in percent over n chances, as hover text: "± 8.6 pts (95%: 31.2–48.5%)".
  // Wilson is lopsided near 0% and 100%, so the range is printed beside the ±.
  function ciText(pct, n) {
    const ci = pct == null ? null : wilson(pct / 100, n);
    if (!ci) return "";
    const [lo, hi] = ci.map((x) => 100 * x);
    return `± ${((hi - lo) / 2).toFixed(1)} pts (95%: ${lo.toFixed(1)}–${hi.toFixed(1)}%)`;
  }

  // A line of text in a <p>: "loading…", "no hands", an error (cls "err").
  function message(text, cls = "muted") {
    const p = el("p", text);
    p.className = cls;
    return p;
  }

  // ---- A hand list beside its replay (All-in, Biggest pots), as the chart
  // has it and under the chart's switch and key, so one choice holds on every
  // page. Split, the replay pane is there with a placeholder whenever there are
  // hands to pick, so the first pick does not shove the list aside. Each page
  // sets its own grid columns on `#hand-pair.split`; the rest is here.
  const LAYOUT_KEY = "pnt.reviewLayout";
  // The defaults sit at no specificity, under the page's own; the rules that
  // must beat the page's grid columns (no replay, a phone's empty pane) do not.
  const PAIR_CSS = `
  :where(.replay) { margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--grid); font-size: 13px; }
  :where(#hand-pair.split) { display: grid; gap: 0 12px; align-items: start; }
  #hand-pair.split:has(> .replay.hidden) { grid-template-columns: minmax(0, 1fr); }
  #hand-pair.split > .replay { position: sticky; top: 12px; margin-top: 0; padding: 0 0 0 12px; border-top: 0;
    border-left: 1px solid var(--grid); max-height: calc(100vh - 24px); max-height: calc(100dvh - 24px); overflow-y: auto; }
  #hands-split[aria-pressed=true] { color: var(--accent); border-color: var(--accent); }
  @media (max-width: 620px) {
    #hand-pair.split:has(> .replay[data-empty]) { grid-template-columns: minmax(0, 1fr); }
    #hand-pair.split > .replay[data-empty] { display: none; }
    :where(.replay) { font-size: 11px; }
  }`;
  // `pair` holds the list and `replay`; `toggle` is the Side by side button;
  // `empty` the placeholder's words; `has()` whether there are hands to pick.
  // Returns reset(shown): clear the replay, to its placeholder when split and
  // `shown`, else hidden.
  function sideBySide({ pair, toggle, replay, empty, has }) {
    let split = true;
    try { split = localStorage.getItem(LAYOUT_KEY) !== "stacked"; } catch { /* side by side */ }
    if (!document.getElementById("pnt-pair-css")) {
      const s = el("style", PAIR_CSS);
      s.id = "pnt-pair-css";
      document.head.prepend(s);
    }
    function reset(shown = true) {
      window.pntReplay?.cancel(replay);
      if (split && shown) {
        replay.classList.remove("hidden");
        replay.dataset.empty = ""; // pntReplay.show clears it
        replay.replaceChildren(message(empty));
      } else {
        replay.classList.add("hidden");
      }
    }
    function apply() {
      pair.classList.toggle("split", split);
      toggle.setAttribute("aria-pressed", split);
    }
    toggle.addEventListener("click", () => {
      split = !split;
      try { localStorage.setItem(LAYOUT_KEY, split ? "split" : "stacked"); } catch { /* this visit only */ }
      apply();
      // A replay on show stays, even when a re-render has unpressed its row.
      if (replay.classList.contains("hidden") || "empty" in replay.dataset) reset(has());
    });
    apply();
    return reset;
  }

  // A time in the viewer's own time zone, the year only when it is not this
  // one: "Oct 30, 03:12 AM". The one formatter for every time a page prints.
  const WHEN = new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  const WHEN_Y = new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  const when = (ts) => {
    const d = new Date(ts);
    if (!ts || isNaN(d)) return ts || "";
    return (d.getFullYear() === new Date().getFullYear() ? WHEN : WHEN_Y).format(d);
  };

  // A line in words, for hover text (SPEC.md, "Paths"): `XC-XC-XF` reads "flop
  // check-call · turn check-call · river check-fold". Null for text that is not
  // a line, which the server's error then explains. It accepts what
  // `paths.parse_path` accepts: tests/fixtures/path_cases.json holds the two to it.
  const ACT = { x: "check", b: "bet", c: "call", f: "fold", r: "raise" };
  const SIZE_WORD = { t: "under ⅕ pot", s: "⅕–½ pot", m: "½–¾ pot", l: "¾ pot–pot", o: "overbet" };
  const STREETS = ["flop", "turn", "river"];
  function pathWords(text) {
    // Spaces are forgiven, but not inside a number: `B3 3` is two sizes.
    if (/[\d.]\s+[\d.]/.test(String(text ?? ""))) return null;
    const parts = String(text ?? "").replace(/\s+/g, "").toLowerCase().split("-");
    // Trailing blank streets drop off first, past the river too: `B-B-B-` is `B-B-B`.
    while (parts.length && !parts.at(-1)) parts.pop();
    if (parts.length > 3 || !parts.length) return null;
    const out = [];
    for (const [i, part] of parts.entries()) {
      if (!part) { out.push(`${STREETS[i]} anything`); continue; }
      const acts = [];
      let size = null;
      // A number is what Python's float() reads of a run of digits and dots: 5, 5., .5, 5.5.
      const re = /\[([xbcfr]+)\]|([xbcfr])|([tsmlo])|(\d+\.?\d*|\.\d+)(?![\d.])|(a)/y;
      let m, at = 0, last = null, jam = false;
      while (at < part.length && (m = re.exec(part))) {
        at = re.lastIndex;
        // A bracket's letters in the order Python writes them: `[BX]` is `[XB]`.
        const letters = m[1] || m[2] ? [..."xbcfr"].filter(c => (m[1] || m[2]).includes(c)).join("") : null;
        if (letters) {
          // As the grammar has it: only C F R follow another action, nothing a fold.
          if (acts.length && (/^[xb]+$/.test(letters) || last === "f")) return null;
          acts.push([...letters].map(c => ACT[c]).join(" or "));
          last = letters;
        } else if (m[5]) {
          // All in: once a street, after a bet or a raise.
          if (jam || !/[br]/.test(last ?? "")) return null;
          jam = true;
        } else if (!acts.length || size) return null;
        else size = m[3] ? SIZE_WORD[m[3]] : `${m[4]}% pot`;
      }
      if (at < part.length || !acts.length) return null;
      out.push(`${STREETS[i]} ${acts.join("-")}${jam ? " all in" : ""}${size ? ` (${size})` : ""}`);
    }
    return out.join(" · ");
  }
  // A size sequence in words: `M-M-L` reads "flop ½–¾ pot · turn ½–¾ pot · river
  // ¾ pot–pot"; `·` is a street with no size, `*` any.
  const sizeSeqWords = (text) => String(text ?? "").split("-").map((s, i) =>
    `${STREETS[i] ?? "?"} ${s === "·" ? "no size" : s === "*" ? "any size" : SIZE_WORD[s.toLowerCase()] ?? s}`).join(" · ");
  // A player's own line as the chart's Lines view keys it (`xc/b/x`, `-` for a
  // street they did not act on) in the Line explorer's capitals and dashes:
  // `XC-B-X`. Streets they never acted on at the end drop off.
  function lineCode(line) {
    const segs = String(line ?? "").split("/");
    while (segs.length && segs.at(-1) === "-") segs.pop();
    return segs.length ? segs.map(s => (s === "-" ? "" : s.toUpperCase())).join("-") : "no action";
  }

  const DASH = "–";
  const ok = (v) => v != null && Number.isFinite(Number(v));
  window.pntPage = {
    theme: THEME, href, nav, DASH, OLD_SERVER, getJson, httpError, wilson, ciText, message, sideBySide, when,
    pathWords, sizeSeqWords, lineCode,
    // A count with thousands separators.
    int: (v) => (ok(v) ? Number(v).toLocaleString() : DASH),
    // A rate in percent, one decimal: 29.0%.
    pct: (v) => (ok(v) ? Number(v).toFixed(1) + "%" : DASH),
    // bb/100 and other signed figures, one decimal: +38.4, +7,407.5.
    signed: (v, dp = 1) => (ok(v)
      ? (v > 0 ? "+" : "") + Number(v).toLocaleString(undefined, { minimumFractionDigits: dp, maximumFractionDigits: dp })
      : DASH),
    // Names in the order a person reads them: player 2 before player 10.
    byName: (a, b) => String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: "base" }),
    // The first line of a server error: an unknown filter term's long list of
    // every term stays in the API and the CLI; the ? Filters panel has it here.
    firstLine: (text) => String(text ?? "").split("\n")[0],
  };
  document.addEventListener("DOMContentLoaded", () => { nav(); sampleBanner(); });
})();
