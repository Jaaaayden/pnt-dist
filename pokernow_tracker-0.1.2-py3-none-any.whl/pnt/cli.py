"""`pnt` -- import logs, query stats, manage identities."""

from __future__ import annotations

import csv
import glob as globlib
import json
import os
import subprocess
import sys
from pathlib import Path

import typer

from . import local_config
from . import service as svc
from . import update as upd
from .db.conn import DEFAULT_DB, connect
from .db.userdata import tag_resolver
from .ingest import fetch as fetchmod
from .ingest import sample as samplemod
from .ingest import sync as syncmod
from .ingest.csv_source import HAND_START, has_hands, read_csv
from .ingest.importer import (
    apply_aliases,
    delete_game,
    export_aliases,
    import_csv,
    merge_players,
    player_notes,
    rebuild_game,
    rename_player,
    set_player_note,
    split_identities,
)
from .ingest.log_folder import LOG_DIR, SAVE_LOGS, log_path, write_log
from .logfmt import anonymize as anon
from .logfmt import redact as rd
from .stats.allin import allin_report
from .stats.bluffs import bluff_value
from .stats.filters import parse_filter
from .stats.fold_equity import fold_equity
from .stats.lines import DEFAULT_MIN as LINES_MIN
from .stats.lines import MODES as LINES_MODES
from .stats.lines import TIERS, line_breakdown
from .stats.pots import DEFAULT_DAYS, DEFAULT_LIMIT, DEFAULT_MIN_POT, big_pots
from .stats.queries import (
    display_names,
    facts_by_player,
    facts_for,
    identities_of,
    pool_facts,
    positional_report,
    report,
)
from .stats.ranges import SIZING_KINDS, composition, range_grid, sizing_tells
from .stats.review import KIND_LABELS as REVIEW_LABELS
from .stats.review import KINDS as REVIEW_KINDS
from .stats.review import (
    hand_notes,
    mark_reviewed,
    note_of,
    review_hand_list,
    reviewed_marks,
    set_note,
)
from .stats.tags import tags_for

app = typer.Typer(add_completion=False, help=__doc__)
alias_app = typer.Typer(help="Manage player identities.")
app.add_typer(alias_app, name="alias")
service_app = typer.Typer(
    help="Keep the server running in the background: starts at login, restarts on crash."
)
app.add_typer(service_app, name="service")


def _utf8_output(*streams) -> None:
    """Never let a suit or an emoji name crash the output.

    Redirected to a file or a pipe on Windows, Python encodes in the ANSI code
    page with errors=strict, so `pnt misses > out.txt` died on the first ♠. Those
    get UTF-8; a console already takes Unicode, and anything left unencodable
    prints as `?` rather than raising.
    """
    for stream in streams:
        if not hasattr(stream, "reconfigure"):
            continue
        try:
            tty = stream.isatty()
        except (AttributeError, ValueError):
            tty = False
        if tty:
            stream.reconfigure(errors="replace")
        else:
            stream.reconfigure(encoding="utf-8", errors="replace")


def _print_version(value: bool) -> None:
    if value:
        typer.echo(upd.install_version())
        raise typer.Exit()


@app.callback()
def _before_any_command(
    _version: bool = typer.Option(
        False,
        "--version",
        callback=_print_version,
        is_eager=True,
        help="Print this install's version, e.g. 0.1.7, and exit.",
    ),
) -> None:
    _utf8_output(sys.stdout, sys.stderr)


#: The database chosen on the front page when there is one, so commands run from any
#: folder reach the same database the server has open.
DbOpt = typer.Option(
    local_config.database(DEFAULT_DB), "--db", help="Path to the tracker database."
)

#: LOG_DIR (from `ingest/log_folder.py`, shared with the server's live record) is
#: where PokerNow exports are kept when you do not say. One folder, so `pnt import`
#: with no argument is the whole history.
#:
#: Three ways to point somewhere else, narrowest first: pass paths (or a folder, or
#: a glob) straight to `pnt import`; pass `--log-dir`; or set PNT_LOG_DIR for good.
#: The environment variable is read once, at import, so it has to be set before the
#: command runs -- which is exactly why `--log-dir` exists as well.

#: A real corpus shipped inside the package, for trying the tracker before it has
#: logs of its own. A fresh install starts empty: `pnt import --sample` and `pnt
#: setup --sample` fall back to it when the log folder is empty; naming a folder or
#: passing paths never reaches it. See pnt/ingest/sample.py.
BUNDLED_LOG_DIR = samplemod.LOG_DIR
BUNDLED_ALIASES = samplemod.ALIASES

LogDirOpt = typer.Option(
    None, "--log-dir", help=f"Folder of PokerNow exports. Default: {LOG_DIR}"
)
PathsArg = typer.Argument(
    None, help="CSV export path(s), directories or globs. Default: the log folder."
)
PnIdsArg = typer.Argument(..., help="PokerNow IDs to move off their player.")
OutOpt = typer.Option(
    Path("logs"), "--out", help="Folder to write the redacted copies into."
)
SampleOpt = typer.Option(
    False,
    "--sample/--no-sample",
    help="Load the bundled, anonymized sample logs when the log folder is empty.",
)
AuditOpt = typer.Option(
    False, "--audit", help="Check files for unshown hole cards instead of writing."
)
AnonymizeOpt = typer.Option(
    False, "--anonymize", help="Also replace every player and game ID with a stand-in."
)
AnonAliasesOpt = typer.Option(
    None, "--aliases", help="With --anonymize: an alias CSV to carry over (`pnt alias export`)."
)
AnonLabelsOpt = typer.Option(
    None,
    "--labels",
    help="With --anonymize: a CSV of alias,label naming those players by the label, not 'player N'.",
)
AliasOpt = typer.Option(..., "--alias", help="Name for the player they move to.")
#: Beside the config in ~/.pnt, never the bundled sample's pnt/logs/aliases.csv:
#: your merges name real people, and that file ships inside the package.
USER_ALIASES = local_config.PATH.parent / "aliases.csv"
AliasFileArg = typer.Argument(USER_ALIASES, help="The alias CSV.")

LOG_GLOB = syncmod.LOG_GLOB

_COLUMNS = [
    ("hands", "Hands", 6),
    ("vpip", "VPIP", 6),
    ("pfr", "PFR", 6),
    ("3bet", "3Bet", 6),
    ("fold_to_3bet", "F3B", 6),
    ("cbet_flop", "CBet", 6),
    ("fold_to_cbet_flop", "FCB", 6),
    ("af_flop", "AFq", 6),
    ("wtsd", "WTSD", 6),
    ("wsd", "W$SD", 6),
    ("bb_per_100", "bb/100", 7),
]


def _fmt(value) -> str:
    if value is None:
        return "--"  # unknown, not zero: the denominator was empty
    return f"{value:g}"


#: `pnt allin`: everything in big blinds, the gap last.
_ALLIN_COLUMNS = [
    ("hands", "Hands", 6),
    ("equity_avg", "Eq%", 7),
    ("net_bb", "Actual", 9),
    ("adjusted_bb", "Adjusted", 9),
    ("diff_bb", "Diff", 9),
]


def _print_table(
    rows: list[dict], key: str, key_width: int = 22, columns: list[tuple] = _COLUMNS
) -> None:
    if not rows:
        typer.echo("(no rows)")
        return
    header = key.ljust(key_width) + "".join(h.rjust(w) for _, h, w in columns)
    typer.echo(header)
    typer.echo("-" * len(header))
    for r in rows:
        line = str(r[key])[: key_width - 1].ljust(key_width)
        line += "".join(_fmt(r.get(c)).rjust(w) for c, _, w in columns)
        typer.echo(line)


def _logs_in(directory: Path) -> list[str]:
    return sorted(str(p) for p in directory.glob(LOG_GLOB))


def _announce_sample(folder: Path) -> None:
    """Say, unmissably, that these hands are not the user's own.

    A database that quietly filled itself with someone else's games would read as
    the user's own history -- and every name in `pnt stats` would be a stranger.
    """
    typer.echo(f"no {LOG_GLOB} in {folder}")
    typer.echo(f"importing the bundled sample corpus instead: {BUNDLED_LOG_DIR}")
    typer.echo("These are someone else's hands, anonymized (Fish, Trapper, ...), for trying the")
    typer.echo("tracker out. Drop your own exports in the log folder and re-run to add yours.")
    typer.echo("")


def _apply_bundled_aliases(conn) -> None:
    """`sample.apply_bundled_aliases`, said aloud."""
    moved = samplemod.apply_bundled_aliases(conn)
    typer.echo(f"merged {moved} sample identity row(s) per {BUNDLED_ALIASES.name}")


def _import(conn, path: str, folder: Path, entries: list | None = None) -> dict:
    """`import_csv`, and a file read from the log folder goes on record.

    On record is what makes deleting that file later remove its game (`pnt sync`).
    Files from anywhere else are not: deleting a Downloads copy once it is imported
    must not take the game with it. `entries`: the file, if the caller read it.
    """
    s = import_csv(conn, path, entries=entries)
    p = Path(path)
    if p.resolve().parent == folder.resolve():
        syncmod.record_file(conn, p, s["game_id"])
    return s


def _log_folder(log_dir: Path | None) -> Path:
    """The log folder a command fills the database from: --log-dir, else LOG_DIR.

    Never the bundled sample's own folder, which the server refuses too
    (`sample.is_sample_folder`): read as a log folder, its anonymized copies of real
    games go on record in your database beside the games they copy."""
    folder = log_dir or LOG_DIR
    if samplemod.is_sample_folder(folder):
        raise typer.BadParameter(
            f"{folder} is the bundled sample's folder, not a log folder. To try the"
            " sample, use `pnt setup --sample` on a new database, or switch Data to"
            " Sample on the front page",
            param_hint="--log-dir" if log_dir else "the log folder (PNT_LOG_DIR or the front page)",
        )
    return folder


def _expand(paths: list[str] | None, folder: Path, sample: bool = False) -> list[str]:
    """Resolve CSV arguments -- paths, directories or globs -- to a list of files.

    With nothing given, that is every export in the log folder; `sample` lets the
    caller fall back to the bundled corpus when that folder is empty, rather than
    failing. Only the two commands that fill a database do that -- asking for a
    specific folder and silently getting a different one would be worse than the
    error it replaces.
    """
    if paths:
        expanded = []
        for pat in paths:
            for p in globlib.glob(pat) or [pat]:
                if not Path(p).exists():
                    raise typer.BadParameter(f"no file or folder at {p}")
                expanded.extend(_logs_in(Path(p)) if Path(p).is_dir() else [p])
    else:
        expanded = _logs_in(folder)
        if not expanded and sample:
            expanded = _logs_in(BUNDLED_LOG_DIR)
        if not expanded:
            raise typer.BadParameter(
                f"no {LOG_GLOB} in {folder} -- put your exports there, pass paths "
                "explicitly, or point somewhere else with --log-dir or PNT_LOG_DIR"
            )
    if not expanded:
        raise typer.BadParameter("no files matched")
    return expanded


@app.command("import")
def import_cmd(
    paths: list[str] | None = PathsArg,
    db: Path = DbOpt,
    log_dir: Path | None = LogDirOpt,
    sample: bool = SampleOpt,
) -> None:
    """Import PokerNow log exports. Safe to re-run: duplicate entries are ignored.

    With no argument, imports every log in the log folder, which is --log-dir if
    given, else $PNT_LOG_DIR, else the folder chosen on the front page, else
    ~/Downloads/pokernow-logs. `pnt where` prints which one is in effect.

    If that folder is empty, `--sample` imports the bundled, anonymized sample
    corpus instead, for trying the tracker out. Without it an empty folder is an
    error: a fresh install starts with no one else's hands.
    """
    folder = _log_folder(log_dir)
    expanded = _expand(paths, folder, sample=sample)
    conn = connect(db)
    if not paths and expanded and Path(expanded[0]).parent == BUNDLED_LOG_DIR:
        _announce_sample(folder)
    bundled = any(Path(p).resolve().parent == BUNDLED_LOG_DIR.resolve() for p in expanded)
    failed = 0
    for path in expanded:
        try:
            entries = read_csv(path)
            if not has_hands(entries):
                typer.echo(f"{Path(path).name}: no hands (joined and left before a deal), skipped")
                continue
            s = _import(conn, path, folder, entries)
        except ValueError as exc:  # no game ID in the name, not a log
            msg = str(exc)
            typer.echo(msg if Path(path).name in msg else f"{Path(path).name}: {msg}", err=True)
            failed += 1
            continue
        note = "no new entries (pure re-import)" if s["entries_new"] == 0 else ""
        typer.echo(
            f"{Path(path).name}: {s['hands']} hands, "
            f"{s['entries_new']}/{s['entries_offered']} new entries, "
            f"{s['parse_misses']} parse misses. {note}"
        )
        if s["hero_pn_id"]:
            typer.echo(f"    hero: {s['hero_pn_id']} ({s['hero_votes']} showdown matches)")
        _echo_sewn(s["game_id"], s["sewn"])
    if bundled:
        _apply_bundled_aliases(conn)
    if failed:
        raise typer.Exit(1)


LinksArg = typer.Argument(None, help="Game links or game IDs.")
FromFileOpt = typer.Option(
    None, "--from-file", "-f", help="A text file of game links, one per line."
)
CookieOpt = typer.Option(
    None,
    "--cookie",
    envvar="PNT_COOKIE",
    show_default=False,
    help="Your PokerNow cookies as 'npt=...; apt=...', for your own hole cards. "
    "Prefer setting PNT_COOKIE: a flag lands in shell history.",
)
RefreshOpt = typer.Option(
    False, "--refresh", help="Re-fetch games already in the folder, merging new lines in."
)
ImportOpt = typer.Option(False, "--import", help="Import each fetched log as well.")


@app.command()
def backfill(
    links: list[str] | None = LinksArg,
    from_file: Path | None = FromFileOpt,
    log_dir: Path | None = LogDirOpt,
    cookie: str | None = CookieOpt,
    refresh: bool = RefreshOpt,
    import_: bool = ImportOpt,
    db: Path = DbOpt,
) -> None:
    """Download games' logs from their PokerNow links into the log folder.

    For games played before live capture: no clicking "download full log" on each.
    Files land where a manual export would (`poker_now_log_<id>.csv` in the log
    folder), so a bare `pnt import` afterwards picks them up.

    Without a cookie you get every action and every showdown, but not your own
    unshown hole cards -- PokerNow only sends `Your hand is` to the logged-in player.
    Copy the `npt` and `apt` cookies from DevTools (Application > Cookies >
    pokernow.com) into PNT_COOKIE as `npt=...; apt=...` to get them; `npt` alone is
    not enough. They are your login: keep them out of files and chat.

    Games already in the folder are skipped; `--refresh` fetches them again and adds
    only lines the file lacks, e.g. your hole cards after a first run without a cookie.
    """
    folder = _log_folder(log_dir)
    raw = list(links or [])
    if from_file:
        raw += [
            line.strip()
            for line in from_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        ]
    if not raw:
        raise typer.BadParameter("give at least one game link, or --from-file")
    try:
        game_ids = list(dict.fromkeys(fetchmod.game_id_from_link(x) for x in raw))
    except fetchmod.FetchError as exc:
        raise typer.BadParameter(str(exc)) from exc

    typer.echo(f"{len(game_ids)} game(s) -> {folder}")
    if not cookie:
        typer.echo("no cookie: your own unshown hole cards will be missing (see --help)")
    elif "apt=" not in cookie:
        typer.echo("cookie has no apt=: without it your hole cards will be missing (see --help)")
    conn = connect(db) if import_ else None
    pacer = fetchmod.Pacer()
    # A game is a minute of paging; show it moving, but only where \r redraws a line.
    live = sys.stdout.isatty()
    failed = 0
    for gid in game_ids:
        path = log_path(folder, gid)
        if path.exists() and not refresh:
            typer.echo(f"{gid}: already in the folder, skipped (--refresh to fetch again)")
            continue
        if not live:
            typer.echo(f"{gid}: fetching...")
        try:
            entries = fetchmod.fetch_log(
                gid,
                cookie,
                pacer=pacer,
                on_page=lambda pages, lines, gid=gid: typer.echo(
                    f"\r{gid}: page {pages}, {lines} lines", nl=False
                )
                if live
                else None,
                on_wait=lambda s, gid=gid: typer.echo(
                    f"{chr(10) if live else ''}{gid}: rate limited by PokerNow, waiting {s:g}s"
                ),
            )
        except fetchmod.FetchError as exc:
            if live:
                typer.echo("")
            typer.echo(str(exc), err=True)
            failed += 1
            continue
        if live:
            typer.echo("")
        if not entries:
            typer.echo(f"{gid}: the log is empty, nothing written")
            continue
        if not has_hands(entries):
            typer.echo(f"{gid}: no hands were dealt, nothing written")
            continue
        new = write_log(entries, path)
        hands = sum(e.entry.startswith(HAND_START) for e in entries)
        hero = fetchmod.count_hero_lines(entries)
        typer.echo(
            f"{gid}: {hands} hands, {new} new lines, {hero} of your hole cards -> {path.name}"
        )
        if cookie and not hero and hands:
            typer.echo(
                "    no hole cards of yours: you did not play this game, or PokerNow did"
                " not accept the cookies (expired, or `apt` missing -- `npt` alone is not enough)"
            )
        if conn is not None:
            s = _import(conn, str(path), folder)
            typer.echo(f"    imported: {s['entries_new']} new entries, {s['parse_misses']} parse misses")
            if s["sewn"]:
                nums = ", ".join(f"#{n}" for n in s["sewn"])
                typer.echo(f"    still missing lines after hand {nums}: PokerNow no longer has them")
    if failed:
        raise typer.Exit(1)
    if not import_:
        typer.echo("\nnext: pnt import")


#: The unpacked Chrome extension, shipped inside the package so that a pip or
#: pipx install has one to load. `pnt extension` prints this path.
EXTENSION_DIR = upd.EXTENSION_DIR


@app.command()
def extension(
    open_folder: bool = typer.Option(False, "--open", help="Reveal it in a file manager."),
) -> None:
    """Where the Chrome extension lives, for `Load unpacked`.

    Printed rather than assumed, because an installed copy sits inside site-packages
    (or a pipx venv) rather than next to a checkout.
    """
    if not (EXTENSION_DIR / "manifest.json").exists():
        raise typer.BadParameter(f"no extension at {EXTENSION_DIR} -- this install is incomplete")
    typer.echo(str(EXTENSION_DIR))
    if open_folder:
        _reveal(EXTENSION_DIR)


def _reveal(path: Path) -> None:
    """Open a folder in the platform's file manager. Best-effort: never fatal."""
    import subprocess
    import sys

    try:
        if sys.platform == "win32":
            os.startfile(path)  # a directory this module constructed, not user input
        else:
            subprocess.run(["open" if sys.platform == "darwin" else "xdg-open", str(path)],
                           check=False)  # fmt: skip
    except OSError as exc:
        typer.echo(f"(could not open the folder: {exc})")


@app.command()
def setup(
    db: Path = DbOpt,
    host: str = svc.DEFAULT_HOST,
    port: int = svc.DEFAULT_PORT,
    service: bool = typer.Option(True, help="Also install the always-on background server."),
    log_dir: Path | None = LogDirOpt,
    sample: bool = SampleOpt,
) -> None:
    """First run: create the database, import any logs, start the server.

    Exists because the steps had an ordering trap. `service install` refuses a
    database that does not exist yet -- rightly, since a missing file would be
    created empty and the HUD would silently show nothing -- but nothing created
    it for you, so a new install hit an error with no obvious next move. This does
    them in the order that works, and is safe to re-run.

    With no exports to import the database starts empty, for live capture to fill.
    `--sample` loads the bundled, anonymized sample corpus into it instead, for
    trying the tracker out.
    """
    folder = _log_folder(log_dir)
    db = db.resolve()
    fresh = not db.exists()
    connect(db).close()
    typer.echo(f"{'created' if fresh else 'using'} database: {db}")

    logs = _logs_in(folder)
    bundled = not logs and sample
    if bundled:
        _announce_sample(folder)
        logs = _logs_in(BUNDLED_LOG_DIR)
    if logs:
        typer.echo(f"importing {len(logs)} log(s) from {Path(logs[0]).parent}")
        conn = connect(db)
        for path in logs:
            # As `pnt import` and the sync do: a log with no hand would only make
            # an empty game, and one that is not a log is named, not a traceback.
            try:
                entries = read_csv(path)
                if not has_hands(entries):
                    typer.echo(f"  {Path(path).name}: no hands (joined and left before a deal), skipped")
                    continue
                s = _import(conn, path, folder, entries)
            except ValueError as exc:
                typer.echo(f"  {Path(path).name}: could not import: {exc}", err=True)
                continue
            typer.echo(f"  {Path(path).name}: {s['hands']} hands, {s['parse_misses']} parse misses")
        if bundled:
            _apply_bundled_aliases(conn)
        conn.close()
    else:
        # Not an error. Live capture fills an empty database on its own; the export
        # folder only matters for backfilling games played before the extension.
        typer.echo(f"no {LOG_GLOB} in {folder} -- skipping import (live capture will fill it)")
        typer.echo("To try it on sample hands first: pnt setup --sample")

    hands = connect(db).execute("SELECT COUNT(*) FROM hands").fetchone()[0]

    if service and svc.supported():
        service_install(db=db, host=host, port=port)
    elif service:
        typer.echo("")
        typer.echo(
            f"`pnt service` covers Windows and macOS. Run `pnt serve --db {db}` in a terminal,"
            " or put that command under systemd."
        )

    typer.echo("")
    typer.echo("Next: load the extension in Chrome -- open chrome://extensions,")
    typer.echo("turn on Developer mode, choose 'Load unpacked', and pick this folder:")
    typer.echo(f"    {EXTENSION_DIR}")
    typer.echo("Already loaded? Click its reload arrow there, so it runs the files just installed.")
    typer.echo("")
    typer.echo(f"Then open a PokerNow game. Charts: http://{host}:{port}/chart  ({hands} hands)")


@app.command("update")
def update_cmd(
    source: str | None = typer.Option(
        None, "--from", help="Install from this URL, wheel or folder instead of the latest release."
    ),
    host: str = svc.DEFAULT_HOST,
    port: int = svc.DEFAULT_PORT,
) -> None:
    """Update to the latest code: reinstall it and restart the server.

    The extension follows on its own: it reloads once it sees the server's copy of
    its files change. One that predates this command cannot, and needs reloading by
    hand at chrome://extensions this once.
    """
    root = upd.checkout_root()
    if root is not None:
        restart = "`pnt service restart`" if svc.supported() else "restart `pnt serve`"
        if source is None:
            typer.echo(
                f"error: this runs from a source checkout ({root}). Update it with `git pull`,"
                f" then {restart}.",
                err=True,
            )
        else:
            # pip would swap the checkout's editable install for that build.
            typer.echo(
                f"error: this runs from a source checkout ({root}), and `--from` would replace"
                " its editable install. Run it with the `pnt` of the install to update,"
                " e.g. a scratch venv's.",
                err=True,
            )
        raise typer.Exit(1)
    if source is None:
        # Asked before the server stops: offline, there is nothing to install, and
        # up to date, nothing to stop it for.
        try:
            latest = upd.newest()
        except upd.UpdateError as exc:
            typer.echo(f"error: {exc}", err=True)
            raise typer.Exit(1) from exc
        build = upd.build_info()
        if upd.changes_behind(latest, build, upd.installed_commit()) == 0:
            mine = (build or {}).get("version") or latest["version"]
            if build is not None and build["count"] > latest["count"]:
                typer.echo(f"already up to date: {mine} is installed, newer than the published {latest['version']}")
            else:
                typer.echo(f"already up to date ({mine})")
            return
        source = upd.wheel_url(latest)
        # A 404 here is a release going out; say so instead of pip's traceback.
        try:
            upd.check_wheel(source)
        except upd.UpdateError as exc:
            typer.echo(f"error: {exc}", err=True)
            raise typer.Exit(1) from exc

    # Stopped first: a running server could import a module halfway through being
    # replaced, and holds files Windows will not let pip overwrite.
    # The task's name is the same for every install on the machine, so only one
    # running this install's interpreter is ours to stop and restart.
    task = svc.supported() and _svc(svc.task_state) is not None
    interpreter = upd.service_interpreter() if task else None
    managed = task and upd.runs_this_install(interpreter)
    if task and not managed:
        which = f"another install ({interpreter})" if interpreter else "an install this cannot name"
        typer.echo(f"`pnt service` runs {which}: leaving it running")
    if managed:
        typer.echo("stopping the server")
        _svc(svc.stop_and_wait)

    typer.echo(f"installing from {source}")
    if sys.platform == "win32":
        typer.echo("(a pip warning about a temporary directory is expected: it is the old pnt.exe)")
    try:
        upd.install(source)
    except upd.UpdateError as exc:
        if managed:
            _svc(svc.start)  # pip rolls back a failed install, so this is the old code
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(1) from exc

    if managed:
        # A fresh interpreter, so the restart runs the code just installed.
        result = subprocess.run(
            [sys.executable, "-m", "pnt.cli", "service", "restart", "--host", host, "--port", str(port)],
            check=False,
        )
        if result.returncode != 0:
            raise typer.Exit(result.returncode)
        typer.echo(
            "The extension reloads itself within a minute; reopen the side panel if it closes."
            " If the HUD still runs the old version, reload it once at chrome://extensions."
        )
        return

    if task:
        # Its server has the database open, maybe on other code: no rebuild under it.
        if interpreter is None:
            typer.echo("updated. If `pnt service` runs this install, run `pnt service restart` now.")
        else:
            typer.echo(
                "updated this install only. To run the service from it instead:"
                " `pnt service install --db <full path>`."
            )
        return

    # No service to restart (Linux, or never `pnt service install`ed), so no restart
    # to rebuild stale hands in: the new code does it here, in a fresh interpreter.
    subprocess.run([sys.executable, "-m", "pnt.cli", "rebuild", "--if-stale"], check=False)

    # A server started by hand keeps the old code, and the extension only reloads
    # once a new one reports the new files, so say which of the two this is.
    body = svc.health(host, port)
    if body is None:
        typer.echo("updated. Start the server with `pnt serve`.")
    else:
        pid = f" (pid {body['pid']})" if body.get("pid") is not None else ""
        typer.echo(
            f"updated, but the server on http://{host}:{port}{pid} still runs the old code."
            " Stop it and run `pnt serve` again."
        )
    typer.echo(
        "The extension reloads itself within a minute of the new server starting; reopen the"
        " side panel if it closes. If the HUD still runs the old version, reload it once at"
        " chrome://extensions. If `pnt serve` asks for `pnt rebuild`, run it once."
    )


@app.command("version")
def version_cmd() -> None:
    """Print this install's version: `0.1.7` for a release, `source checkout at <sha>` for a checkout."""
    typer.echo(upd.install_version())


@app.command()
def where(db: Path = DbOpt) -> None:
    """Print the paths this install is using: database, log folder, extension, log file.

    Every one of them has a default that can be overridden three different ways, so
    "which one is it actually using" is a question worth being able to answer without
    reading the source.
    """
    source = (
        "$PNT_LOG_DIR"
        if os.environ.get("PNT_LOG_DIR")
        else f"chosen on the front page; {local_config.PATH}"
        if local_config.get("log_dir")
        else "default (~/Downloads/pokernow-logs)"
    )
    chosen = local_config.database(DEFAULT_DB)
    db_source = (
        "--db" if db != chosen
        else f"chosen on the front page; {local_config.PATH}" if chosen != DEFAULT_DB
        else "default: the current folder"
    )  # fmt: skip
    n = len(_logs_in(BUNDLED_LOG_DIR))
    rows = [
        ("database", str(db.resolve()), db_source),
        ("log folder", str(LOG_DIR), source),
        (
            "live record",
            "on: live capture writes each game's CSV to the log folder"
            if SAVE_LOGS
            else "off",
            "PNT_SAVE_LOGS=0 turns it off; restart the service after changing it",
        ),
        ("sample logs", str(BUNDLED_LOG_DIR), f"{n} inside the package, anonymized; loaded by --sample"),
        ("extension", str(EXTENSION_DIR), "inside the package"),
        ("server log", str(svc.LOG_FILE), "fixed"),
    ]
    width = max(len(name) for name, _, _ in rows)
    for name, value, note in rows:
        typer.echo(f"{name:<{width}}  {value}")
        typer.echo(f"{'':<{width}}  ({note})")


PruneUntrackedOpt = typer.Option(
    False,
    "--prune-untracked",
    help="Also remove every game no log-folder file is on record for. See --help.",
)
RemoveEmptyOpt = typer.Option(
    False,
    "--remove-empty",
    help="Delete logs with no hand in them (a table joined and left before the first"
    " deal) from the log folder, and their games from the database.",
)


@app.command()
def sync(
    db: Path = DbOpt,
    log_dir: Path | None = LogDirOpt,
    prune_untracked: bool = PruneUntrackedOpt,
    remove_empty: bool = RemoveEmptyOpt,
) -> None:
    """Bring the database in step with the log folder: import new logs, drop deleted ones.

    Logs with no hand in them -- a table joined and left before the first deal --
    are not imported. `--remove-empty` deletes them from the folder as well, along
    with any game they already put in the database.

    The background server does this by itself every few seconds (PNT_SYNC_SECONDS,
    0 to turn it off), so this is for when it is not running.

    A game is removed once every log-folder file it was read from or saved to has
    been deleted. Games with no such file on record are never touched: imported from
    another folder, the bundled sample, captured with PNT_SAVE_LOGS=0, or imported
    before sync existed from a file already deleted. `--prune-untracked` removes
    those too. Deleting the whole folder removes nothing: a missing folder reads as
    an unplugged drive, not an instruction.

    Player merges and renames survive; only players nothing but the deleted games
    knew about go with them.
    """
    conn = connect(db)
    folder = _log_folder(log_dir)
    emptied = syncmod.remove_empty(conn, folder) if remove_empty and folder.is_dir() else []
    for path in emptied:
        typer.echo(f"{path.name}: no hands, deleted")
    out = syncmod.sync_folder(conn, folder)
    for gid, hands in out.removed.items():
        typer.echo(f"{gid}: log deleted, removed {hands} hands")
    # A file already in the database is only put on record; nothing to say about it.
    changed = [s for s in out.imported if s["entries_new"] or "hands" in s]
    for s in changed:
        typer.echo(f"{s['file']}: {s['entries_new']}/{s['entries_offered']} new entries")
    for path, why in out.failed.items():
        typer.echo(f"{Path(path).name}: could not import: {why}", err=True)

    untracked = syncmod.untracked_games(conn)
    if untracked and prune_untracked:
        for gid in untracked:
            typer.echo(f"{gid}: no log file on record, removed {delete_game(conn, gid)} hands")
    elif untracked:
        typer.echo(
            f"{len(untracked)} game(s) have no log file in the folder on record and are"
            " left alone; --prune-untracked removes them"
        )
    if out.empty:
        typer.echo(
            f"{len(out.empty)} log(s) with no hands skipped; --remove-empty deletes them"
        )
    if not (out.removed or changed or out.failed or untracked or emptied or out.empty):
        typer.echo(f"in sync with {folder}")
    if out.failed:
        raise typer.Exit(1)


@app.command()
def rebuild(
    db: Path = DbOpt,
    if_stale: bool = typer.Option(
        False, "--if-stale",
        help="Only when this version would store the hands differently, with one summary line."
        " What `pnt update` runs.",
    ),
) -> None:
    """Re-derive every hand from stored raw entries. Run this after a parser change."""
    if if_stale:
        _rebuild_if_stale(db)
        return
    conn = connect(db)
    for (gid,) in conn.execute("SELECT game_id FROM raw_entries GROUP BY game_id").fetchall():
        s = rebuild_game(conn, gid)
        typer.echo(f"{gid}: {s['hands']} hands, {s['parse_misses']} parse misses")
        _echo_sewn(gid, s["sewn"])


def _echo_sewn(gid: str, sewn: list[int]) -> None:
    """Name a game's hands dropped for a gap in its log, and how to fill it."""
    if sewn:
        nums = ", ".join(f"#{n}" for n in sewn)
        typer.echo(
            f"    {gid}: lines missing after hand {nums}, dropped;"
            f" `pnt backfill {gid} --refresh --import` fills the gap while PokerNow still has the game"
        )


def _rebuild_if_stale(db: Path) -> None:
    """Rebuild every game when this code would store the hands differently
    (`_rebuild_reasons`), with one line before and one after; else nothing.
    What `pnt service restart` runs while the server is stopped."""
    reasons = _rebuild_reasons(str(db))
    if not reasons:
        return
    typer.echo(f"rebuilding the stored hands, so this version can {' and '.join(reasons)}")
    conn = connect(db)
    try:
        games = hands = 0
        for (gid,) in conn.execute("SELECT game_id FROM raw_entries GROUP BY game_id").fetchall():
            s = rebuild_game(conn, gid)
            hands += s["hands"]
            games += 1
            _echo_sewn(gid, s["sewn"])
    finally:
        conn.close()
    typer.echo(f"rebuilt {hands:,} hands in {games} games")


@app.command()
def stats(
    db: Path = DbOpt,
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    filter_: str = typer.Option(None, "--filter", help="e.g. '3bet,position=BTN'"),
    min_hands: int = typer.Option(1, "--min-hands"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Per-player stats. Rates show `--` when the denominator is empty."""
    conn = connect(db)
    try:
        pred = parse_filter(filter_, display_names(conn), tag_resolver(conn)) if filter_ else None
    except ValueError as exc:
        raise typer.BadParameter(str(exc), param_hint="--filter") from exc
    rows = report(conn, game_id=game, min_hands=min_hands, predicate=pred)
    if as_json:
        typer.echo(json.dumps(rows, indent=2))
    else:
        if filter_:
            typer.echo(f"filter: {filter_}\n")
        _print_table(rows, "player")


@app.command()
def positions(
    alias: str,
    db: Path = DbOpt,
    split_by_size: bool = typer.Option(
        False, "--split-by-size", help="Separate 6-max from 5-max instead of pooling."
    ),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """One player's stats broken down by position."""
    conn = connect(db)
    try:
        rows = positional_report(conn, alias, pool=not split_by_size)
    except ValueError as exc:  # an unknown alias
        raise typer.BadParameter(str(exc), param_hint="ALIAS") from exc
    if as_json:
        typer.echo(json.dumps(rows, indent=2))
    else:
        _print_table(rows, "position", key_width=24)


@app.command()
def allin(
    db: Path = DbOpt,
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    filter_: str = typer.Option(None, "--filter", help="e.g. 'position=BTN,3bet_pot'"),
    min_hands: int = typer.Option(1, "--min-hands"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """All-in EV per player: actual net, all-in adjusted net, and the gap, in bb.

    Equities are computed once and kept in the database, so the first run over a
    fresh import takes a while -- about half a second per preflop all-in -- and
    every run after it is instant. Running this once also warms the page.
    """
    conn = connect(db)
    try:
        pred = parse_filter(filter_, display_names(conn), tag_resolver(conn)) if filter_ else None
    except ValueError as exc:
        raise typer.BadParameter(str(exc), param_hint="--filter") from exc
    rows = allin_report(conn, game_id=game, min_hands=min_hands, predicate=pred)
    if as_json:
        typer.echo(json.dumps(rows, indent=2))
        return
    if filter_:
        typer.echo(f"filter: {filter_}")
    skipped = rows[0]["skipped"]["cards_unknown"] if rows else 0
    if skipped:
        typer.echo(f"skipped: {skipped} all-in showdown(s) where a live hand was mucked")
    if filter_ or skipped:
        typer.echo("")
    _print_table(rows, "player", columns=_ALLIN_COLUMNS)


@app.command()
def pots(
    db: Path = DbOpt,
    days: float = typer.Option(DEFAULT_DAYS, "--days", help="Window in days, back from now."),
    all_time: bool = typer.Option(False, "--all", help="Ignore the window; read all of history."),
    min_pot: int = typer.Option(DEFAULT_MIN_POT, "--min-pot", help="Chips a pot must reach to be listed."),
    player: str = typer.Option(None, "--player", help="Only hands this player was dealt into."),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    limit: int = typer.Option(DEFAULT_LIMIT, "--limit"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """The biggest pots of the last few days -- everyone's, biggest first.

    The same rows the Biggest pots page lists; SPEC.md, "Biggest pots", defines
    the window and the pot.
    """
    if days <= 0 and not all_time:
        raise typer.BadParameter("must be above zero; use --all for no window", param_hint="--days")
    conn = connect(db)
    try:
        out = big_pots(
            conn,
            days=None if all_time else days,
            min_pot=min_pot,
            game_id=game,
            player=player,
            limit=limit,
        )
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return
    window = "all time" if all_time else f"the last {days:g} day(s)"
    who = f" for {player}" if player else ""
    typer.echo(
        f"{out['over']} pot(s) over {out['min_pot']:,} in {window}{who}"
        f"  |  {out['hands']:,} hands, biggest {out['biggest']:,}"
    )
    if not out["pots"]:
        typer.echo("(no pots that big)")
        return
    if out["over"] > len(out["pots"]):
        typer.echo(f"showing the {len(out['pots'])} biggest")
    typer.echo("")
    for h in out["pots"]:
        bb = f"{h['pot_bb']:.0f}bb" if h["pot_bb"] is not None else "--"
        who = "chopped" if h["chopped"] else (
            f"{h['winner']} +{h['won']:,}" + (f" vs {h['loser']} {h['lost']:,}" if h["loser"] else "")
        )
        board = " ".join(h["board"]) or "no flop"
        short = "" if h["complete"] else "  (log cut short)"
        typer.echo(
            f"{h['pot']:>7,} {bb:>7}  {(h['ts'] or '')[:16]:<17}{who:<34}{board}{short}"
        )


@app.command()
def review(
    alias: str,
    db: Path = DbOpt,
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    filter_: str = typer.Option(None, "--filter", help="e.g. 'srp,vs=alex'"),
    kind: str = typer.Option(
        None, "--kind", help="One flag: " + ", ".join(REVIEW_KINDS)
    ),
    unreviewed: bool = typer.Option(
        False, "--unreviewed", help="Only hands not yet marked reviewed."
    ),
    noted: bool = typer.Option(
        False, "--noted", help="Only hands you have written a note on."
    ),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Hands worth reviewing: missed bluffs, missed value, failed bluffs, and bad beats.

    Newest first, a check mark against the ones already marked with `pnt reviewed`,
    and whatever `pnt note` wrote down on its own line underneath. The same rows
    the chart's Hand review and Bad beats views list; SPEC.md, "Hand review",
    defines each flag.
    """
    if kind is not None and kind not in REVIEW_KINDS:
        raise typer.BadParameter(f"unknown kind {kind!r}. Known: {', '.join(REVIEW_KINDS)}", param_hint="--kind")
    conn = connect(db)
    try:
        pred = parse_filter(filter_, display_names(conn), tag_resolver(conn)) if filter_ else None
    except ValueError as exc:
        raise typer.BadParameter(str(exc), param_hint="--filter") from exc
    try:
        out = review_hand_list(conn, alias, game, pred)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    if kind is not None:
        out["hands"] = [h for h in out["hands"] if h["kind"] == kind]
    if unreviewed:
        out["hands"] = [h for h in out["hands"] if not h["reviewed"]]
    if noted:
        out["hands"] = [h for h in out["hands"] if h["note"]]
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return
    if filter_:
        typer.echo(f"filter: {filter_}")
    typer.echo(
        f"{out['examined']} hands, {out['showdowns']} showdowns, {out['known_showdowns']} with every hand shown"
    )
    typer.echo(
        "  ".join(f"{REVIEW_LABELS[k]} {n}" for k, n in out["counts"].items())
        + f"  |  reviewed {out['reviewed']}, noted {out['noted']}"
    )
    sk = out["skipped"]
    if sk["cards_unknown"] or sk["stack_unknown"]:
        typer.echo(
            f"skipped: {sk['cards_unknown']} showdown(s) with a mucked hand,"
            f" {sk['stack_unknown']} with a stack unknown"
        )
    typer.echo("")
    if not out["hands"]:
        typer.echo("(no hands)")
        return
    for h in out["hands"]:
        pot = f"{h['pot_bb']:.0f}bb" if h["pot_bb"] is not None else f"{h['pot']}"
        seen = "x" if h["reviewed"] else " "
        typer.echo(f"{seen} #{h['hand_number']:<5}{REVIEW_LABELS[h['kind']]:<17}pot {pot:>6}  {h['why']}")
        # Your own words, indented under the flag's. A note can run to several
        # lines, and every one of them is yours, so none of it is truncated.
        for line in (h["note"] or "").splitlines():
            typer.echo(f"    | {line}")


@app.command()
def reviewed(
    game: str = typer.Argument(None, help="The game_id. Omit to list every mark."),
    hand_number: int = typer.Argument(None, help="The hand number, as the log names it."),
    db: Path = DbOpt,
    undo: bool = typer.Option(False, "--undo", help="Clear the mark instead of setting it."),
) -> None:
    """Mark a hand as reviewed, so `pnt review` and the chart can set it aside.

    With no arguments, lists what is marked. The mark is on the hand, keyed the way
    the log names it, so it survives a rebuild and shows up on every player's review
    of that hand.
    """
    conn = connect(db)
    if game is None or hand_number is None:
        if game is not None or hand_number is not None:
            raise typer.BadParameter("give both a game_id and a hand number, or neither")
        marks = reviewed_marks(conn)
        if not marks:
            typer.echo("(nothing marked reviewed)")
            return
        for (g, n), at in sorted(marks.items()):
            typer.echo(f"{g}  #{n:<6}{at}")
        return
    try:
        at = mark_reviewed(conn, game, hand_number, not undo)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    typer.echo(f"#{hand_number} {game}: " + (f"reviewed {at}" if at else "mark cleared"))


@app.command()
def note(
    game: str = typer.Argument(None, help="The game_id. Omit to list every note."),
    hand_number: int = typer.Argument(None, help="The hand number, as the log names it."),
    text: str = typer.Argument(None, help="What went wrong. Omit to print the note as it stands."),
    db: Path = DbOpt,
    clear: bool = typer.Option(False, "--clear", help="Delete the note instead of writing one."),
) -> None:
    """Write down what you found in a hand, so the next review has it beside the flag.

    With no arguments, lists every note. With a game and a hand but no text, prints
    that hand's note. Writing again replaces what is there -- a note is a document,
    not a log -- and the mark from `pnt reviewed` is separate: neither command
    touches the other's.

        pnt note pgl051Pj7uqrht2HJB-JPZlcd 161 "turn barrel had no fold equity"
        pnt note pgl051Pj7uqrht2HJB-JPZlcd 161 --clear
        pnt note
    """
    conn = connect(db)
    if game is None or hand_number is None:
        if game is not None or hand_number is not None:
            raise typer.BadParameter("give both a game_id and a hand number, or neither")
        rows = hand_notes(conn)
        if not rows:
            typer.echo("(nothing noted)")
            return
        for (g, n), v in sorted(rows.items()):
            typer.echo(f"{g}  #{n:<6}{v['noted_at']}")
            for line in v["note"].splitlines():
                typer.echo(f"    | {line}")
        return
    if clear and text is not None:
        raise typer.BadParameter("--clear deletes the note; it takes no text")
    if text is None and not clear:
        row = note_of(conn, game, hand_number)
        typer.echo(row["note"] if row else "(no note on that hand)")
        return
    try:
        row = set_note(conn, game, hand_number, None if clear else text)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    typer.echo(f"#{hand_number} {game}: " + (f"noted {row['noted_at']}" if row else "note cleared"))


@app.command("player-note")
def player_note(
    alias: str = typer.Argument(None, help="The player, by alias. Omit to list every note."),
    text: str = typer.Argument(None, help="What you know about them. Omit to print the note."),
    db: Path = DbOpt,
    clear: bool = typer.Option(False, "--clear", help="Delete the note instead of writing one."),
) -> None:
    """Write down what you know about a player, for the HUD to show beside their stats.

    The player-sized twin of `pnt note`: with no arguments, lists every note; with
    an alias and no text, prints theirs. Writing again replaces it. The note is the
    canonical player's, so it follows them across devices, and a merge appends the
    merged player's note to it rather than dropping it.

        pnt player-note alex "tanks then jams with air; never folds the river"
        pnt player-note alex --clear
        pnt player-note
    """
    conn = connect(db)
    if alias is None:
        rows = player_notes(conn)
        if not rows:
            typer.echo("(nothing noted)")
            return
        for name, v in rows.items():
            typer.echo(f"{name}  {v['noted_at'] or ''}".rstrip())
            for line in v["note"].splitlines():
                typer.echo(f"    | {line}")
        return
    if clear and text is not None:
        raise typer.BadParameter("--clear deletes the note; it takes no text")
    if text is None and not clear:
        row = conn.execute("SELECT notes FROM players WHERE alias = ?", (alias,)).fetchone()
        if row is None:
            typer.echo(f"unknown alias: {alias!r}", err=True)
            raise typer.Exit(1)
        typer.echo((row["notes"] or "").strip() or "(no note on that player)")
        return
    try:
        row = set_player_note(conn, alias, None if clear else text)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    typer.echo(f"{alias}: " + (f"noted {row['noted_at']}" if row else "note cleared"))


def _print_grid(grid: dict) -> None:
    """13x13 chart, one cell as `LABEL n`. A dot means never shown in this spot."""
    for row in grid["rows"]:
        typer.echo(
            " ".join(
                f"{label:<4}{grid['cells'][label]['n'] or '.':>3}" for label in row
            )
        )


def _print_composition(comp: dict) -> None:
    typer.echo(f"{'class':<24}{'n':>5}{'pct':>7}{'won':>5}{'net bb':>9}")
    typer.echo("-" * 50)
    for c in comp["classes"]:
        typer.echo(
            f"{c['class']:<24}{c['n']:>5}{_fmt(c['pct']):>7}{c['won']:>5}{c['net_bb']:>9}"
        )


@app.command("range")
def range_cmd(
    alias: str,
    db: Path = DbOpt,
    filter_: str = typer.Option(
        None, "--filter", help="The spot or line, e.g. 'opener,open_bb>=4,srp,cbet_flop'"
    ),
    by: str = typer.Option(
        "preflop", "--by", help="'preflop' for the 169-cell chart, 'made' for hand strength."
    ),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """What a player *had* in a spot, from the hands where their cards were shown.

    Coverage is the honest part: cards are only known at showdown, so the chart
    sees the hands that got there and not the ones that folded on the way.
    """
    if by not in ("preflop", "made"):
        raise typer.BadParameter("--by must be 'preflop' or 'made'")
    conn = connect(db)
    try:
        facts = facts_for(conn, alias, game)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    if filter_:
        try:
            pred = parse_filter(filter_, display_names(conn), tag_resolver(conn))
        except ValueError as exc:
            raise typer.BadParameter(str(exc)) from exc
        facts = [f for f in facts if pred(f)]

    out = range_grid(facts) if by == "preflop" else composition(facts)
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return

    typer.echo(f"{alias}  filter: {filter_ or '(none)'}")
    typer.echo(
        f"hands in this spot: {out['hands']}   cards known: {out['known']}"
        f"   coverage: {_fmt(out['coverage'])}%"
    )
    r = out.get("raise")
    if r:
        typer.echo(
            f"preflop raise-to (bb), all {r['n']} raised hands: median {r['median']}"
            f"  mean {r['mean']}  mode {_fmt(r['mode'])}  min {r['min']}  max {r['max']}"
        )
    typer.echo("")
    if by == "preflop":
        _print_grid(out)
    else:
        _print_composition(out)


@app.command()
def sizing(
    alias: str,
    db: Path = DbOpt,
    street: str = typer.Option("flop", "--street", help="flop, turn or river."),
    kind: str = typer.Option(
        "cbet",
        "--kind",
        help="'cbet' their c-bets, 'bet' every first bet, 'faced_cbet' the c-bets they faced.",
    ),
    filter_: str = typer.Option(None, "--filter", help="The spot, e.g. 'srp,flop=ace_high'"),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """What a player had at each bet size: what they bet small with, what they overbet with.

    Each size lists the made hands that were shown, so read coverage first: the
    bluffs at any size are the hands that folded out before showdown.
    """
    if kind not in SIZING_KINDS:
        raise typer.BadParameter(f"--kind must be one of: {', '.join(SIZING_KINDS)}")
    conn = connect(db)
    try:
        facts = facts_for(conn, alias, game)
        if filter_:
            pred = parse_filter(filter_, display_names(conn), tag_resolver(conn))
            facts = [f for f in facts if pred(f)]
        out = sizing_tells(facts, street, kind)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return

    spot = {"cbet": "c-bet chances", "bet": "bets", "faced_cbet": "c-bets faced"}[kind]
    typer.echo(f"{alias}  {street} {kind}  filter: {filter_ or '(none)'}")
    typer.echo(f"hands in this spot: {out['hands']}   {spot}: {out['spot']}\n")
    for b in out["blocks"]:
        line = f"{b['size']:<8}{b['n']:>5}x  {_fmt(b['pct']):>5}% of {spot}"
        if kind == "faced_cbet" and b["n"]:
            line += f"   fold {_fmt(b['fold'])}%  call {_fmt(b['call'])}%  raise {_fmt(b['raise'])}%"
        if b["n"]:
            line += f"   shown {b['known']} ({_fmt(b['coverage'])}%)"
        typer.echo(line)
        if b["classes"]:
            _print_composition(b)
        typer.echo("")


@app.command()
def tags(
    alias: str = typer.Argument(None, help="One player; every player when omitted."),
    db: Path = DbOpt,
    filter_: str = typer.Option(None, "--filter", help="Judge the tags inside a spot, e.g. 'players>=4'"),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    min_hands: int = typer.Option(1, "--min-hands"),
    basis: str = typer.Option("pool", "--basis", help="'pool': against the other players; 'fixed': the fixed cuts."),
    show_pool: bool = typer.Option(False, "--pool", help="Print each rule's pool baseline instead."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Archetype and exploit tags per player, with the count behind each one.

    Every tag names the spot filter that puts its hands on the chart. Tags built
    from shown hands say so: cards are known at showdown, so the bluffs that got
    through are the hands missing from that evidence. Each rule is judged against
    the other players' rates (SPEC.md, "Pool baseline") unless `--basis fixed`.
    """
    from .stats.pool import owners, pool_for, pool_from_facts

    if basis not in ("pool", "fixed"):
        raise typer.BadParameter("--basis is 'pool' or 'fixed'")
    if show_pool and basis == "fixed":
        raise typer.BadParameter("--pool prints the pool's baseline, which --basis fixed does not use")
    conn = connect(db)
    spot_pool = bool(filter_) and basis == "pool"
    try:
        pred = parse_filter(filter_, display_names(conn), tag_resolver(conn)) if filter_ else None
        if alias:
            identities_of(conn, alias)  # raises on an alias that does not exist
        # Everyone's hands are derived only to list everyone or to pool a filtered
        # spot; one player's tags otherwise read their own hands and the stored pool.
        everyone = None
        if spot_pool or (alias is None and not show_pool):
            grouped, aliases, _ = facts_by_player(conn, game)
            everyone = sorted(((aliases[pid], facts) for pid, facts in grouped.items()), key=lambda p: -len(p[1]))
            if pred is not None:
                everyone = [(a, [f for f in fs if pred(f)]) for a, fs in everyone]
        players: list[tuple[str, list]] = []
        if show_pool:
            pass  # the baseline only: no player's own tags
        elif alias is None:
            players = everyone
        elif everyone is not None:
            players = [(alias, dict(everyone).get(alias, []))]  # a known player with no hands here
        else:
            facts = facts_for(conn, alias, game)
            players = [(alias, [f for f in facts if pred(f)] if pred is not None else facts)]
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    pool = None
    if basis == "pool":
        pool = pool_from_facts(dict(everyone), owners(conn), f"spot: {filter_}") if spot_pool else pool_for(conn, game)
    if show_pool:
        base = pool.baseline(alias)
        if as_json:
            typer.echo(json.dumps({k: {"pct": b.pct, "players": b.players, "spread": list(b.spread)}
                                   for k, b in sorted(base.items())}, indent=2))
            return
        typer.echo(f"pool baseline ({len(pool.players)} players{f', without {alias}' if alias else ''}):")
        for k, b in sorted(base.items()):
            typer.echo(f"  {k:<20} {b.pct:>5}%  middle half {b.spread[0]}-{b.spread[1]}%  ({b.players} players)")
        return
    rows = []
    for name, facts in players:
        if len(facts) < min_hands:
            continue
        rows.append({"player": name, "filter": filter_, **tags_for(facts, pool, name)})
    if alias and not rows:
        n = len(players[0][1])
        where = "".join([" in this spot" if filter_ else "", " in this game" if game else ""])
        skipped = f"{n} hand{'' if n == 1 else 's'}{where}, fewer than --min-hands {min_hands}"
        if as_json:
            typer.echo(json.dumps({"player": alias, "filter": filter_, "hands": n, "skipped": skipped}, indent=2))
        else:
            typer.echo(f"{alias}: {skipped}")
        return
    if as_json:
        typer.echo(json.dumps(rows if not alias else rows[0], indent=2))
        return
    for row in rows:
        arch = row["archetype"]
        p = row["profile"]
        typer.echo(f"{row['player']}  {arch['label'] if arch else '(too few hands for an archetype)'}  {p['hands']} hands")
        for t in row["tags"]:
            if t["kind"] == "archetype":
                continue
            mark = " (fixed cut)" if t["kind"] == "exploit" and t.get("basis") == "fixed" else ""
            typer.echo(f"  {t['label']:<20} {_fmt(t['pct']):>5}% of {t['n']:<5} {t['tip']}{mark}")
        for t in row["streaky"]:
            c = t["carried_by"]
            typer.echo(
                f"  ({t['label']})".ljust(22) + f" {_fmt(t['pct']):>5}% of {t['n']:<5} one session only: "
                f"gone without the {c['hands']}-hand game {c['game_id']} ({c['sessions']} sessions in all)"
            )
        typer.echo("")


@app.command()
def misses(db: Path = DbOpt, limit: int = 20) -> None:
    """Log lines the grammar did not recognize. Empty means the parse was total."""
    conn = connect(db)
    rows = conn.execute(
        "SELECT game_id, ord, reason, entry FROM parse_misses LIMIT ?", (limit,)
    ).fetchall()
    total = conn.execute("SELECT COUNT(*) FROM parse_misses").fetchone()[0]
    typer.echo(f"{total} parse miss(es)")
    for r in rows:
        typer.echo(f"  [{r['reason']}] {r['entry'][:120]}")


@app.command()
def redact(
    paths: list[str] | None = PathsArg,
    out: Path = OutOpt,
    log_dir: Path | None = LogDirOpt,
    audit: bool = AuditOpt,
    anonymize: bool = AnonymizeOpt,
    aliases: Path | None = AnonAliasesOpt,
    labels: Path | None = AnonLabelsOpt,
) -> None:
    """Write publishable copies of your logs with your unshown hole cards removed.

    A raw export names your cards on every hand you were dealt in, folds included.
    This keeps a `Your hand is` entry only where the same two cards also appear in
    a `shows a` entry for that hand -- cards the table already saw -- and drops the
    rest. Everything else in the log is copied byte for byte.

    The copies are still importable: `pnt import` infers hero from showdowns, which
    is exactly what survives. Nothing is written over your originals.

    `--audit` skips writing and checks files instead. Run it on the folder you are
    about to commit; anything it prints is a hand you did not show.

    `--anonymize` also replaces every player's name and PokerNow ID, and each game's
    ID, with stand-ins (pnt/logfmt/anonymize.py): for logs going to people who were
    not at the table. `--aliases` carries an alias file across with them, and
    `--labels` names chosen players for a label (`Fish`) instead of a number.
    """
    folder = log_dir or LOG_DIR
    expanded = _expand(paths, folder)
    if aliases is not None and not aliases.is_file():
        raise typer.BadParameter(f"no alias file at {aliases}", param_hint="--aliases")
    if labels is not None and not labels.is_file():
        raise typer.BadParameter(f"no labels file at {labels}", param_hint="--labels")

    if audit:
        leaks = [line for p in expanded for line in rd.audit(Path(p))]
        for line in leaks:
            typer.echo(line)
        typer.echo(
            f"{len(expanded)} file(s): {len(leaks)} unshown hole-card entr"
            f"{'y' if len(leaks) == 1 else 'ies'}"
        )
        raise typer.Exit(1 if leaks else 0)

    out = out.resolve()
    sources = {Path(p).resolve().parent for p in expanded}
    if out in sources:
        raise typer.BadParameter(
            f"--out {out} is where the originals live; pick a different folder"
        )
    if out == BUNDLED_LOG_DIR.resolve() and not anonymize:
        raise typer.BadParameter(
            f"--out {out} ships inside the package; only --anonymize copies go there"
        )

    import tempfile

    hero_hands = kept = 0
    # Anonymized, the redacted copies are a step on the way: they go to a scratch
    # folder, and only their anonymized versions reach --out.
    with tempfile.TemporaryDirectory() as scratch:
        stage = Path(scratch) if anonymize else out
        names = anon.Pseudonyms(
            aliases=anon.read_aliases(aliases) if aliases else None,
            labels=anon.read_labels(labels) if labels else None,
        )
        for path in expanded:
            src = Path(path)
            p = rd.redact_file(src, stage / src.name)
            hero_hands += p.hero_hands
            kept += p.kept
            typer.echo(f"{src.name}: removed {p.dropped} of {p.hero_hands} hole-card entries")
            if anonymize:
                anon.anonymize_file(stage / src.name, out, names)
        if anonymize:
            typer.echo(f"anonymized {len(names.ids)} player ID(s) and {len(names.names)} name(s)")
            if aliases:
                n = anon.anonymize_aliases(aliases, out / "aliases.csv", names)
                typer.echo(f"carried {n} alias row(s) over to {out / 'aliases.csv'}")

    leaks = [line for f in sorted(out.glob(LOG_GLOB)) for line in rd.audit(f)]
    if leaks:  # redact_file already refuses to write a partial redaction
        for line in leaks:
            typer.echo(line)
        raise typer.Exit(1)
    typer.echo("")
    typer.echo(
        f"{len(expanded)} file(s) -> {out}\n"
        f"{kept} of {hero_hands} hands kept their hole cards (the showdowns); "
        f"{hero_hands - kept} redacted. Verified: no unshown holding remains."
    )


@app.command()
def serve(
    db: Path = DbOpt,
    host: str = "127.0.0.1",
    port: int = svc.DEFAULT_PORT,
) -> None:
    """Run the local API that the HUD and your analysis scripts read.

    Lasts until the terminal closes. To keep it running in the background instead,
    use `pnt service install`.
    """
    # A second server on the port would split requests with the first (see
    # svc.bind): usually the background service, which is already doing this job.
    busy = f"error: something already answers on http://{host}:{port}. "
    if svc.port_in_use(host, port):
        body = svc.health(host, port)
        if body is not None and body.get("pid") is not None:
            typer.echo(busy + f"The tracker is already running there (pid {body['pid']}; "
                       "`pnt service status`).", err=True)  # fmt: skip
        else:
            typer.echo(busy + svc.port_holder_hint(port).capitalize() + ".", err=True)
        raise typer.Exit(1)
    typer.echo(f"range chart: http://{host}:{port}/chart   api docs: http://{host}:{port}/docs")
    _rebuild_hint(str(db))
    try:
        svc.run_server(db, host, port)
    except OSError as exc:  # taken between the check and the bind
        typer.echo(busy + f"({exc}) " + svc.port_holder_hint(port).capitalize() + ".", err=True)
        raise typer.Exit(1) from exc


def _service_name() -> str:
    """What `pnt service` manages here, for its messages."""
    if sys.platform == "darwin":
        return f"launch agent {svc.AGENT_LABEL} ({svc.AGENT_PLIST})"
    return f"task {svc.TASK_NAME!r}"


def _svc(fn, *args, **kwargs):
    """Call into `pnt.service`, turning its errors into a one-line CLI failure."""
    try:
        return fn(*args, **kwargs)
    except svc.ServiceError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(1) from exc


@service_app.command("install")
def service_install(
    db: Path = DbOpt, host: str = svc.DEFAULT_HOST, port: int = svc.DEFAULT_PORT
) -> None:
    """Run the server in the background for this user, starting now.

    A Task Scheduler task on Windows, a launch agent on macOS.

    Re-run to change --db or --port: it replaces the existing task. --db must be
    the database you actually use; the task does not start in this folder.
    """
    busy = svc.port_in_use(host, port)
    # Recorded before the task starts, since `service run` prefers the recorded one.
    # Even before it exists: a missing choice falls back to the task's --db, which is
    # this same path, whereas leaving an older choice in place would win over it.
    # Put back if the install fails: the task already installed reads it too.
    before = local_config.get("db")
    local_config.put("db", str(db.resolve()))
    try:
        interpreter = _svc(svc.install, db, host, port)
    except BaseException:
        local_config.put("db", before)
        raise
    typer.echo(f"registered {_service_name()}: starts at login, restarts on crash")
    typer.echo(f"  database:    {db.resolve()}")
    typer.echo(f"  interpreter: {interpreter}")
    typer.echo(f"  log:         {svc.LOG_FILE}")
    if not svc.loopback(host):
        typer.echo("\n" + svc.exposed_warning(host, port), err=True)
    # macOS guards these folders per program, and the agent's Python is not the
    # Terminal that may already have been allowed in. Refused, it can neither read
    # the exports nor save live-captured logs there.
    home = Path.home()
    guarded = [home / "Downloads", home / "Documents", home / "Desktop"]
    folder = next((p for p in (LOG_DIR, *LOG_DIR.parents) if p in guarded), None)
    if sys.platform == "darwin" and folder is not None:
        typer.echo(
            f"\nmacOS may ask whether Python can use your {folder.name} folder: allow it,"
            " or the server cannot read or save logs there."
        )
    if busy:
        typer.echo(
            f"\nport {port} is already in use, probably by a `pnt serve` in a terminal."
            " The service is waiting and takes over as soon as that one stops."
        )
        return
    body = svc.wait_for_health(host, port)
    if body is None:
        typer.echo("\nnot answering yet. Check `pnt service log`.")
    else:
        typer.echo(f"\nup: http://{host}:{port}/chart  ({body['hands']} hands)")


@service_app.command("uninstall")
def service_uninstall() -> None:
    """Stop the background server and remove the task. The database is untouched."""
    removed = _svc(svc.uninstall)
    typer.echo(f"removed {_service_name()}" if removed else "not installed")


@service_app.command("start")
def service_start() -> None:
    """Start the background server now. It also starts at every login."""
    _svc(svc.start)
    typer.echo("started")


@service_app.command("stop")
def service_stop() -> None:
    """Stop the background server until `pnt service start` or the next login."""
    _svc(svc.stop)
    typer.echo("stopped")


@service_app.command("restart")
def service_restart(host: str = svc.DEFAULT_HOST, port: int = svc.DEFAULT_PORT) -> None:
    """Restart it. Needed after pulling code changes: a running server keeps the old code.

    Stored hands this code would store differently are rebuilt while the server is
    down (`pnt rebuild --if-stale`), so after a `git pull` or a `pnt update` there is
    nothing else to run.
    """
    # The database the service serves: the one chosen on the front page wins.
    db = local_config.database(DEFAULT_DB)
    body = _svc(svc.restart, host=host, port=port, while_stopped=lambda: _rebuild_if_stale(db))
    typer.echo(f"restarted: pid {body['pid']}, {body['hands']} hands, db {body['db']}")
    _rebuild_hint(body.get("db"))


def _rebuild_reasons(path: str | None) -> list[str]:
    """What this code would store differently in the database at `path`, one
    phrase each; empty when nothing. One `pnt rebuild` covers them all."""
    import sqlite3

    from .ingest.importer import needs_game_modes_rebuild, needs_parse_rebuild
    from .logfmt.parser import PARSE_CHANGE
    from .stats.timing import needs_rebuild

    if not path or not Path(path).exists():
        return []
    try:
        conn = connect(path, init=False)
        try:
            return [
                why
                for stale, why in (
                    # SPEC.md, "Timing tells".
                    (needs_rebuild, "time every decision (the chart's Timing view)"),
                    # SPEC.md, "Money": PLO, Double Board, bomb pots and the Nit Game.
                    (needs_game_modes_rebuild, "read PLO, Double Board, bomb pots and the Nit Game"),
                    # parser.PARSE_VERSION: a parser change the data's shape cannot show.
                    (needs_parse_rebuild, PARSE_CHANGE),
                )
                if stale(conn)
            ]
        finally:
            conn.close()
    except sqlite3.Error:
        return []


def _rebuild_hint(path: str | None) -> None:
    """Say so when the database holds hands this code would store differently.

    `pnt update` rebuilds them itself (`pnt rebuild --if-stale`); this is for a
    restart or a `pnt serve` after a `git pull`, or an update whose rebuild did
    not finish.
    """
    reasons = _rebuild_reasons(path)
    if reasons:
        typer.echo(
            f"This version can {' and '.join(reasons)}. Run `pnt rebuild` once to apply it to the"
            " hands already stored; it re-reads them from the stored logs."
        )


@service_app.command("status")
def service_status(host: str = svc.DEFAULT_HOST, port: int = svc.DEFAULT_PORT) -> None:
    """Whether the task is installed and running, and whether the server answers."""
    state = _svc(svc.task_state)
    typer.echo(f"task:   {state or 'not installed'}")
    body = svc.health(host, port)
    if body is None:
        typer.echo(f"server: not answering on http://{host}:{port}")
    else:
        pid = body.get("pid", "? (older than this install: `pnt service restart`)")
        typer.echo(f"server: up on http://{host}:{port}  pid {pid}  {body['hands']} hands  db {body['db']}")
    typer.echo(f"log:    {svc.LOG_FILE}")
    if sys.platform == "darwin":
        # Where a crash before the server opened its own log ends up.
        typer.echo(f"        {svc.AGENT_LOG_FILE} (launchd)")


@service_app.command("log")
def service_log(lines: int = typer.Option(40, "--lines", "-n")) -> None:
    """The last lines of the background server's log."""
    if not svc.LOG_FILE.exists():
        typer.echo(f"no log yet at {svc.LOG_FILE}")
        return
    for line in svc.tail(svc.LOG_FILE, lines):
        typer.echo(line)


@service_app.command("run", hidden=True)
def service_run(
    db: Path = DbOpt, host: str = svc.DEFAULT_HOST, port: int = svc.DEFAULT_PORT
) -> None:
    """What the scheduled task executes: the supervised server, logging to a file.

    The database chosen on the front page wins over the task's --db, which is only
    what it was installed with; that one is the fallback if the chosen one is gone.
    """
    svc.run_service(local_config.database(db), host, port)


@alias_app.command("list")
def alias_list(db: Path = DbOpt) -> None:
    """Every canonical player and the PokerNow IDs mapped to them."""
    conn = connect(db)
    for r in conn.execute(
        "SELECT p.alias, COUNT(pi.pn_id) n, GROUP_CONCAT(pi.pn_id, ', ') ids,"
        " GROUP_CONCAT(DISTINCT pi.last_seen_name) names"
        " FROM players p JOIN player_identities pi ON pi.player_id = p.player_id"
        " GROUP BY p.player_id ORDER BY p.alias"
    ):
        typer.echo(f"{r['alias']:24s} {r['n']} id(s): {r['ids']}")
        if r["names"] and r["names"] != r["alias"]:
            typer.echo(f"{'':24s}   seen as: {r['names']}")


@alias_app.command("merge")
def alias_merge(source: str, target: str, db: Path = DbOpt) -> None:
    """Merge SOURCE into TARGET -- use when one human played from two devices.

    Nothing is recomputed: because no statistic is stored, repointing the identity
    rows *is* the merge.
    """
    conn = connect(db)
    try:
        moved = merge_players(conn, source, target)
    except ValueError as exc:  # an unknown alias, or merging one into itself
        raise typer.BadParameter(str(exc)) from exc
    typer.echo(f"moved {len(moved)} identity row(s) from {source!r} to {target!r}")
    if moved:
        # Printed because the merge cannot be undone without them: the source
        # player row is gone, so this list is the only record of what was behind it.
        typer.echo(f"  ids: {' '.join(moved)}")
        typer.echo(f"  undo: pnt alias split {' '.join(moved)} --alias {source}")


@alias_app.command("rename")
def alias_rename(old: str, new: str, db: Path = DbOpt) -> None:
    """Rename a canonical player."""
    try:
        rename_player(connect(db), old, new)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    typer.echo(f"{old!r} -> {new!r}")


@alias_app.command("split")
def alias_split(
    pn_ids: list[str] = PnIdsArg,
    alias: str = AliasOpt,
    db: Path = DbOpt,
) -> None:
    """Move PokerNow IDs onto a new player. The inverse of `alias merge`.

    Undoes a merge (the merge prints the exact command), and separates two humans
    who were joined by mistake.
    """
    try:
        n = split_identities(connect(db), pn_ids, alias)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    typer.echo(f"moved {n} identity row(s) to {alias!r}")


@alias_app.command("export")
def alias_export(path: Path = AliasFileArg, db: Path = DbOpt) -> None:
    """Write every PokerNow ID and its alias to a CSV that rebuilds your merges.

    Merges and renames are the one thing a re-import cannot rebuild; this file is
    how they survive a fresh database. `pnt alias import` reads it back.
    """
    if path.resolve() == BUNDLED_ALIASES.resolve():
        raise typer.BadParameter(
            f"{path} belongs to the bundled sample and ships with the package; "
            "pick another path"
        )
    pairs = export_aliases(connect(db))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh, lineterminator="\n")
        writer.writerow(["pn_id", "alias"])
        writer.writerows(pairs)
    typer.echo(f"wrote {len(pairs)} id(s) across {len({a for _, a in pairs})} player(s) to {path}")


@alias_app.command("import")
def alias_import(path: Path = AliasFileArg, db: Path = DbOpt) -> None:
    """Apply a CSV from `pnt alias export`: every known ID moves to its alias.

    Safe to re-run. IDs not in the database yet are skipped -- import their logs,
    then run this again.
    """
    if not path.exists():
        raise typer.BadParameter(f"no alias file at {path}")
    with path.open(newline="", encoding="utf-8") as fh:
        pairs = [(r["pn_id"], r["alias"]) for r in csv.DictReader(fh)]
    moved, unknown = apply_aliases(connect(db), pairs)
    typer.echo(f"moved {moved} identity row(s); {unknown} id(s) not in this database yet")


#: `pnt results`: one row's figures, after its label.
_RESULTS_COLUMNS = [
    ("hands", "Hands", 7),
    ("net_bb", "Net bb", 10),
    ("bb_per_100", "bb/100", 9),
    ("vpip_pct", "VPIP%", 7),
    ("saw_flop_pct", "Flop%", 7),
    ("wtsd", "WTSD", 6),
    ("wsd", "W$SD", 6),
]


@app.command()
def results(
    alias: str,
    db: Path = DbOpt,
    filter_: str = typer.Option(None, "--filter", help="The spot, e.g. 'position=BTN'"),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Where a player's big blinds went: by pot type and who raised it, by seat, by position.

    Each row ends with the filter that finds its hands, to add to the spot. The
    worst bb/100 among rows of enough hands is marked; incomplete hands count as
    hands but in no bb figure.
    """
    from .stats.results import results_breakdown

    conn = connect(db)
    try:
        facts = facts_for(conn, alias, game, "money")  # Results counts PLO's money
        if filter_:
            pred = parse_filter(filter_, display_names(conn), tag_resolver(conn))
            facts = [f for f in facts if pred(f)]
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    out = results_breakdown(facts)
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return

    def line(r: dict, indent: int = 0) -> str:
        text = (" " * indent + r["label"])[:23].ljust(24)
        text += "".join(_fmt(r.get(c)).rjust(w) for c, _, w in _RESULTS_COLUMNS)
        spot = r["filter"] if r["filter"] is not None else "(no filter term)"
        return text + "   " + spot + ("   <- worst" if r["worst"] else "")

    typer.echo(f"{alias}  filter: {filter_ or '(none)'}")
    typer.echo(line(out["total"]))
    typer.echo(f"worst: the lowest bb/100 of {out['min_hands']}+ hands with a known result\n")
    for table in out["tables"]:
        header = table["title"].ljust(24) + "".join(h.rjust(w) for _, h, w in _RESULTS_COLUMNS)
        typer.echo(header + "   filter")
        typer.echo("-" * (len(header) + 9))
        for r in table["rows"]:
            typer.echo(line(r))
            for role in r.get("roles", ()):
                typer.echo(line(role, 2))
        typer.echo("")


@app.command("lines")
def lines_cmd(
    alias: str,
    db: Path = DbOpt,
    mode: str = typer.Option(
        "own", "--mode", help="'own' groups by their own line, 'action' by the whole street."
    ),
    street: str = typer.Option(None, "--street", help="One street only: flop, turn or river."),
    filter_: str = typer.Option(None, "--filter", help="The spot, e.g. 'srp,pfa'"),
    min_n: int = typer.Option(LINES_MIN, "--min", help="Hide lines with fewer hands than this."),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Every line a player took after the flop, and what they had when it was shown.

    Each line's hands split into nutted, strong, marginal, draw and air on the board
    of the last street they acted on, as a share of the hands shown. Bluffs that
    got a fold are never shown, so read coverage first. The last column is the
    filter that finds the line's hands, for --filter here or the chart's Spot box.
    """
    if mode not in LINES_MODES:
        raise typer.BadParameter(f"--mode must be one of: {', '.join(LINES_MODES)}")
    conn = connect(db)
    try:
        facts = facts_for(conn, alias, game)
        if filter_:
            pred = parse_filter(filter_, display_names(conn), tag_resolver(conn))
            facts = [f for f in facts if pred(f)]
        out = line_breakdown(facts, mode, street, max(1, min_n))
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return

    what = "own line" if mode == "own" else "whole street"
    typer.echo(f"{alias}  {what}, {'/'.join(out['streets'])}  filter: {filter_ or '(none)'}")
    typer.echo(
        f"hands in this spot: {out['hands']}   shown and rated: {out['known']}"
        f"   coverage: {_fmt(out['coverage'])}%   net: {_fmt(out['net_bb'])} bb"
    )
    hidden = out["hidden"]
    if hidden["groups"]:
        typer.echo(
            f"{hidden['groups']} line(s) under {out['min']} hands hidden ({hidden['hands']} hands)"
        )
    typer.echo("strength: % of the known hands, on the last street they acted on.")
    typer.echo("Bluffs that got a fold are never shown.\n")
    width = max([len("line"), *(len(g["line"]) for g in out["groups"])]) + 2
    head = f"{'line':<{width}}{'n':>6}{'known':>7}{'net bb':>9}" + "".join(f"{t:>9}" for t in TIERS)
    typer.echo(head + "  filter")
    typer.echo("-" * (len(head) + 8))
    for g in out["groups"]:
        row = f"{g['line']:<{width}}{g['n']:>6}{g['known']:>7}{_fmt(g['net_bb']):>9}"
        row += "".join(f"{_fmt(g['tiers'][t]['pct']):>9}" for t in TIERS)
        typer.echo(f"{row}  {g['filter']}")

def _print_bluffs(title: str, out: dict) -> None:
    """One value:bluff table: a row per category, grouped by street."""
    typer.echo(title)
    typer.echo(
        f"{'':<7}{'category':<27}{'n':>6}{'shown':>7}{'cov%':>7}"
        f"{'value':>7}{'marg':>6}{'semi':>6}{'bluff':>6}{'V : B':>10}{'folded':>8}"
    )
    typer.echo("-" * 97)
    street = None
    for r in out["rows"]:
        if r["street"] != street and street is not None:
            typer.echo("")
        c = r["counts"]
        # ASCII for the console: Windows' default code page has no infinity sign.
        ratio = r["ratio_text"].replace("∞", "inf")
        folded = f"{_fmt(r['folded_pct'])}%" if r["folded_pct"] is not None else ""
        typer.echo(
            f"{(r['street'] if r['street'] != street else ''):<7}"
            f"{(('  ' if r['parent'] else '') + r['label'])[:26]:<27}"
            f"{r['n']:>6}{r['known']:>7}{_fmt(r['coverage']):>7}"
            f"{c['value']:>7}{c['marginal']:>6}{c['semi_bluff']:>6}{c['bluff']:>6}"
            f"{ratio:>10}{folded:>8}"
        )
        street = r["street"]


@app.command()
def bluffs(
    alias: str = typer.Argument(None, help="One player; the pool when omitted."),
    pool: bool = typer.Option(False, "--pool", help="The pool too: every player, every hand."),
    db: Path = DbOpt,
    filter_: str = typer.Option(None, "--filter", help="The spot, e.g. 'srp,vs=alex'"),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Value:bluff by kind of aggression: bets by size, check-raises, raises and jams.

    The shown hands of each are read on the board of the street the action was
    made on, by hand strength on that board: value (a value hand there, top pair
    or better on most), marginal (a weaker made hand), semi-bluff (a draw on the
    flop or turn) and bluff (no pair, or a missed draw on the river).
    Bets everyone folded to are never shown, so the shown ratio leans to value;
    `folded` is how many of a bet row's bets got there, as context.
    """
    conn = connect(db)
    try:
        pred = parse_filter(filter_, display_names(conn), tag_resolver(conn)) if filter_ else None
        scopes = []
        if alias:
            scopes.append((alias, facts_for(conn, alias, game)))
        if pool or not alias:
            scopes.append(("pool", pool_facts(conn, game)))
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc

    outs = {
        name: bluff_value([f for f in facts if pred is None or pred(f)], ids=False)
        for name, facts in scopes
    }
    if as_json:
        typer.echo(json.dumps(outs if len(outs) > 1 else next(iter(outs.values())), indent=2))
        return
    for i, (name, out) in enumerate(outs.items()):
        if i:
            typer.echo("")
        _print_bluffs(f"{name}  filter: {filter_ or '(none)'}  hands: {out['hands']}", out)
    typer.echo(
        "\nShown hands only, read on the street of the action. Bets everyone folded to are"
        "\nnever shown, so the ratio leans to value: read coverage, and `folded`, first."
    )


def _print_fold_equity(who: str, out: dict) -> None:
    """Both sides of `fold_equity`, street by street: the bettor's table, then the
    defender's. `*` marks a row that clears its line on at least MIN_SAMPLE hands."""
    def pct(v: float | None) -> str:
        return "--" if v is None else f"{v:.1f}%"

    def table(title: str, rows: list[dict], head: tuple, line: str, gap: str) -> None:
        typer.echo(title)
        typer.echo(f"  {'size':<9}{head[0]:>6}{'fold':>8}{'call':>8}{'raise':>8}"
                   f"{'size':>8}{head[1]:>8}{head[2]:>8}")
        for r in rows:
            if r["n"]:
                mark = " *" if r["judged"] and r[gap] > 0 else ""
                typer.echo(
                    f"  {r['size']:<9}{r['n']:>6}{pct(r['fold']):>8}{pct(r['call']):>8}"
                    f"{pct(r['raise']):>8}{r['median_size']:>8.2f}{pct(r[line]):>8}{r[gap]:>+8.1f}{mark}"
                )

    typer.echo(f"{who}  ({out['hands']} hands)")
    for street, d in out["streets"].items():
        typer.echo("")
        table(f"{street}: bets  (b/e: a pure bluff's break-even; edge = fold - b/e)",
              d["bets"], ("bets", "b/e", "edge"), "break_even", "edge")
        for key, what in (("faced", "bets and raises faced"), ("faced_cbet", "c-bets faced")):
            table(f"{street}: {what}  (over = fold - (100 - MDF))",
                  d[key], ("faced", "MDF", "over"), "mdf", "overfold")


@app.command()
def foldeq(
    alias: str = typer.Argument(None, help="One player; the whole pool when omitted."),
    pool: bool = typer.Option(False, "--pool", help="Also print the whole pool, to compare."),
    db: Path = DbOpt,
    filter_: str = typer.Option(None, "--filter", help="The spot, e.g. 'srp'"),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Fold equity by bet size: how often each size of bet is folded to, against
    the fold rate a pure bluff that size needs, and how often each size is
    defended, against the MDF.

    Size is the median bet in the bucket, as a fraction of the pot. `*` marks a
    bet size that showed a profit as a pure bluff, or a defense that over-folds,
    on at least ten hands.
    """
    conn = connect(db)
    try:
        pred = parse_filter(filter_, display_names(conn), tag_resolver(conn)) if filter_ else None
        results = []
        if alias:
            facts = facts_for(conn, alias, game)
            if pred is not None:
                facts = [f for f in facts if pred(f)]
            results.append((alias, fold_equity(facts)))
        if pool or not alias:
            results.append(("pool", fold_equity(pool_facts(conn, game, pred))))
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    if as_json:
        body = {who: out for who, out in results}
        typer.echo(json.dumps(body if len(body) > 1 else results[0][1], indent=2))
        return
    if filter_:
        typer.echo(f"filter: {filter_}\n")
    for i, (who, out) in enumerate(results):
        if i:
            typer.echo("\n" + "=" * 64 + "\n")
        _print_fold_equity(who, out)


#: `pnt slowplay`: one short heading per column of `slowplay.CATEGORIES`.
_SLOWPLAY_HEADS = {
    "bet": "bet", "raise": "raise", "check_raise": "x-r", "check_call": "x-c", "call": "call",
    "checked": "x", "checked_back": "x-back", "check_fold": "x-f", "fold": "fold", "other": "other",
}


@app.command()
def slowplay(
    alias: str = typer.Argument(None, help="One player; everyone pooled, then ranked, when omitted."),
    db: Path = DbOpt,
    street: str = typer.Option("flop", "--street", help="flop, turn or river."),
    floor: str = typer.Option("set", "--floor", help="The weakest made hand counted: set, two_pair, straight..."),
    filter_: str = typer.Option(None, "--filter", help="The spot, e.g. 'srp,players=2'"),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    min_n: int = typer.Option(5, "--min", help="Pooled: strong hands a player needs to be ranked."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """What they did on a street with a strong made hand: bet it, raised it, or
    slowplayed it with a check or a call.

    One row per made hand from the strongest down to --floor, one column per line.
    Built from shown hands: a strong hand that bet and got folds to is never shown,
    so anyone's slowplay share but your own reads high. Read coverage first.
    """
    from .stats.slowplay import CATEGORIES, by_player
    from .stats.slowplay import slowplay as slowplay_report

    conn = connect(db)
    try:
        pred = parse_filter(filter_, display_names(conn), tag_resolver(conn)) if filter_ else None
        if alias:
            grouped = {0: facts_for(conn, alias, game)}
            aliases = {0: alias}
        else:
            grouped, aliases, _ = facts_by_player(conn, game)
        if pred is not None:
            grouped = {pid: [f for f in facts if pred(f)] for pid, facts in grouped.items()}
        out = slowplay_report([f for facts in grouped.values() for f in facts], street, floor)
        if not alias:
            out["players"] = by_player(grouped, aliases, street, out["floor"], min_n)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    if as_json:
        typer.echo(json.dumps({"player": alias, "filter": filter_, **out}, indent=2))
        return

    keys = [k for k, *_ in CATEGORIES]
    typer.echo(f"{alias or 'everyone'}  {street}, {out['floor']} and up  filter: {filter_ or '(none)'}")
    typer.echo(
        f"in the hand on the {street}: {out['hands']}   cards known: {out['known']} ({_fmt(out['coverage'])}%)"
    )
    typer.echo(
        "shown hands only: a strong hand that bet and got folds to is never shown, so "
        "the slowplay share reads high for anyone whose cards you do not always see.\n"
    )
    header = f"{'made':<16}{'n':>5}" + "".join(f"{_SLOWPLAY_HEADS[k]:>7}" for k in keys) + f"{'slow%':>7}"
    typer.echo(header)
    typer.echo("-" * len(header))
    for row in [*out["rows"], out["total"]]:
        if not row["n"] and row is not out["total"]:
            continue
        cells = "".join(f"{row['cells'][k]['n'] or '.':>7}" for k in keys)
        typer.echo(f"{row['leaf']:<16}{row['n']:>5}{cells}{_fmt(row['slowplay_pct']):>7}")
    if out["total"]["all_in"]:
        typer.echo(f"\n{out['total']['all_in']} more were all in before the {street}, with nothing to decide.")
    typer.echo(f"slowplays: x-c, call, x and x-back. Each cell is a spot filter, "
               f"made_{street}=<made>,line_{street}=<line>; --json prints them.")
    if alias:
        return
    typer.echo(f"\nwho slowplays, of {min_n}+ strong hands acted on:")
    _print_table(out["players"], "player", 16, [
        ("n", "n", 5), ("slowplay", "slow", 6), ("slowplay_pct", "slow%", 7), ("coverage", "cov%", 7),
    ])


@app.command()
def bounties(
    db: Path = DbOpt,
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """The 7-2 bounty ledger: who has collected and paid the side bet, ranked by net,
    and how often you played 72 when you were dealt it.

    The 72 counts are yours only, from the logs you downloaded: anyone else's 72 is
    seen only when it is shown, and a folded one never is.
    """
    from .stats.bounty import ledger

    conn = connect(db)
    out = ledger(conn, game)
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return

    typer.echo(f"7-2 bounties  {game or 'all games'}")
    if not out["players"]:
        typer.echo("(no bounty has been paid)")
    else:
        header = f"{'player':<22}{'won':>5}{'chips':>8}{'paid':>6}{'chips':>8}{'net':>8}{'net bb':>9}{'hands':>7}"
        typer.echo(header)
        typer.echo("-" * len(header))
        for r in out["players"]:
            typer.echo(
                f"{r['player'][:21]:<22}{r['won']['count']:>5}{r['won']['chips']:>8}"
                f"{r['paid']['count']:>6}{r['paid']['chips']:>8}{r['net']['chips']:>+8}"
                f"{_fmt(r['net']['bb']):>9}{r['hands']:>7}"
            )
        t = out["total"]
        typer.echo(f"\n{t['bounties']} bounties, {t['won']} chips changed hands.")
        if out["balance"]:
            typer.echo(f"the ledger is {out['balance']:+} off zero: a payment named someone not dealt in.")
    for h in out["hero"]:
        typer.echo(
            f"\n{h['player']}: dealt 72 {h['dealt_72']} times, played {h['played_72']}"
            f" ({_fmt(h['played_pct'])}%), cards known on {h['known']} of {h['hands']} hands."
            + (f" Showed 72 {h['shown_72']} times in other logs." if h["shown_72"] else "")
        )
        why = "" if h["dealt_filter"] and h["played_filter"] else (
            "   (none: it would also find a 72 they showed in a log they do not own)"
        )
        typer.echo(f"  filters: {h['dealt_filter'] or '(none)'} / {h['played_filter'] or '(none)'}{why}")


@app.command()
def shows(
    alias: str = typer.Argument(..., help="The player."),
    db: Path = DbOpt,
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """The hands a player showed without being asked, and what they were.

    Two-card shows are read on the board as it stood -- a fold on the street they
    folded -- as strong, marginal, draw or air, and split by how the hand ended
    for them. One-card shows are counted only. These are chosen reveals: what
    the player wants you to see, not a sample of their range.
    """
    from .stats.shows import CLASSES, voluntary_shows

    conn = connect(db)
    try:
        out = voluntary_shows(conn, alias, game)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return
    typer.echo(f"{alias}  shown without being asked: {out['shows']} of {out['hands']} hands dealt in")
    typer.echo(f"two cards, classified: {out['two_card']} of {out['shows']} ({_fmt(out['coverage'])}%)"
               f"   one card, counted only: {out['one_card']}")
    fv = out["folded_vs"]
    typer.echo(f"air {_fmt(out['air_pct'])}%   strong {_fmt(out['strong_pct'])}%   "
               f"folded the best hand {fv['ahead']} of {fv['known']} where the winner's cards are known")
    typer.echo("\n".join("- " + n.replace("**", "") for n in out["note"]) + "\n")
    header = f"{'how the hand ended':<32}{'shows':>6}{'1 card':>7}" + "".join(f"{c:>9}" for c in CLASSES)
    typer.echo(header)
    typer.echo("-" * len(header))
    total = {"label": "all", "shows": out["shows"], "one_card": out["one_card"], "classes": out["classes"]}
    for c in [*out["contexts"], total]:
        cells = "".join(f"{c['classes'][k] or '.':>9}" for k in CLASSES)
        typer.echo(f"{c['label']:<32}{c['shows']:>6}{c['one_card'] or '.':>7}{cells}")
    if out["rows"]:
        typer.echo("")
    for r in out["rows"]:
        board = " ".join(r["board"]) or "(preflop)"
        made = ("missed " if r["missed"] else "") + (r["made"] or "")
        what = f"{r['class']}: {made}" if r["class"] else "one card"
        typer.echo(f"  #{r['hand_number']:<5} {r['cards']:<6} {r['context']:<12} {r['street']:<8}"
                   f" {board:<16} {what}   hand {r['hand_id']}")


@app.command()
def h2h(
    alias: str = typer.Argument(None, help="One player's opponents; the pool's matrix when omitted."),
    db: Path = DbOpt,
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Head to head: the big blinds that went between two players.

    A hand with one winner is settled exactly: each loser's chips went to them.
    With several winners each loser's loss is split by what each winner won.
    Positive is what the row's player won from the column's.
    """
    from .stats.h2h import player_h2h, pool_h2h

    conn = connect(db)
    try:
        out = player_h2h(conn, alias, game) if alias else pool_h2h(conn, game)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return
    skipped = out["skipped"]
    short = skipped["incomplete"] + skipped["unbalanced"] + skipped["no_bb"]
    if alias:
        typer.echo(f"{alias}  {out['hands']} hands  net {out['net_bb']:+.1f}bb against the table")
        _print_table(out["rows"], "opponent", 16, [
            ("hands", "hands", 7), ("counted", "money", 7), ("net_bb", "net bb", 9),
            ("showdowns", "SD", 5), ("split_hands", "split", 6),
            ("failed_bluffs", "FB by", 6), ("failed_bluffs_against", "FB vs", 6), ("n", "vs= n", 7),
        ])
        typer.echo(
            "\nmoney: hands whose chips are all there. split: settled by the multiway rule."
            "\nFB by / vs: their failed bluffs into the opponent, and the opponent's into them."
            f"\n{out['failed_bluff_note']}"
            "\nvs= n: the hands `--filter vs=<opponent>` finds, still in when they last acted."
        )
    else:
        players = out["players"]
        names = [p["player"] for p in players]
        width = 7
        typer.echo(f"who pays whom: {out['hands']} hands, bb the row won from the column\n")
        typer.echo(" " * 16 + "".join(n[: width - 1].rjust(width) for n in names) + "total".rjust(9))
        for p in players:
            row = out["cells"][p["player"]]
            cells = "".join(
                (f"{row[n]['net_bb']:+.0f}" if n in row else ".").rjust(width) for n in names
            )
            typer.echo(p["player"][:15].ljust(16) + cells + f"{p['net_bb']:+.0f}".rjust(9))
    if short:
        typer.echo(f"\n{short} hand(s) moved no money: {skipped['incomplete']} incomplete, "
                   f"{skipped['unbalanced']} whose chips do not balance, {skipped['no_bb']} without a big blind.")


#: `pnt winnings`: one session's figures, after its game id.
_WINNINGS_COLUMNS = [
    ("hands", "Hands", 7),
    ("net_bb", "Net bb", 10),
    ("bb_per_100", "bb/100", 9),
    ("red", "Red", 9),
    ("blue", "Blue", 9),
]


@app.command()
def winnings(
    alias: str,
    db: Path = DbOpt,
    filter_: str = typer.Option(None, "--filter", help="The spot, e.g. 'position=BTN'"),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    adjusted: bool = typer.Option(False, "--adjusted", help="Add the all-in adjusted total."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Red line and blue line: net bb won without showdown and at showdown, and per session.

    Blue is every hand they took to showdown, red every other hand; the two add
    up to the total. Incomplete hands count as hands but in no bb figure. --json
    prints every point of the three lines.
    """
    from .stats.winnings import allin_adjusted, winnings_series

    conn = connect(db)
    try:
        facts = facts_for(conn, alias, game, "money")  # as /winnings does
        if filter_:
            pred = parse_filter(filter_, display_names(conn), tag_resolver(conn))
            facts = [f for f in facts if pred(f)]
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    out = winnings_series(facts, allin_adjusted(conn, facts) if adjusted else None)
    if as_json:
        typer.echo(json.dumps({"player": alias, "filter": filter_, **out}, indent=2))
        return

    t = out["totals"]
    typer.echo(f"{alias}  filter: {filter_ or '(none)'}")
    typer.echo(f"hands: {t['hands']}   with a known result: {t['bb_hands']}")
    typer.echo(f"total:  {_fmt(t['net_bb'])} bb   ({_fmt(t['bb_per_100'])} bb/100)")
    for key, label in (("red", "red (no showdown)"), ("blue", "blue (showdown)")):
        line = t[key]
        typer.echo(f"{label + ':':<20}{_fmt(line['net_bb']):>9} bb over {line['bb_hands']} hands"
                   f"   filter: {line['filter']}")
    if "adjusted" in t:
        a = t["adjusted"]
        typer.echo(f"{'all-in adjusted:':<20}{_fmt(a['net_bb']):>9} bb   "
                   f"{a['allin_hands']} all-in showdown(s) paid by equity"
                   + (f", {a['skipped']} skipped (a live hand mucked)" if a["skipped"] else ""))
    typer.echo("\nby session, oldest first:")
    if not out["sessions"]:
        typer.echo("(no rows)")
        return
    header = "game_id".ljust(26) + "date".ljust(12) + "".join(h.rjust(w) for _, h, w in _WINNINGS_COLUMNS)
    typer.echo(header)
    typer.echo("-" * len(header))
    for s in out["sessions"]:
        line = s["game_id"][:25].ljust(26) + (s["first_ts"] or "--")[:10].ljust(12)
        typer.echo(line + "".join(_fmt(s.get(c)).rjust(w) for c, _, w in _WINNINGS_COLUMNS))


@app.command()
def hero(
    player: str = typer.Argument(None, help="Your player name, as `pnt alias list` prints it."),
    clear: bool = typer.Option(False, "--clear", help="Forget the pick and go back to the guess."),
    db: Path = DbOpt,
) -> None:
    """Who "you" are on the leaks, tendencies and stats pages.

    Guessed from whose seat the logs were downloaded from, so importing a friend's
    logs can make them "you". Pick yourself once and the guess is ignored:
    `pnt hero Sam`. With no name, says who it is now.
    """
    from .db.userdata import delete_setting, set_setting
    from .stats.leaks import HERO_SETTING, chosen_hero, guessed_hero

    conn = connect(db)
    if clear:
        delete_setting(conn, HERO_SETTING)
    elif player is not None:
        row = conn.execute("SELECT player_id FROM players WHERE alias = ?", (player,)).fetchone()
        if row is None:
            raise typer.BadParameter(f"no player {player!r}; `pnt alias list` shows every name")
        set_setting(conn, HERO_SETTING, row["player_id"])
    picked, guess = chosen_hero(conn), guessed_hero(conn)
    if picked:
        typer.echo(f"hero: {picked} (picked; the guess would be {guess or 'nobody'})")
    elif guess:
        typer.echo(f"hero: {guess} (guessed: owns the most logs). Not you? pnt hero <your name>")
    else:
        typer.echo("hero: nobody. No log names its owner; pick yourself with pnt hero <your name>.")


@app.command()
def leaks(
    db: Path = DbOpt,
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    show_all: bool = typer.Option(False, "--all", help="Every stat judged, inside its band or not."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Your leaks: the stats of your own game furthest outside their bands, and what they cost.

    The hero is the one `pnt hero` picked, else the owner of the most downloaded
    logs. Each stat is held against a band of ordinary values; the ones outside it
    rank by cost (bb per 100 of your hands) times confidence (how much of the 95%
    range is outside the band). Each row's filter opens its hands on your chart.
    """
    from .stats.leaks import leaks as hero_leaks

    conn = connect(db)
    out = hero_leaks(conn, game)
    if as_json:
        typer.echo(json.dumps(out, indent=2))
        return
    if out["hero"] is None:
        typer.echo("No hero: no log names its owner. Import a log you downloaded yourself, or pnt hero <your name>.")
        return
    typer.echo(f"{out['hero']}  {out['hands']} hands ({out['bb_hands']} with a known result)"
               f"   {_fmt(out['bb_per_100'])} bb/100 +/- {_fmt(out['bb_per_100_ci'])}\n")
    if out["top"]:
        typer.echo("Top leaks:")
        for i, r in enumerate(out["top"], 1):
            typer.echo(f"  {i}. {r['tip']}")
            also = f"  (also {', '.join(r['also'])})" if r.get("also") else ""
            typer.echo(f"     cost {_fmt(r['cost_bb_per_100'])} bb/100, confidence {r['confidence']:.0%}"
                       f"   filter: {r['leak_filter'] or r['filter']}{also}")
    else:
        typer.echo("No leak with a visible cost.")
    rows = out["candidates"] if show_all else out["ranked"]
    typer.echo("\nEvery stat judged:" if show_all else "\nOut of band:")
    header = f"{'stat':<26}{'value':>7}{'band':>14}{'95%':>14}{'n':>7}{'conf':>6}{'cost':>8}  filter"
    typer.echo(header)
    typer.echo("-" * len(header))
    for r in rows:
        band = f"{r['band'][0]:g}-{r['band'][1]:g}" if r["band"] else "--"
        ci = f"{r['ci'][0]:g}-{r['ci'][1]:g}" if r["ci"] else "--"
        flag = "" if r["judged"] else "  (too few to judge)"
        typer.echo(f"{r['label'][:25]:<26}{_fmt(r['value']):>7}{band:>14}{ci:>14}{r['n']:>7}"
                   f"{r['confidence']:>6.0%}{_fmt(r['cost_bb_per_100']):>8}  {r['leak_filter'] or r['filter']}{flag}")
    typer.echo("\n" + out["note"])


# ---- timing tells ---------------------------------------------------------------
# Imported inside the command so this block stands alone. See SPEC.md, "Timing tells".


def _timing_secs(ms: float | None) -> str:
    return "--" if ms is None else f"{ms / 1000:.1f}s"


def _timing_value(c: dict) -> str:
    return f"{_fmt(c['value'])}% ({c['known']}/{c['n']})" if c["known"] else f"-- (0/{c['n']})"


@app.command()
def timing(
    alias: str = typer.Argument(None, help="A player from `pnt alias list`; omit for the whole pool."),
    db: Path = DbOpt,
    filter_: str = typer.Option(None, "--filter", help="The spot, e.g. 'srp'"),
    game: str = typer.Option(None, "--game", help="Restrict to one game_id."),
    relative: bool = typer.Option(False, "--relative", help="A player's buckets cut from their own median."),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Timing tells: what flop and turn calls, river bets and river calls held, by how long they took.

    Each first decision on a street is pre-selected, snap, normal or tank (a fold
    or check the clock made is left out). Without a player, the pool, with the
    logs' owners' own cards apart from everyone else's shown hands. Hands stored
    before this version have no times until `pnt rebuild`.
    """
    from .stats.pool import owners
    from .stats.timing import pool_rows, timing_report

    conn = connect(db)
    names = display_names(conn)
    try:
        pred = parse_filter(filter_, names, tag_resolver(conn)) if filter_ else None
        if alias:
            everything = facts_for(conn, alias, game)
            out = timing_report([f for f in everything if pred is None or pred(f)], baseline=everything)
        else:
            out = timing_report(pool_rows(conn, game, pred), owners=owners(conn), who=names)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    if as_json:
        typer.echo(json.dumps({"player": alias, "filter": filter_, **out}, indent=2))
        return

    t = out["timed"]
    typer.echo(f"{alias or 'the pool'}  filter: {filter_ or '(none)'}   "
               f"{t['timed']} of {t['decisions']} first decisions timed")
    if t["rebuild"]:
        typer.echo("some hands have no times: they were stored before this version. Run `pnt rebuild` once.")
    spots = out["relative"]["spots"] if relative and alias else out["spots"]
    pool = alias is None
    head = f"{'spot':<12}{'tempo':<8}{'n':>6}  {'value (known/n)':<20}{'draw':>7}{'air':>7}"
    if pool:
        head += f"  {'others, shown':<20}{'owners, own cards':<20}"
    typer.echo("\n" + head + "\n" + "-" * len(head))
    for sp in spots:
        for r in sp["rows"]:
            line = (f"{sp['label']:<12}{r['bucket']:<8}{r['n']:>6}  {_timing_value(r):<20}"
                    f"{_fmt(r['draw']):>7}{_fmt(r['air']):>7}")
            if pool:
                line += f"  {_timing_value(r['others']):<20}{_timing_value(r['own']):<20}"
            typer.echo(line + f"  {r['filter']}")
    if relative and alias:
        cuts = out["relative"]["cuts_ms"]
        typer.echo("\nown median cuts: " + ", ".join(f"{s} snap <{_timing_secs(lo)} tank >{_timing_secs(hi)}"
                                                    for s, (lo, hi) in cuts.items()))
    typer.echo(f"\n{'street':<9}{'timed':>7}{'median':>8}{'middle half':>14}  "
               + "".join(f"{b:>9}" for b in out["buckets"]))
    for st in out["streets"]:
        mid = f"{_timing_secs(st['p25_ms'])}-{_timing_secs(st['p75_ms'])}"
        typer.echo(f"{st['street']:<9}{st['timed']:>7}{_timing_secs(st['median_ms']):>8}{mid:>14}  "
                   + "".join(f"{_fmt(b['pct']) + ('%' if b['pct'] is not None else ''):>9}" for b in st["buckets"]))
    if pool:
        rb = out["thin"]["river_bet"]
        who = " and ".join(rb["full"]) or "nobody"
        typer.echo(f"\nthin per player: of {rb['players']} players with river bets known, {who} "
                   f"{'have' if len(rb['full']) > 1 else 'has'} {out['min_cell']}+ known in every bucket.")
    typer.echo("\nBluffs that got a fold are never shown, so the shown rows lean to value.")


if __name__ == "__main__":  # pragma: no cover
    app()
