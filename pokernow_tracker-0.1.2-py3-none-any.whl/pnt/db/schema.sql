-- PokerNow Tracker schema.
--
-- Three layers, each rebuildable from the one above it:
--
--   1. raw_entries      immutable truth, exactly as PokerNow emitted it
--   2. hands/actions    parsed, DISPOSABLE, rebuilt by re-running the importer
--   3. stats            SQL at read time -- nothing aggregated is ever stored
--
-- No counter is persisted anywhere. That is deliberate: a counter that misses one
-- hand is permanently wrong with no way to detect or repair it, whereas raw
-- actions let a re-import fix any gap and let a stat invented next month compute
-- retroactively across all history.

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------- layer 1 ----

-- Every log line ever seen. Keeping these means a parser improvement can
-- re-derive everything WITHOUT needing the original CSV again. This is what
-- makes "a re-import repairs any gap" actually true rather than aspirational.
CREATE TABLE IF NOT EXISTS raw_entries (
    game_id TEXT NOT NULL,
    ord     INTEGER NOT NULL,   -- epoch_ms * 100 + seq; globally unique, monotonic
    at      TEXT NOT NULL,
    entry   TEXT NOT NULL,
    PRIMARY KEY (game_id, ord)
) WITHOUT ROWID;

-- Where each game's lines came from: one row per (game, source), updated in place
-- by every ingest, so live capture's polls do not add a row each. The unique index
-- on the pair is made by conn._migrate, which first folds an older file's rows
-- down to one per pair.
CREATE TABLE IF NOT EXISTS imports (
    import_id   INTEGER PRIMARY KEY,
    game_id     TEXT NOT NULL,
    source      TEXT NOT NULL,          -- 'csv:<file name>' | 'api' | 'extension'
    ingested_at TEXT NOT NULL,          -- the latest ingest from this source
    n_entries   INTEGER NOT NULL,       -- entries the latest ingest offered
    n_new       INTEGER NOT NULL        -- entries this source has inserted, in all
);

-- Which log-folder files each game has been read from or written to. This is what
-- lets deleting a CSV remove its game: a game is dropped once EVERY file on record
-- for it is gone. A game with no row here was imported from somewhere else, or
-- captured with PNT_SAVE_LOGS=0, and no file's absence says anything about it.
-- mtime_ns and size are how a sync tells a file it has already read from a new one.
CREATE TABLE IF NOT EXISTS log_files (
    path     TEXT PRIMARY KEY,   -- resolved, absolute
    game_id  TEXT NOT NULL,
    mtime_ns INTEGER NOT NULL,
    size     INTEGER NOT NULL
) WITHOUT ROWID;

CREATE INDEX IF NOT EXISTS idx_log_files_game ON log_files(game_id);

-- Lines the grammar did not recognize. Never silently dropped: an empty table is
-- a claim that the parse was total, and a non-empty one tells you exactly what to
-- teach the grammar next.
CREATE TABLE IF NOT EXISTS parse_misses (
    game_id TEXT NOT NULL,
    ord     INTEGER NOT NULL,
    entry   TEXT NOT NULL,
    reason  TEXT NOT NULL,
    PRIMARY KEY (game_id, ord)
) WITHOUT ROWID;

-- ------------------------------------------------------- identity (layer 2) --

-- A canonical person. Stats are always requested for one of these.
-- `notes` is what you know about them that no log records ("tanks then jams
-- with air", "plays scared after a loss"), and `notes_at` when it was last
-- written. Like the alias it is a judgement, so the identity operations that
-- delete player rows carry it along instead of dropping it (importer.py).
CREATE TABLE IF NOT EXISTS players (
    player_id  INTEGER PRIMARY KEY,
    alias      TEXT NOT NULL UNIQUE,
    notes      TEXT,
    created_at TEXT NOT NULL,
    notes_at   TEXT
);

-- Many PokerNow IDs -> one person. IDs are stable per browser/device and survive
-- quit/rejoin and renames within and across games (one ID can appear as
-- "alex" in one session and "500" in another), but the SAME human on a
-- second device gets a different ID -- which is what this table exists for.
-- Merging two people is one UPDATE here; because no stat is stored, nothing
-- needs recomputing afterwards.
CREATE TABLE IF NOT EXISTS player_identities (
    pn_id          TEXT PRIMARY KEY,
    player_id      INTEGER NOT NULL REFERENCES players(player_id) ON DELETE CASCADE,
    last_seen_name TEXT,
    last_seen_at   TEXT,
    first_seen_at  TEXT
) WITHOUT ROWID;

CREATE INDEX IF NOT EXISTS idx_identities_player ON player_identities(player_id);

-- ----------------------------------------------------- judgement (layer 2) --

-- The hands you have already looked at. A mark is a judgement you made, not a
-- fact any log holds, so -- alone among the layer-2 tables -- it is never thrown
-- away and a rebuild does not touch it. It is the same kind of row as an
-- identity merge or `players.notes`.
--
-- Keyed on (game_id, hand_number), the log's own name for a hand, and NOT on
-- hand_id. hand_id is a rowid the importer hands out, and `rebuild_game` deletes
-- every hand of a game before re-inserting it, so those ids move: a mark keyed
-- on one would come back after a rebuild silently pointing at a different hand.
-- The same reasoning rules out a foreign key to hands, whose ON DELETE CASCADE
-- would clear every mark at exactly the moment you most want them kept -- and
-- whose absence lets a mark outlive a game deleted and imported again later.
CREATE TABLE IF NOT EXISTS hand_reviews (
    game_id     TEXT NOT NULL,
    hand_number INTEGER NOT NULL,
    reviewed_at TEXT NOT NULL,
    PRIMARY KEY (game_id, hand_number)
) WITHOUT ROWID;

-- What you wrote down about a hand: the mistake you found, the read you want to
-- remember. Everything said above about a mark applies to a note -- same key,
-- same reason, never thrown away -- and it is a table of its own rather than a
-- column on hand_reviews so that the two can be set and cleared independently:
-- un-ticking a hand you meant to look at again must not silently delete what you
-- typed, and a note is worth keeping on a hand you have not finished with.
--
-- `noted_at` is when the note was LAST written, unlike `reviewed_at`, which is
-- when the hand was first marked: a mark is an event, a note is a document.
CREATE TABLE IF NOT EXISTS hand_notes (
    game_id     TEXT NOT NULL,
    hand_number INTEGER NOT NULL,
    note        TEXT NOT NULL,
    noted_at    TEXT NOT NULL,
    PRIMARY KEY (game_id, hand_number)
) WITHOUT ROWID;

-- The hands you flagged for a second look, usually from the HUD's 🚩 a moment
-- after the hand ended: the queue the Manual review tab lists. Kept and keyed
-- like a mark, for the same reasons, and independent of it -- a flag says "look
-- at this", a mark says "I have". Unlike a mark it may name a hand the rebuild
-- has not reached yet: the HUD flags a hand seconds after it ends, so a flag is
-- checked against the raw log rather than against `hands`.
CREATE TABLE IF NOT EXISTS hand_flags (
    game_id     TEXT NOT NULL,
    hand_number INTEGER NOT NULL,
    flagged_at  TEXT NOT NULL,
    PRIMARY KEY (game_id, hand_number)
) WITHOUT ROWID;

-- Your words for a hand: `river-bluff`, `cooler`, `study`. Several per hand, kept
-- and keyed like a flag, for the same reasons, and like a flag it may name a hand
-- the rebuild has not reached yet. Stored normalised (db/userdata.py): lower
-- case, trimmed, a run of spaces one `-`.
CREATE TABLE IF NOT EXISTS hand_tags (
    game_id     TEXT NOT NULL,
    hand_number INTEGER NOT NULL,
    tag         TEXT NOT NULL,
    tagged_at   TEXT NOT NULL,
    PRIMARY KEY (game_id, hand_number, tag)
) WITHOUT ROWID;

CREATE INDEX IF NOT EXISTS idx_hand_tags_tag ON hand_tags(tag);

-- The games you have opened in the chart's Session view, so its tab can count
-- the new ones. Keyed on game_id, the log's own name, and never touched by a
-- rebuild, like a mark. A database made before this table counts every game it
-- held as opened (conn._seed_session_opens), so the count starts at 0.
CREATE TABLE IF NOT EXISTS session_opens (
    game_id   TEXT PRIMARY KEY,
    opened_at TEXT NOT NULL
) WITHOUT ROWID;

-- A spot filter you named, to apply again from the ★ menu. `ord` is your order
-- (NULL sorts last), pinned ones first. Nothing derived refers to it, so like
-- the rest of this section it is never touched by a rebuild.
CREATE TABLE IF NOT EXISTS saved_spots (
    spot_id    INTEGER PRIMARY KEY,
    name       TEXT NOT NULL UNIQUE,
    filter     TEXT NOT NULL,
    pinned     INTEGER NOT NULL DEFAULT 0,
    ord        INTEGER,
    created_at TEXT NOT NULL
);

-- Choices made on the pages that should outlive a browser: the HUD's columns,
-- and the like. `value` is JSON.
CREATE TABLE IF NOT EXISTS settings (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at TEXT NOT NULL
) WITHOUT ROWID;

-- ---------------------------------------------------------------- layer 2 ----

CREATE TABLE IF NOT EXISTS games (
    game_id    TEXT PRIMARY KEY,
    started_at TEXT,
    sb         INTEGER,
    bb         INTEGER,
    ante       INTEGER DEFAULT 0,
    variant    TEXT DEFAULT 'nlhe',
    hero_pn_id TEXT,
    -- The derivation generation this game's hands were last rebuilt at (see
    -- conn.generation). The global counter says *that* something changed; this says
    -- which game, so a cache can re-derive that game alone. hand_id cannot serve:
    -- a rebuild may hand the same ids back out.
    derived_gen INTEGER NOT NULL DEFAULT 0,
    -- The parser.PARSE_VERSION that stored this game's hands. Older than the
    -- running one: `pnt rebuild --if-stale` re-parses it.
    parsed_with INTEGER NOT NULL DEFAULT 0
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS hands (
    hand_id          INTEGER PRIMARY KEY,
    game_id          TEXT NOT NULL REFERENCES games(game_id) ON DELETE CASCADE,
    hand_number      INTEGER NOT NULL,
    table_hand_id    TEXT,
    ts               TEXT,
    ord              INTEGER NOT NULL,
    dealer_seat      INTEGER,          -- NULL on a dead button
    dead_button      INTEGER NOT NULL DEFAULT 0,
    blinds_irregular INTEGER NOT NULL DEFAULT 0,  -- a dead blind left a position slot empty
    n_dealt_in       INTEGER NOT NULL, -- stored RAW; never bucketed into "6-max" etc.
    bb               INTEGER,          -- this hand's actual BB post; blind levels move
    board_json       TEXT,             -- list of runs, so run-it-twice needs no new columns
    run_count        INTEGER NOT NULL DEFAULT 1,
    went_to_showdown INTEGER NOT NULL DEFAULT 0,
    complete         INTEGER NOT NULL DEFAULT 1,  -- 0: the log stopped mid-hand
    board_ords       TEXT,             -- JSON {street: ord} of the run-one board lines
    clock_ms         INTEGER,          -- decision limit plus a full time bank, in ms
    variant          TEXT,             -- the game per hand; NULL reads as Hold'em
    double_board     INTEGER NOT NULL DEFAULT 0,
    UNIQUE (game_id, hand_number)
);

-- No index on game_id alone: the UNIQUE index above starts with it and serves
-- every lookup by game. conn._migrate drops the one older files still have.

-- Populated from the `Player stacks:` line -- the DEALT-IN roster -- never from
-- join/quit events and never from whoever happened to act. A player sitting out
-- is still at the table; getting this wrong silently deflates every rate for
-- exactly the players who sit out most.
CREATE TABLE IF NOT EXISTS hand_players (
    hand_id           INTEGER NOT NULL REFERENCES hands(hand_id) ON DELETE CASCADE,
    pn_id             TEXT NOT NULL,
    seat              INTEGER NOT NULL,
    seats_from_button INTEGER,   -- position is DERIVED from this at query time
    starting_stack    INTEGER,
    hole_cards        TEXT,      -- known at showdown, or for hero on every hand
    contributed       INTEGER NOT NULL DEFAULT 0,
    collected         INTEGER NOT NULL DEFAULT 0,
    -- Signed 7-2 side-bet result. Kept OUT of collected/contributed so those two
    -- continue to describe the pot alone and keep balancing against each other.
    bounty            INTEGER NOT NULL DEFAULT 0,
    -- Signed Nit Game penalty, the same way: in net, never in the pot.
    nit               INTEGER NOT NULL DEFAULT 0,
    folded           INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (hand_id, pn_id)
) WITHOUT ROWID;

CREATE INDEX IF NOT EXISTS idx_hp_pn ON hand_players(pn_id);

CREATE TABLE IF NOT EXISTS actions (
    hand_id     INTEGER NOT NULL REFERENCES hands(hand_id) ON DELETE CASCADE,
    seq         INTEGER NOT NULL,     -- monotonic within the hand
    street      TEXT NOT NULL,        -- preflop | flop | turn | river
    pn_id       TEXT NOT NULL,
    action_type TEXT NOT NULL,        -- post | fold | check | call | bet | raise
    amount      INTEGER NOT NULL DEFAULT 0,  -- INCREMENTAL chips (see parser.py)
    amount_to   INTEGER,              -- raw cumulative figure from the log, for audit
    is_forced   INTEGER NOT NULL DEFAULT 0,
    all_in      INTEGER NOT NULL DEFAULT 0,
    post_kind   TEXT,                 -- sb | bb | ante | missed_bb | missing_sb | straddle | bomb_pot
    ord         INTEGER,              -- the log line's ord: when it was logged (timing tells)
    PRIMARY KEY (hand_id, seq)
) WITHOUT ROWID;

-- Supports "every time this player did X on this street" -- the filter queries.
CREATE INDEX IF NOT EXISTS idx_actions_pn ON actions(pn_id, street, action_type);
-- NOTE: no index on (hand_id, ...) is needed. This is a WITHOUT ROWID table whose
-- primary key is already (hand_id, seq), so rows for one hand are physically
-- contiguous and ordered. An extra index there is never chosen by the planner and
-- only costs write time on every rebuild.

-- Cards shown AFTER `-- ending hand #N --`: a player who folded and then showed,
-- a winner who took it down uncontested and showed, a showdown loser who mucked
-- and revealed later. PokerNow logs all of these past the hand-end line, in the
-- same slot as the 7-2 bounty.
--
-- Deliberately NOT merged into hand_players.hole_cards. Showdown cards are the
-- hands that got there; these are the hands a player CHOSE to reveal -- the bluff
-- they are proud of, the fold they want credit for -- a bias running the other
-- way. Kept apart, a range view can opt in; merged, that choice is gone for good.
--
-- One row per player per hand. A player may show one card and then the other as
-- two separate lines, so `cards` is the union, in the order shown.
CREATE TABLE IF NOT EXISTS voluntary_shows (
    hand_id INTEGER NOT NULL,
    pn_id   TEXT NOT NULL,
    cards   TEXT NOT NULL,     -- same encoding as hole_cards; may be one card
    ord     INTEGER NOT NULL,  -- raw_entries.ord of the latest show line, for audit
    PRIMARY KEY (hand_id, pn_id),
    -- Only a player dealt into the hand can show from it.
    FOREIGN KEY (hand_id, pn_id) REFERENCES hand_players(hand_id, pn_id) ON DELETE CASCADE
) WITHOUT ROWID;

-- ------------------------------------------------------- derived (layer 3) ---

-- Showdown equities, memoized. DERIVED and DISPOSABLE: drop the table and the
-- next all-in EV request refills it. It is the one exception to "nothing derived
-- is stored", and it is safe because the key is the cards and the pot layout
-- alone -- never a hand_id or an identity -- so no rebuild, merge or rename can
-- make a row wrong. A preflop all-in costs half a second of sampling; without
-- this the page would pay that for every hand on every request.
CREATE TABLE IF NOT EXISTS equity_cache (
    key         TEXT PRIMARY KEY,   -- hole cards | board | pot layout (equity.cache_key)
    expected    TEXT NOT NULL,      -- JSON list: expected chips collected, per player
    method      TEXT NOT NULL,      -- exact | sampled
    n           INTEGER NOT NULL,   -- boards enumerated, or deals sampled
    computed_at TEXT NOT NULL
) WITHOUT ROWID;

-- Hand strength (stats/strength.py: the share of every two-card holding a hand
-- beats on the board as it stood, ties half), memoized. DERIVED and DISPOSABLE,
-- keyed by cards alone: a change of cut never touches it.
CREATE TABLE IF NOT EXISTS strength_cache (
    key  TEXT PRIMARY KEY,   -- strength.cache_key: sorted hole | sorted board
    num2 INTEGER NOT NULL,   -- 2*wins + ties against every other two-card holding
    n    INTEGER NOT NULL    -- holdings counted
) WITHOUT ROWID;

-- ------------------------------------------------------------------ views ----

-- Resolves the identity layer once so every stat query can join on player_id
-- without repeating the alias plumbing.
CREATE VIEW IF NOT EXISTS v_hand_players AS
SELECT
    hp.*,
    h.game_id,
    h.hand_number,
    h.n_dealt_in,
    h.dead_button,
    h.went_to_showdown,
    h.ts,
    pi.player_id,
    p.alias
FROM hand_players hp
JOIN hands   h  ON h.hand_id = hp.hand_id
LEFT JOIN player_identities pi ON pi.pn_id = hp.pn_id
LEFT JOIN players p            ON p.player_id = pi.player_id;

CREATE VIEW IF NOT EXISTS v_actions AS
SELECT
    a.*,
    h.game_id,
    h.hand_number,
    h.n_dealt_in,
    pi.player_id,
    p.alias
FROM actions a
JOIN hands   h  ON h.hand_id = a.hand_id
LEFT JOIN player_identities pi ON pi.pn_id = a.pn_id
LEFT JOIN players p            ON p.player_id = pi.player_id;

-- A voluntary show with the context that makes it readable: did the player fold,
-- did anyone reach showdown, how far the board ran. "Folded, then showed, before
-- the river" is `folded = 1 AND board_cards < 5`.
CREATE VIEW IF NOT EXISTS v_voluntary_shows AS
SELECT
    vs.*,
    length(vs.cards) / 2 AS n_cards,
    hp.folded,
    hp.seats_from_button,
    hp.contributed,
    hp.collected,
    h.game_id,
    h.hand_number,
    h.n_dealt_in,
    h.went_to_showdown,
    COALESCE(json_array_length(h.board_json, '$[0]'), 0) AS board_cards,  -- first run
    h.board_json,
    h.ts,
    pi.player_id,
    p.alias
FROM voluntary_shows vs
JOIN hand_players hp ON hp.hand_id = vs.hand_id AND hp.pn_id = vs.pn_id
JOIN hands        h  ON h.hand_id = vs.hand_id
LEFT JOIN player_identities pi ON pi.pn_id = vs.pn_id
LEFT JOIN players p            ON p.player_id = pi.player_id;

-- Bumped whenever something makes previously derived facts stale: a rebuild, or a
-- change to who an identity belongs to. Read-side caches key on it, so they can
-- hold a result for as long as it is still true and never longer.
--
-- Note what does NOT bump it: appending raw entries. Those change nothing derived
-- until a rebuild reads them, so live capture between hands leaves caches warm.
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value INTEGER NOT NULL
);
