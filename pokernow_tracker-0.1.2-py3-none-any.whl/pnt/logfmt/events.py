"""Typed events -- the intermediate representation between raw log lines and hands.

One dataclass per line *kind*. `grammar.py` produces these; `parser.py` consumes
them. Keeping this layer explicit is what lets an unrecognized line become a
recorded `Unknown` rather than a silent drop.
"""

from __future__ import annotations

from dataclasses import dataclass

from .tokens import PlayerRef

# --- Post kinds -------------------------------------------------------------
# Every one of these is forced money: it counts toward stat denominators and
# never toward a VPIP numerator. See pnt/stats/SPEC.md.
POST_SB = "sb"
POST_BB = "bb"
POST_ANTE = "ante"
POST_MISSED_BB = "missed_bb"
POST_MISSING_SB = "missing_sb"
POST_STRADDLE = "straddle"
#: Everyone's share of a bomb pot: no blinds, no preflop betting, straight to the
#: flop. Nobody acts voluntarily preflop, so no preflop rate counts the hand.
POST_BOMB = "bomb_pot"

# --- Streets ----------------------------------------------------------------
PREFLOP = "preflop"
FLOP = "flop"
TURN = "turn"
RIVER = "river"
STREET_ORDER = (PREFLOP, FLOP, TURN, RIVER)
#: Each street's place in STREET_ORDER, for "folded before this street".
STREET_INDEX = {s: i for i, s in enumerate(STREET_ORDER)}


@dataclass(frozen=True, slots=True)
class Event:
    """Base: every event carries its source ordering key and raw text."""

    ord: int
    raw: str


@dataclass(frozen=True, slots=True)
class HandStart(Event):
    hand_number: int
    table_hand_id: str
    variant: str
    dealer: PlayerRef | None  # None when the log says "(dead button)"
    dead_button: bool


@dataclass(frozen=True, slots=True)
class HandEnd(Event):
    hand_number: int


@dataclass(frozen=True, slots=True)
class PlayerStacks(Event):
    """The dealt-in roster. This -- not join/quit events -- defines who is in the hand."""

    seats: tuple[tuple[int, PlayerRef, int], ...]  # (seat, player, starting_stack)
    #: The stacks were printed as decimals: the table is in Cents Mode, so the
    #: hand's other amounts are in hundredths too (`grammar._chips`).
    cents: bool = False


@dataclass(frozen=True, slots=True)
class HeroCards(Event):
    cards: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Post(Event):
    """A forced post: blind, ante, straddle, or a missed blind on rejoining.

    `all_in` because a stack shorter than the blind posts what it has and is all
    in for it -- the log says so on the same line, exactly as it does for a bet.
    """

    player: PlayerRef
    kind: str
    amount: int
    all_in: bool = False


@dataclass(frozen=True, slots=True)
class Action(Event):
    """A voluntary action.

    `amount_to` is the raw figure from the log and is **cumulative for the
    street**, not incremental -- see parser.py. None for fold/check.
    """

    player: PlayerRef
    kind: str  # fold | check | call | bet | raise
    amount_to: int | None
    all_in: bool


@dataclass(frozen=True, slots=True)
class StreetDealt(Event):
    street: str
    run: int  # 0 = first board; 1 = second run (run-it-twice) or second board (Double Board)
    board: tuple[str, ...]  # full board for this street on this run
    double_board: bool = False  # the second board was Double Board's, not a second run


@dataclass(frozen=True, slots=True)
class UncalledReturn(Event):
    player: PlayerRef
    amount: int


@dataclass(frozen=True, slots=True)
class Collected(Event):
    player: PlayerRef
    amount: int
    ranking: str | None  # e.g. "Two Pair, A's & 6's"; None for uncontested pots


@dataclass(frozen=True, slots=True)
class BountyPaid(Event):
    """A side-bet transfer between two players, outside the pot.

    Emitted only by the ``paid N ... to X`` line. The matching ``collected N from
    the 7-2 bounty`` line is a *summary* of those payments -- crediting both would
    pay the winner twice -- so it is classified as `Noise`.
    """

    payer: PlayerRef
    payee: PlayerRef
    amount: int
    kind: str = "7-2"
    #: More winners after `payee`, when two chopped the pot: ``to "A @ x", "B @ y"``.
    #: The amount is split between them all, as their ``collected`` lines show.
    others: tuple[PlayerRef, ...] = ()


@dataclass(frozen=True, slots=True)
class NitPenalty(Event):
    """The Nit Game's payout: the last player not to win a pot pays each other one.

    `amount` is paid to *each* payee, unlike `BountyPaid`'s total. It comes out
    of the payer's escrow, which their stack funded when they bought in -- the
    buy-in, the escrow carried over and the refund on leaving all move the
    player's own chips, so this line is the only one that changes anyone's net.
    """

    payer: PlayerRef
    payees: tuple[PlayerRef, ...]
    amount: int


@dataclass(frozen=True, slots=True)
class Shows(Event):
    player: PlayerRef
    cards: tuple[str, ...]  # may be a single card (voluntary partial show)


@dataclass(frozen=True, slots=True)
class SeatChange(Event):
    """joined / quit / stand up / sit back / requested seat / admin approval."""

    player: PlayerRef
    kind: str
    stack: int | None


@dataclass(frozen=True, slots=True)
class AdminStackChange(Event):
    player: PlayerRef
    from_stack: int
    to_stack: int


@dataclass(frozen=True, slots=True)
class BlindChange(Event):
    which: str  # sb | bb | ante
    #: In the table's integer units, like every amount: a Cents Mode table's
    #: "changed from 0.10 to 0.05" is 10 to 5. Only ever a game-level fallback: a
    #: hand's big blind comes from that hand's actual BB post.
    from_amount: int
    to_amount: int


@dataclass(frozen=True, slots=True)
class Noise(Event):
    """Recognized but semantically inert: rabbit hunts, RIT prompts, config dumps."""

    kind: str


@dataclass(frozen=True, slots=True)
class Unknown(Event):
    """Unrecognized line. Never dropped -- these land in `parse_misses`."""

    reason: str = "no grammar rule matched"
