"""Line explorer: one path, split by the sizes on it or by a dimension (SPEC.md,
"Line explorer").

SnapMDA's table. A path (`paths.py`) is a rate, n out of its opportunity, and
each row of the table is that rate in one group of hands, with what the shown
hands were, what they did next, what their bets got, and the EV of the two plays
against them: calling their bet with a bluff-catcher, and bluffing into their
check. Every row carries the filter that finds its n hands.

`suggest` is the line box's autocomplete: the paths the hands in a spot took,
most common first.
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict
from collections.abc import Callable, Collection, Iterable, Mapping
from dataclasses import replace
from functools import lru_cache
from itertools import permutations, product
from statistics import mean, median

from . import filters
from .bluffs import CLASSES, classify
from .cards import VALUE_RANK, Card, board_at, made_hand, parse_cards
from .derive import ANSWERS, POSTFLOP_STREETS, Facts, pct
from .equity import rank7
from .fold_equity import MIN_SAMPLE, break_even
from .groupby import DIMENSIONS, Context
from .lines import money
from .paths import (
    NO_SIZE,
    SIZE_LETTERS,
    UNBET,
    Path,
    matches,
    next_decision,
    opportunity,
    parse_path,
    size_letter,
    street_sized,
    to_term,
)
from .queries import TREND_DAYS, trend, wilson
from .strength import hs_of
from .tags import strength_at

#: What a table can be split by: the size sequence, nothing, or a group-by
#: dimension (groupby.DIMENSIONS).
DIMS = ("flop_texture", "pot_type", "vs", "player", "players_flop", "ip", "depth")
BY = ("size_seq", "overall", *DIMS)
#: A blank street of the path in a size-sequence key: it is "any", not split.
ANY = "*"
#: The next decision's letters, in the order a page prints them.
NEXT_LETTERS = ("F", "C", "R", "X", "B")
_BUCKET_OF = {letter.upper(): bucket for letter, bucket in SIZE_LETTERS.items()}
#: The bins of a row's `strength_dist`: hand strength 0-10%, 10-20%, ... 90-100%.
STRENGTH_BINS = 10
#: The bluff-catchers a river call EV is also priced for (SPEC.md, "Line
#: explorer", "By catcher"): (key, label), weakest first. Each is built on every
#: shown hand's own river board (`catcher_hole`) and played against it.
CATCHERS = (
    ("ace_high", "A-high"),
    ("bottom_pair", "bottom pair"),
    ("second_pair", "second pair"),
    ("top_pair", "top pair"),
)


@lru_cache(maxsize=65536)
def catcher_hole(kind: str, board: tuple[str, ...], dead: tuple[str, ...] = ()) -> tuple[Card, Card] | None:
    """Two cards that are the catcher `kind` (a CATCHERS key) on a river `board`,
    out of `dead` (the shown hand's cards), or None when the board has no such
    hand: A-high with an ace on the board, a pair of a rank the board already
    pairs, second pair on a board of two ranks.

    The pair is of the board's highest, second-highest or lowest rank (A-high
    holds an ace), and the kicker is the middle rank of those that pair nothing,
    trying outward from it. Suits go where the board has fewest, the two cards
    apart, so the catcher makes no flush. It must read as that hand
    (`cards.made_hand`: an A-high adds nothing to the board), else the next
    kicker is tried.
    """
    b = parse_cards(board)
    used = set(b) | set(parse_cards(dead))
    values = sorted({c.value for c in b}, reverse=True)
    if kind == "ace_high":
        if 14 in values:
            return None
        top = 14
    elif kind == "top_pair":
        top = values[0]
    elif kind == "second_pair":
        if len(values) < 3:
            return None
        top = values[1]
    else:
        top = values[-1]
    per_suit = Counter(c.suit for c in b)
    suits = sorted("cdhs", key=lambda s: (per_suit[s], s))
    kickers = [v for v in range(2, 15) if v not in values and v != top]
    mid = kickers[len(kickers) // 2]
    for k in sorted(kickers, key=lambda v: (abs(v - mid), v)):
        for s1, s2 in permutations(suits, 2):
            hole = (Card(top, s1), Card(k, s2))
            if hole[0] in used or hole[1] in used:
                continue
            mh = made_hand([_text(c) for c in hole], board)
            adds_nothing = mh.cls in ("high_card", "draw") or mh.detail == "board_pair"
            if (adds_nothing if kind == "ace_high" else mh.detail == _DETAIL.get(kind, kind)):
                return hole
    return None


#: `cards.made_hand`'s name for a catcher, where it is not the key: any pair
#: between the board's top and bottom ranks is its middle pair.
_DETAIL = {"second_pair": "middle_pair"}


def _text(c: Card) -> str:
    return VALUE_RANK[c.value] + c.suit


def catcher_share(kind: str, shown: Iterable[Facts], street: str) -> tuple[float, int]:
    """What the catcher `kind` wins of `shown` at showdown on `street`'s board,
    a chop as half, and over how many: the hands its board can build it on (a
    hand with a card used twice sits out)."""
    won, n = 0.0, 0
    for f in shown:
        board = board_at(f.board, street)
        if board is None or not f.hole_cards:
            continue
        seen = _shown_rank(board, f.hole_cards)
        if seen is None:
            continue  # a card used twice: no hand to play against
        dead, theirs = seen
        mine = _catcher_rank(kind, board, dead)
        if mine is None:
            continue
        won += 1.0 if mine > theirs else 0.5 if mine == theirs else 0.0
        n += 1
    return won, n


#: Shown hands and catchers ranked, kept across rows and tables: every row's
#: catchers, and the Overall row's after them, play the same shown hands, four
#: catchers each. A few MB when full.
_RANKED = 16384


@lru_cache(maxsize=_RANKED)
def _shown_rank(board: tuple[str, ...], hole: str) -> tuple[tuple[str, ...], tuple[int, ...]] | None:
    """A shown `hole` on `board`: its cards as text (a catcher's dead cards) and
    its rank (`rank7`); None when a card is used twice."""
    b, theirs = parse_cards(board), parse_cards(hole)
    if len(set(b) | set(theirs)) < len(b) + len(theirs):
        return None
    return tuple(_text(c) for c in theirs), rank7(theirs + b)


@lru_cache(maxsize=_RANKED)
def _catcher_rank(kind: str, board: tuple[str, ...], dead: tuple[str, ...]) -> tuple[int, ...] | None:
    """The rank of the catcher `kind` built on `board` around `dead`; None when
    the board cannot build it (`catcher_hole`)."""
    hole = catcher_hole(kind, board, dead)
    return None if hole is None else rank7([*hole, *parse_cards(board)])


def call_ev(beaten: float, size: float) -> float:
    """The EV of calling a bet of `size` pots with a hand that beats `beaten` of
    the bettor's range, in % of the pot before the bet: win the pot and the bet,
    or lose the call."""
    return round(100.0 * (beaten * (1 + size) - (1 - beaten) * size), 1)


def bluff_ev(fold: float, size: float) -> float:
    """The EV of a pure bluff of `size` pots into a player who folds `fold` of
    the time, in % of the pot before the bet: win the pot when they fold, lose
    the bet when they do not."""
    return round(100.0 * (fold - (1 - fold) * size), 1)


def _class_on(f: Facts, street: str, path_bets: bool) -> str | None:
    """A shown hand's class on `street` (`bluffs.classify`): read as a bet's when
    the path bets or raises there (`path_bets`) and so did this hand -- a weak
    river pair is then a bluff -- else as a caller's, a bluff-catcher. A check
    line (`--X`) that a hand check-raised later is still read as a check, as the
    page labels it; a bracket (`[XB]`) reads each hand by what it did."""
    line = f.line.get(street, "")
    aggressive = path_bets and ("b" in line or "r" in line)
    return classify(strength_at(f.hole_cards, f.board, street), street, aggressive=aggressive)


def _bets_on(path: str, street: str) -> bool:
    """Whether canonical path text has a B or R on `street`."""
    parts = path.split("-")
    i = POSTFLOP_STREETS.index(street)
    return i < len(parts) and bool(set(parts[i]) & {"B", "R"})


def today() -> str:
    """The day the trend counts back from, as `last:` reads it: what a cache of
    this table adds to its key."""
    return filters._today().isoformat()


def check_by(by: str, pool: bool) -> None:
    """ValueError unless `by` is a grouping the explorer offers; `player` needs the pool."""
    if by not in BY:
        raise ValueError(f"unknown grouping {by!r}. Known: {', '.join(BY)}")
    if by == "player" and not pool:
        raise ValueError("group by player needs the pool: leave the player out")


def _join(*terms: str | None) -> str:
    return ",".join(t for t in terms if t)


def _size_key(path: Path, f: Facts, upto: int | None = None) -> tuple[str, ...]:
    """The size letter of each of the path's streets (the first `upto`): T S M L
    O, `·` with none, `*` on a blank street, which a path does not split."""
    out = []
    for spec, s in list(zip(path.streets, POSTFLOP_STREETS))[:upto]:
        if spec.blank:
            out.append(ANY)
            continue
        out.append(size_letter(f, s))
    return tuple(out)


def _sized_path(path: Path, key: tuple[str, ...]) -> Path:
    """`path` with each street's size letter from `key` written in."""
    streets = []
    for spec, k in zip(path.streets, key):
        if k in _BUCKET_OF and not spec.blank:
            at = spec.size_at if spec.size is not None else len(spec.letters) - 1
            spec = replace(spec, size=_BUCKET_OF[k], size_at=at)
        streets.append(spec)
    return Path(tuple(streets))


def _size_filter(path: Path, key: tuple[str, ...]) -> str:
    """The terms that find a size-sequence row's hands: the path with its sizes
    written in, and for each street with no size, `path!=` that path with each
    size there, since "no size" has no letter of its own."""
    sized = _sized_path(path, key)
    terms = [f"path={to_term(sized)}"]
    for i, k in enumerate(key):
        if k != NO_SIZE:
            continue
        alts = []
        for bucket in SIZE_LETTERS.values():
            streets = list(sized.streets)
            spec = streets[i]
            streets[i] = replace(spec, size=bucket, size_at=len(spec.letters) - 1)
            alts.append(to_term(Path(tuple(streets))))
        terms.append("path!=" + "|".join(alts))
    return ",".join(terms)


class _Spot:
    """What the path itself fixes about every row: the streets each column reads."""

    def __init__(self, path: Path):
        self.path = path
        self.term = to_term(path)
        self.last = len(path.streets) - 1
        self.street = POSTFLOP_STREETS[self.last]
        end = path.streets[-1]
        self.end = end.letters[-1]
        self.pos = len(end.letters) - 1
        # The street a row's shown hands are read on: the last with a bet or a
        # raise in it, else the last.
        self.shown_street = self.street
        self.bets = False  # the path bets or raises on the shown street
        for spec, s in reversed(list(zip(path.streets, POSTFLOP_STREETS))):
            if any(g & {"b", "r"} for g in spec.letters):
                self.shown_street, self.bets = s, True
                break
        # Calling their bet with a bluff-catcher: on the river only. Before it a
        # "bluff" is often a draw with equity against the catcher, and the shown
        # hands are the ones that reached showdown, without the bluffs that gave
        # up on a later street, so the EV would be a fiction.
        self.call = self.end <= {"b", "r"} and self.street == POSTFLOP_STREETS[-1]
        self.got = self.end == {"b"}
        # A bluff into them: after their check (or bet) as the street's only
        # letter, where the bet they face next is the first they face there, so
        # `faced_bet_pot` is its size. One letter, not `[XB]`: that would price
        # bets faced after a check and raises faced after a bet as one size.
        self.bluff = self.pos == 0 and len(self.end) == 1 and self.end <= UNBET
        letter = "".join(c for c in "xbcfr" if c in self.end).upper()
        self.letter = letter if len(letter) == 1 else ""


def _closes(spot: _Spot, f: Facts) -> bool:
    """Whether `f`'s last action on the path ended the street for them: a fold,
    a check that was the street's last action (`check_back`), or a call no one
    raised after. Not `in_position`: that is fixed among the players of their
    last action, so on a later street, once the flop's last actor has folded or
    is all in, the player who now checks last is not "in position"."""
    line = f.line.get(spot.street, "")
    act = line[spot.pos] if len(line) > spot.pos else ""
    if act == "f":
        return True
    again = len(line) > spot.pos + 1
    return not again and (act == "c" or (act == "x" and bool(f.check_back.get(spot.street))))


def _row(
    spot: _Spot, key: str, label: str, filt: str, rows: list[Facts], opp: list[Facts],
    recent: Callable[[Facts], bool], with_ids: bool, skip_answers: Collection[tuple[int, str]],
) -> dict:
    n, o = len(rows), len(opp)
    ci = wilson(n, o)
    st = spot.street

    # Shown hands, read on the board as it stood on the shown street.
    mix = dict.fromkeys(CLASSES, 0)
    known: list[Facts] = []
    for f in rows:
        if f.hole_cards is None:
            continue
        cls = _class_on(f, spot.shown_street, spot.bets)
        if cls is not None:
            mix[cls] += 1
            known.append(f)
    shown = sum(mix.values())
    bluffs = mix["semi_bluff"] + mix["bluff"]
    bluff_share = bluffs / shown if shown else None

    # The same shown hands' hand strength on that board, `strength_cache`'s
    # values: the mean and a histogram of STRENGTH_BINS bins.
    hs = [x for f in known if (x := hs_of(f, spot.shown_street)) is not None]
    dist = [0] * STRENGTH_BINS
    for x in hs:
        dist[min(int(x * STRENGTH_BINS), STRENGTH_BINS - 1)] += 1

    # What they did next on the same street.
    nxt = Counter(d for f in rows if (d := next_decision(spot.path, f)) is not None)
    next_n = sum(nxt.values())
    letters = [c for c in NEXT_LETTERS if nxt[c] or c in "FCR"]
    next_out = {
        "n": next_n,
        "counts": {c: nxt[c] for c in letters},
        "pct": {c: pct(nxt[c], next_n) for c in letters},
        # Their own action ended the street for them, so no next one could come.
        "closed": sum(1 for f in rows if _closes(spot, f)),
    }

    # What their bet on the last street got.
    got = None
    if spot.got:
        # Without the bets someone left out of the table answered (the hero, when
        # the table is about others): their answers are not the pool's.
        bets = [f for f in rows if st in f.bet_pot and (f.hand_id, st) not in skip_answers]
        answers = Counter(f.bet_answer.get(st) for f in bets)
        be = mean(break_even(f.bet_pot[st]) for f in bets) if bets else None
        got = {
            "n": len(bets),
            **{a: pct(answers[a], len(bets)) for a in ANSWERS},
            "break_even": round(100.0 * be, 1) if be is not None else None,
        }
        got["edge"] = round(got["fold"] - got["break_even"], 1) if bets else None

    # The size the row prints: the last street of the path where any hand has one.
    avg_size = size_street = None
    size_n = 0
    for spec, s in reversed(list(zip(spot.path.streets, POSTFLOP_STREETS))):
        if spec.blank:
            continue
        sizes = [x[1] for f in rows if (x := street_sized(f, s)) is not None and x[1] is not None]
        if sizes:
            avg_size, size_street, size_n = round(median(sizes), 3), s, len(sizes)
            break

    pots = [f.pot_at[st] / f.bb_size for f in rows if st in f.pot_at and f.bb_size]

    # Calling their last bet or raise with a bluff-catcher: win the pot and the
    # bet when it is a bluff, lose the call when it is not. In pots before it.
    ev_call = call_size = catchers = None
    if spot.call:
        own = []
        for f in rows:
            line = f.line.get(st, "")
            act = line[spot.pos] if len(line) > spot.pos else ""
            # `raise_pot` is their first raise on the street: a re-raise
            # (`xrr`) has no size of its own, so it sits out rather than be
            # priced at the raise before it.
            first_raise = act == "r" and "r" not in line[:spot.pos]
            x = f.bet_pot.get(st) if act == "b" else f.raise_pot.get(st) if first_raise else None
            if x is not None:
                own.append(x)
        if own:
            call_size = round(median(own), 3)
        if bluff_share is not None and shown >= MIN_SAMPLE and call_size is not None:
            ev_call = call_ev(bluff_share, call_size)
            # The same call with a named catcher, built on each shown hand's board
            # and played against it: priced over the hands it could be built on,
            # when they are a sample.
            catchers = []
            for c_key, c_label in CATCHERS:
                won, m = catcher_share(c_key, known, st)
                beaten = won / m if m else None
                catchers.append({
                    "key": c_key, "label": c_label, "n": m,
                    "beats": round(100.0 * beaten, 1) if beaten is not None else None,
                    "ev": call_ev(beaten, call_size) if beaten is not None and m >= MIN_SAMPLE else None,
                })

    # A pure bluff into their check: win the pot when everyone folds, lose the
    # bet when anyone does not. The size is the bet they faced there, in pots
    # before it. Multiway one player's fold is not the pot, so after a check the
    # fold is the bet behind it taking the pot (`street_bet_answer`); after a
    # bet, whether the raise over it got everyone out is kept by no fact, so
    # only heads-up hands are priced, where their fold is everyone's.
    ev_bluff = bluff_size = bluff_fold = None
    bluff_n = 0
    if spot.bluff:
        acted = [f for f in rows if next_decision(spot.path, f) is not None]
        if spot.letter == "X":
            priced = [f for f in acted if st in f.street_bet_answer]
            took = sum(1 for f in priced if f.street_bet_answer[st] == "fold")
        else:
            priced = [f for f in acted if f.players_on.get(st) == 2]
            took = sum(1 for f in priced if next_decision(spot.path, f) == "F")
        bluff_n = len(priced)
        faced = [f.faced_bet_pot[st] for f in priced if st in f.faced_bet_pot]
        if faced:
            bluff_size = round(median(faced), 3)
        if bluff_n:
            bluff_fold = pct(took, bluff_n)
        if bluff_n >= MIN_SAMPLE and bluff_size is not None:
            ev_bluff = bluff_ev(took / bluff_n, bluff_size)

    # The rate over the last TREND_DAYS days against everything else,
    # `!(last:30d)`: a hand with no time is "before", as on the stats page.
    def split(xs: list[Facts]) -> tuple[int, int]:
        r = sum(1 for f in xs if recent(f))
        return r, len(xs) - r

    (nr, nb), (orr, ob) = split(rows), split(opp)

    out = {
        "key": key,
        "label": label,
        "n": n,
        "opp": o,
        "freq": pct(n, o),
        "ci": [round(100 * ci[0], 1), round(100 * ci[1], 1)] if ci else None,
        "shown": shown,
        "mix": mix,
        "bluff_pct": round(100.0 * bluff_share, 1) if bluff_share is not None else None,
        "coverage": pct(shown, n),
        "strength": round(100.0 * mean(hs), 1) if hs else None,
        "strength_n": len(hs),
        "strength_dist": dist,
        "next": next_out,
        "got": got,
        "avg_size": avg_size,
        "size_street": size_street,
        "size_n": size_n,
        "pot_bb": round(mean(pots), 1) if pots else None,
        # What the hands that took the line won or lost, the whole hand, in bb.
        **money(rows),
        "call_ev": ev_call,
        "call_size": call_size,
        "catchers": catchers,
        "bluff_ev": ev_bluff,
        "bluff_size": bluff_size,
        # The share of the priced hands (`bluff_n`) where the bluff took the pot.
        "bluff_fold": bluff_fold,
        "bluff_n": bluff_n,
        "judged": n >= MIN_SAMPLE,
        "filter": filt,
        "trend": {
            "dir": trend((nr, orr), (nb, ob)),
            "recent": pct(nr, orr), "recent_n": nr, "recent_opp": orr,
            "before": pct(nb, ob), "before_n": nb, "before_opp": ob,
        },
    }
    if with_ids:
        out["hand_ids"] = [f.hand_id for f in rows]
    return out


def explore(
    facts: Iterable[Facts],
    path: Path | str,
    by: str = "size_seq",
    with_ids: bool = False,
    ctx: Context | None = None,
    base: str | None = None,
    skip_answers: Collection[tuple[int, str]] = frozenset(),
) -> dict:
    """The Line explorer's table for `path` over `facts`, which the caller has
    already narrowed to the spot (`base`, the filter that did it, starts every
    row's own). See SPEC.md, "Line explorer".

    `by` is one of BY; `ctx` names opponents for `vs` and each row's player for
    `player`, which needs `ctx.player_of` (the pool). `with_ids` adds each row's
    `hand_ids`. `skip_answers` holds the (hand_id, street) bets whose answer
    `got` leaves out: those the hero answered, on a table about others. Raises
    ValueError on a bad path or grouping.
    """
    if isinstance(path, str):
        path = parse_path(path)
    ctx = ctx or Context()
    check_by(by, pool=ctx.player_of is not None)
    spot = _Spot(path)
    recent = filters.parse_filter(f"last:{TREND_DAYS}d")
    facts = list(facts)
    matched = [f for f in facts if matches(path, f)]
    opp = [f for f in facts if opportunity(path, f)]
    head = _join(base, f"path={spot.term}")

    overall = _row(spot, "all", "Overall", head, matched, opp, recent, with_ids, skip_answers)
    rows: list[dict] = []
    if by == "size_seq":
        groups: dict[tuple[str, ...], list[Facts]] = defaultdict(list)
        for f in matched:
            groups[_size_key(path, f)].append(f)
        by_prefix: dict[tuple[str, ...], list[Facts]] = defaultdict(list)
        for f in opp:
            by_prefix[_size_key(path, f, spot.last)].append(f)
        for key, xs in groups.items():
            label = "-".join(key)
            rows.append(_row(spot, label, label, _join(base, _size_filter(path, key)), xs,
                             by_prefix[key[:-1]], recent, with_ids, skip_answers))
    elif by != "overall":
        d = DIMENSIONS[by]
        key_of, term_of, ident = d.key, d.term, d.ident

        def buckets(f: Facts) -> list[str]:
            k = key_of(f, ctx)
            if k is None:
                return []
            return list(dict.fromkeys(k)) if isinstance(k, list) else [k]

        labels: dict[str, str] = {}
        hit: dict[str, list[Facts]] = defaultdict(list)
        chances: dict[str, list[Facts]] = defaultdict(list)
        for f in opp:
            m = matches(path, f)
            for b in buckets(f):
                k = ident(b)
                labels.setdefault(k, b)
                chances[k].append(f)
                if m:
                    hit[k].append(f)
        for k, xs in chances.items():
            label = labels[k]
            shown_as = label.upper() if by == "ip" else f"{label}bb" if by == "depth" else label
            row = _row(spot, label, shown_as, _join(head, term_of(label)), hit[k], xs, recent, with_ids, skip_answers)
            if by == "player":
                row["player"] = label
            rows.append(row)
    rows.sort(key=lambda r: (-r["n"], -r["opp"], r["label"]))
    return {
        "path": spot.term,
        "by": by,
        "min_sample": MIN_SAMPLE,
        "trend_days": TREND_DAYS,
        "street": spot.street,
        "shown_street": spot.shown_street,
        # The share the page calls "bluffs": a river bet's or raise's. Elsewhere
        # it is draws and air (SPEC.md, "Value:bluff").
        "bluffs": spot.bets and spot.shown_street == POSTFLOP_STREETS[-1],
        "letter": spot.letter,
        "ev": "call" if spot.call else "bluff" if spot.bluff else None,
        "overall": overall,
        "rows": rows,
    }


# ---- the line box's suggestions --------------------------------------------------


def _paths_of(f: Facts) -> set[str]:
    """Every path `f` matches that has no size and no bracket, and whose blank
    streets are the only ones written empty: each street any prefix of its line,
    or blank before the last."""
    out: set[str] = set()
    opts: list[list[str]] = []
    for s in POSTFLOP_STREETS:
        line = f.line.get(s) or ""
        pre = [line[:k].upper() for k in range(1, len(line) + 1)]
        if pre:
            for combo in product(*opts):
                for p in pre:
                    out.add("-".join((*combo, p)))
        opts.append(["", *pre])
    return out


def shown_street(path: str) -> str:
    """The street a path's shown hands are read on, as the table reads them: the
    last with a bet or raise letter, else its last street. `path` is canonical
    text (`_paths_of`, `to_term`)."""
    parts = path.split("-")
    at = next((i for i in range(len(parts) - 1, -1, -1) if set(parts[i]) & {"B", "R"}), len(parts) - 1)
    return POSTFLOP_STREETS[at]


def path_stats(facts: Iterable[Facts]) -> dict[str, dict]:
    """`path_counts` with more per path, for the explorer's list of common lines:
    `n`, the shown hands' `mix` over CLASSES on the path's `shown_street`, and
    `net` in bb with `net_n`, the hands it counts (complete, with a known big
    blind, as `money` counts them).

    A path with no blank street also carries what pricing it needs (`look_marks`),
    read as its table reads them on its last street: `pot_bb`, the mean pot in bb;
    after a lone X or B there, the hands the table prices a bluff on (`priced`:
    after X those whose faced bet has an answer, after B those heads-up) and
    `took`, those where the bet took the pot, with `faced`, the median
    `faced_bet_pot` of the priced hands (`faced_n` of them, the table's
    `bluff_size`); on a river B or R, `own`, the median size of
    that bet or first raise (`own_n`, the table's `call_size`). None where no hand
    has one."""
    out: dict[str, dict] = {}
    river = POSTFLOP_STREETS[-1]
    for f in facts:
        cls_at: dict[tuple[str, bool], str | None] = {}
        net = f.net / f.bb_size if f.bb_size and f.complete else None
        pot = {st: f.pot_at[st] / f.bb_size for st in POSTFLOP_STREETS if st in f.pot_at and f.bb_size}
        for p in _paths_of(f):
            s = out.get(p)
            if s is None:
                s = out[p] = {"n": 0, "mix": dict.fromkeys(CLASSES, 0), "net": 0.0, "net_n": 0,
                              "pot": 0.0, "pot_n": 0}
            s["n"] += 1
            if net is not None:
                s["net"] += net
                s["net_n"] += 1
            if f.hole_cards is not None:
                st = shown_street(p)
                key = (st, _bets_on(p, st))
                if key not in cls_at:
                    cls_at[key] = _class_on(f, st, key[1])
                if cls_at[key] is not None:
                    s["mix"][cls_at[key]] += 1
            parts = p.split("-")
            if "" in parts:
                continue
            st = POSTFLOP_STREETS[len(parts) - 1]
            if st in pot:
                s["pot"] += pot[st]
                s["pot_n"] += 1
            last, line = parts[-1], f.line.get(st, "")
            if last in ("X", "B") and len(line) > 1:
                # As `_row` prices the bluff: after X the bet took the pot,
                # after B their fold, heads-up only.
                if last == "X":
                    took = f.street_bet_answer.get(st)
                    took = None if took is None else took == "fold"
                else:
                    took = line[1] == "f" if f.players_on.get(st) == 2 else None
                if took is not None:
                    s["priced"] = s.get("priced", 0) + 1
                    s["took"] = s.get("took", 0) + took
                    if st in f.faced_bet_pot:
                        s.setdefault("faced", []).append(f.faced_bet_pot[st])
            if st == river and last[-1] in "BR":
                k = len(last) - 1
                act = line[k]
                x = (f.bet_pot.get(st) if act == "b"
                     else f.raise_pot.get(st) if act == "r" and "r" not in line[:k] else None)
                if x is not None:
                    s.setdefault("own", []).append(x)
    for s in out.values():
        for name in ("faced", "own"):
            xs = s.pop(name, None) or []
            s[name], s[f"{name}_n"] = (round(median(xs), 3) if xs else None), len(xs)
        n = s.pop("pot_n")
        s["pot_bb"] = s.pop("pot") / n if n else None
    return out


def stat_row(path: str, s: dict) -> dict:
    """One common line of `path_stats` as the page reads it."""
    shown = sum(s["mix"].values())
    st = shown_street(path)
    bluffs = s["mix"]["semi_bluff"] + s["mix"]["bluff"]
    return {
        "path": path, "n": s["n"], "shown": shown, "mix": s["mix"],
        "bluff_pct": pct(bluffs, shown) if shown else None,
        "coverage": pct(shown, s["n"]),
        "bluffs": st == POSTFLOP_STREETS[-1] and _bets_on(path, st),
        "net_bb": round(s["net"], 2) if s["net_n"] else None,
        "bb_per_100": round(100 * s["net"] / s["net_n"], 2) if s["net_n"] else None,
    }


# ---- lines worth a look -------------------------------------------------------------

#: A line is worth a look at this many bb/100 on the table (SPEC.md, "Line
#: explorer", "Worth a look"); the page fills a mark with a worth.
LOOK_WORTH = 1.0
#: Off the pool marks a line on its own only when `strong` (twice POOL_GAP) over
#: this many hands of its sibling group; a weaker one stays in `look` unmarked.
LOOK_OFF_N = 200
#: A river bet's shown range is lopsided at this much value, or this many bluffs (%).
LOPSIDED_VALUE = 85.0
LOPSIDED_BLUFFS = 50.0
#: Siblings off the pool by the same gap: the first of these letters is the one named.
_LOOK_ORDER = "FRBXC"
_VERB = {"X": ("checks", "check"), "B": ("bets", "bet"), "C": ("calls", "call"),
         "F": ("folds", "fold"), "R": ("raises", "raise")}
_DOING = {"X": "checking", "B": "betting", "C": "calling", "R": "raising"}
_FACED = {"X": "bet", "B": "raise", "C": "raise", "R": "re-raise"}


def parent_path(path: str) -> tuple[str, bool]:
    """The plain line one action back and whether `path` is its next street's
    first action, as the page's tree hangs them: `XC` -> (`X`, False), `X-B` ->
    (`X`, True), `B` -> ("", False), the flop's actions under the root."""
    parts = path.split("-")
    if len(parts[-1]) > 1:
        return "-".join([*parts[:-1], parts[-1][:-1]]), False
    return "-".join(parts[:-1]), len(parts) > 1


def _plain(path: str) -> bool:
    return "" not in path.split("-")


def _shares(counts: Mapping[str, int]) -> tuple[dict[str, int], Counter]:
    """Plain paths' n, and each sibling group's total (`parent_path`): the
    page's Share is one over the other."""
    ns = {p: n for p, n in counts.items() if _plain(p)}
    totals: Counter = Counter()
    for p, n in ns.items():
        totals[parent_path(p)] += n
    return ns, totals


def _did(path: str, share: float, you: bool) -> str:
    """The share of a line in words, from the player's side or the hero's own:
    `XF` "folds 64% to a flop bet after checking", `B-X` "checks the turn 40%
    after B"."""
    parts = path.split("-")
    st, last = POSTFLOP_STREETS[len(parts) - 1], parts[-1]
    verb = ("you " if you else "") + _VERB[last[-1]][you]
    up = parent_path(path)[0]
    if len(last) > 1:
        where = f"after {_DOING[last[-2]]}" if len(parts) == 1 else f"after {up}"
        return f"{verb} {round(share)}% to a {st} {_FACED[last[-2]]} {where}"
    return f"{verb} the {st} {round(share)}%" + (f" after {up}" if up else "")


def _sure(num: int, den: int, base: float) -> float:
    """`num` / `den` only as far from `base` (a fraction) as its 95% interval is
    sure of: the interval's end nearest `base`, or `base` when it holds it."""
    lo, hi = wilson(num, den)
    return lo if lo > base else min(base, hi)


def look_marks(player_stats: Mapping[str, dict], pool_stats: Mapping[str, dict], hands: int,
               you: bool = False) -> dict[str, dict]:
    """The lines worth a look in one player's `path_stats` against the pool's
    (its `n` and `mix`), over the player's `hands` in the spot: `{path: {"worth",
    "play", "off_pool", "lopsided", "why", "mark"}}` for every plain path with
    any of the three (SPEC.md, "Line explorer", "Worth a look").

    `worth` is the bb/100 that playing them as they are, not as the pool, wins on
    the line, and `play` how: "bluff more", "bluff less", "call more" or "fold
    more". `off_pool` is the line's share of its siblings against the pool's
    (`queries.pool_outlier`), the furthest off of each sibling group only;
    `lopsided` a river bet's shown range, "value" or "bluffs". `mark` is whether
    the page marks it. `you` words `why` as the hero's own (self-scout): the
    same numbers, read as leaks."""
    from .queries import POOL_MIN_N, pool_outlier

    mine, totals = _shares({p: s["n"] for p, s in player_stats.items()})
    pool_n, pool_totals = _shares({p: s["n"] for p, s in pool_stats.items()})

    def pool_share(p: str) -> float | None:
        of = pool_totals.get(parent_path(p), 0)
        return pool_n.get(p, 0) / of if of >= POOL_MIN_N else None

    # Off the pool: per sibling group, the one furthest off.
    best: dict[tuple[str, bool], tuple[float, int, str, dict]] = {}
    for p, n in mine.items():
        group = parent_path(p)
        den, theirs = totals[group], pool_share(p)
        if den < MIN_SAMPLE or theirs is None:
            continue
        mark = pool_outlier(n, den, round(100 * theirs, 1))
        if mark is None:
            continue
        share = 100 * n / den
        rank = (round(abs(share - 100 * theirs), 1), -_LOOK_ORDER.index(p[-1]))
        if group not in best or rank > best[group][:2]:
            best[group] = (*rank, p, {**mark, "share": round(share, 1), "n": den})
    off = {p: mark for _, _, p, mark in best.values()}

    river = POSTFLOP_STREETS[-1]
    out: dict[str, dict] = {}
    for p in mine:
        s = player_stats[p]
        parts = p.split("-")
        st, last = POSTFLOP_STREETS[len(parts) - 1], parts[-1]
        pot = s.get("pot_bb")
        said: list[str] = []
        if p in off:
            said.append(f"{_did(p, off[p]['share'], you)}; pool {round(off[p]['pool'])}%")
        # Each play's edge over playing them as the pool, in % of the pot, and
        # its chances.
        plays: list[tuple[float, int, str]] = []
        # A bluff into their lone X or B: they face the bet (or raise) next,
        # priced as the table prices it (`path_stats`' `priced` and `took`).
        next_n, folds = s.get("priced", 0), s.get("took", 0)
        p0 = pool_stats.get(p, {})
        f0 = p0["took"] / p0["priced"] if p0.get("priced", 0) >= POOL_MIN_N else None
        if last in ("X", "B") and next_n >= MIN_SAMPLE and s.get("faced") is not None:
            share = 100 * folds / next_n
            said.append((_did(p + "F", share, you) if last == "B"
                         else f"a {st} bet after {p} takes the pot {round(share)}%")
                        + (f"; pool {round(100 * f0)}%" if f0 is not None else ""))
            if f0 is not None:
                edge = bluff_ev(_sure(folds, next_n, f0), s["faced"]) - bluff_ev(f0, s["faced"])
                plays.append((edge, next_n, "bluff"))
        # Calling their river bet or raise with a bluff-catcher.
        shown = sum(s["mix"].values())
        bluffs = s["mix"]["semi_bluff"] + s["mix"]["bluff"]
        lopsided = None
        if st == river and last[-1] in "BR" and shown >= MIN_SAMPLE:
            value = 100 * s["mix"]["value"] / shown
            lopsided = ("value" if value >= LOPSIDED_VALUE
                        else "bluffs" if 100 * bluffs / shown >= LOPSIDED_BLUFFS else None)
            mix0 = pool_stats.get(p, {}).get("mix")
            shown0 = sum(mix0.values()) if mix0 else 0
            b0 = (mix0["semi_bluff"] + mix0["bluff"]) / shown0 if shown0 >= POOL_MIN_N else None
            what = f"{round(value)}% value" if lopsided == "value" else f"{round(100 * bluffs / shown)}% bluffs"
            pool_said = f"; pool {round(100 * b0)}% bluffs" if b0 is not None and lopsided != "value" else ""
            said.append(f"{'you show' if you else 'shows'} {what} (n {shown}){pool_said}")
            if b0 is not None and s.get("own") is not None:
                edge = call_ev(_sure(bluffs, shown, b0), s["own"]) - call_ev(b0, s["own"])
                plays.append((edge, s["n"], "call"))
        # In bb/100 of their hands: the edge on each chance, times the chances.
        priced = [(abs(e) * pot * k / hands, e, kind) for e, k, kind in plays if pot and hands]
        top = max(priced, default=None)
        worth = play = None
        if top is not None and top[0] > 0:
            worth = round(top[0], 2)
            play = _PLAY[top[2], top[1] > 0]
            said.append(f"{_YOU_PLAY[play] if you else play}: {worth:.1f} bb/100")
        if worth is None and p not in off and lopsided is None:
            continue
        out[p] = {
            "worth": worth,
            "play": play,
            "off_pool": off.get(p),
            "lopsided": lopsided,
            "why": " · ".join(said),
            "mark": ((worth is not None and worth >= LOOK_WORTH) or lopsided is not None
                     or (p in off and off[p]["strong"] and off[p]["n"] >= LOOK_OFF_N)),
        }
    return out


#: The play a line's edge asks for: (kind, edge > 0) -> words, and as the hero
#: reads it of their own line.
_PLAY = {("bluff", True): "bluff more", ("bluff", False): "bluff less",
         ("call", True): "call more", ("call", False): "fold more"}
_YOU_PLAY = {"bluff more": "bluff you more", "bluff less": "bluff you less",
             "call more": "call you more", "fold more": "fold to you more"}


def pool_less(pool_stats: Mapping[str, dict], player_stats: Mapping[str, dict]) -> dict[str, dict]:
    """The pool's `n`, `mix`, `priced` and `took` per path less one player's:
    the pool `look_marks` reads when the player is in it."""
    out = {}
    for p, s in pool_stats.items():
        mine = player_stats.get(p)
        if mine is None:
            out[p] = {"n": s["n"], "mix": s["mix"],
                      **{k: s[k] for k in ("priced", "took") if k in s}}
            continue
        out[p] = {"n": max(0, s["n"] - mine["n"]),
                  "mix": {c: max(0, k - mine["mix"][c]) for c, k in s["mix"].items()},
                  **{k: max(0, s[k] - mine.get(k, 0)) for k in ("priced", "took") if k in s}}
    return out


def path_counts(facts: Iterable[Facts]) -> Counter:
    """How many of `facts` each path in `_paths_of` matches: exactly what the
    `path=` term would count for it."""
    c: Counter = Counter()
    for f in facts:
        c.update(_paths_of(f))
    return c


def canonical_prefix(prefix: str) -> str:
    return re.sub(r"\s+", "", prefix or "").upper()


def suggest(counts: Counter, prefix: str = "", limit: int = 20) -> list[dict]:
    """The most common paths starting with `prefix` (case and spaces forgiven),
    `[{path, n}]`, most hands first, shorter first on a tie."""
    want = canonical_prefix(prefix)
    hits = [(p, n) for p, n in counts.items() if p.startswith(want)]
    hits.sort(key=lambda x: (-x[1], len(x[0]), x[0]))
    return [{"path": p, "n": n} for p, n in hits[:limit]]
