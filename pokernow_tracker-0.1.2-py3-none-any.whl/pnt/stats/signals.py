"""Tab hints: which of the chart's views hold a read on a player.

A view gets a hint when its own report says something the player does that a
regular would not, judged the way that report judges it. Each check reads a
report the view already builds, so a hint and its tab never disagree:

- ``timing``: in some spot, the hands behind their quick and slow decisions
  differ -- the two buckets' value shares have non-overlapping Wilson intervals
  (`timing.timing_report`), their own-median buckets first, the pool's cuts when
  those are thin.
- ``tilt``: VPIP or aggression after a big loss is off every other hand's by
  non-overlapping intervals and POOL_GAP points (`tilt.tilt_report`).
- ``shows``: the share of air in their two-card voluntary shows is off the
  other players' (`shows.air_counts`, `queries.pool_outlier`).
- every other view but Range: an exploit tag whose ``by`` opens that view
  (`tags.tags_for`), already judged against the pool.

Each hint is ``{"level": "strong"|"some", "why": "<one clause>"}``; a view with
nothing to say is absent. See SPEC.md, "Tab hints".
"""

from __future__ import annotations

import sqlite3
import statistics
from collections.abc import Iterable, Mapping

from .derive import Facts
from .queries import POOL_GAP, POOL_MIN_PLAYERS, facts_cached, pool_outlier, remembered, trend
from .tilt import tilt_report
from .timing import BUCKETS_OF, timing_report

#: Known hands each of the two tempo buckets needs before their split is read.
TIMING_MIN = 10
#: Hands the post-loss window needs before it is set against every other hand.
TILT_MIN = 20
#: Two-card voluntary shows a player needs to be judged on air, and to count
#: toward the pool's share.
SHOWS_MIN = 10

#: Tag labels a hint names before "+N more".
TAG_LABELS = 3
#: A tag whose ``by`` would open another view than the one its read is about.
TAG_VIEW = {"tilts": "tilt"}
#: Views no tag hints: Range is where the chart opens, and it lists the tags.
NO_TAG_HINT = frozenset({"preflop"})

#: Each tempo bucket as the hint words it.
_QUICK_WORD = {"snap": "snaps", "pre": "pre-selected"}


def _plural(label: str) -> str:
    """"River bet" -> "river bets"."""
    return f"{label.lower()}s"


def _value(row: Mapping) -> tuple[int, int]:
    """A timing row's (value hands, known hands)."""
    c = row["counts"]
    return c["nutted"] + c["strong"], row["known"]


def _timing_spot(spot: Mapping, quick: str) -> dict | None:
    """The hint one spot's block gives, or None: its `quick` bucket against its
    tank bucket, each with TIMING_MIN known hands, intervals apart."""
    rows = {r["bucket"]: r for r in spot["rows"]}
    q, t = rows.get(quick), rows.get("tank")
    if q is None or t is None or q["known"] < TIMING_MIN or t["known"] < TIMING_MIN:
        return None
    if trend(_value(t), _value(q), TIMING_MIN) == "flat":
        return None
    gap = abs(t["value"] - q["value"])
    return {
        "level": "strong" if gap >= 2 * POOL_GAP else "some",
        "why": f"tanked {_plural(spot['label'])} {t['value']:g}% value, {_QUICK_WORD[quick]} {q['value']:g}%",
        "gap": gap,
    }


def _read(spot: Mapping | None, quick: str) -> bool:
    """Whether a spot's own-median block had enough hands to read: then its
    answer stands, firing or not, and the pool's cuts are not asked."""
    if spot is None:
        return False
    rows = {r["bucket"]: r for r in spot["rows"]}
    return all(b in rows and rows[b]["known"] >= TIMING_MIN for b in (quick, "tank"))


def timing_signal(report: Mapping) -> dict | None:
    """The timing hint from a `timing_report`: the spot whose quick and slow
    hands differ most. Per spot, the buckets cut on their own median when both
    have enough known hands, else the pool's cuts (where a call's quick end is
    the pre-selected click)."""
    own = {sp["key"]: sp for sp in (report.get("relative") or {}).get("spots", [])}
    best = None
    for spot in report["spots"]:
        letter = "b" if spot["key"].endswith("_bet") else "c"
        mine = own.get(spot["key"])
        got = _timing_spot(mine, "snap") if mine is not None else None
        if got is None and not _read(mine, "snap"):
            got = _timing_spot(spot, "snap" if "snap" in BUCKETS_OF[letter, "pool"] else "pre")
        if got is not None and (best is None or got["gap"] > best["gap"]):
            best = got
    return None if best is None else {"level": best["level"], "why": best["why"]}


def tilt_signal(report: Mapping) -> dict | None:
    """The tilt hint from a `tilt_report`: VPIP or aggression in the post-loss
    window against every other hand, the larger gap of the two that hold."""
    rows = {r["key"]: r for t in report["tables"] if t["key"] == "loss" for r in t["rows"]}
    post, rest = rows.get("post_loss"), rows.get("other")
    if post is None or rest is None or post["hands"] < TILT_MIN:
        return None
    best = None
    for key, word in (("vpip", "VPIP"), ("af", "aggression")):
        if post[key] is None or rest[key] is None:
            continue
        mine = (post[f"{key}_hits"], post[f"{key}_n"])
        other = (rest[f"{key}_hits"], rest[f"{key}_n"])
        gap = abs(post[key] - rest[key])
        if gap < POOL_GAP or trend(mine, other, TILT_MIN) == "flat":
            continue
        if best is None or gap > best[0]:
            best = (gap, f"{word} {post[key]:g}% after a big loss, {rest[key]:g}% otherwise")
    if best is None:
        return None
    return {"level": "strong" if best[0] >= 2 * POOL_GAP else "some", "why": best[1]}


def shows_signal(air_by_player: Mapping[str, tuple[int, int]], alias: str) -> dict | None:
    """The shows hint: `alias`'s share of air among their two-card shows off
    the pool's, by `queries.pool_outlier`. The pool's share is the median of the
    *other* players with SHOWS_MIN two-card shows, and needs POOL_MIN_PLAYERS of
    them; `alias` needs SHOWS_MIN too. `air_by_player` is `shows.air_counts`."""
    air, two = air_by_player.get(alias, (0, 0))
    others = [100 * a / n for p, (a, n) in air_by_player.items() if p != alias and n >= SHOWS_MIN]
    if two < SHOWS_MIN or len(others) < POOL_MIN_PLAYERS:
        return None
    pool = round(statistics.median(others), 1)
    mark = pool_outlier(air, two, pool)
    if mark is None:
        return None
    rate = round(100 * air / two)
    why = (f"shows air {rate}% of the time; pool {pool:g}%" if mark["dir"] == "high"
           else f"shows air only {rate}% of the time; pool {pool:g}%")
    return {"level": "strong" if mark["strong"] else "some", "why": why}


def tag_signals(tags: Iterable[Mapping]) -> dict[str, dict]:
    """Per view, the hint its exploit tags give: their labels, strong when any
    of them is 2×POOL_GAP or more off the pool's rate. Never the Range tab: it
    is where the chart opens, and it lists the tags already."""
    by_view: dict[str, list[Mapping]] = {}
    for t in tags:
        view = TAG_VIEW.get(t["id"], t.get("by") or "preflop")
        if t.get("kind") == "exploit" and view not in NO_TAG_HINT:
            by_view.setdefault(view, []).append(t)
    out = {}
    for view, ts in by_view.items():
        strong = any(
            t.get("pool_pct") is not None and t.get("pct") is not None
            and abs(t["pct"] - t["pool_pct"]) >= 2 * POOL_GAP
            for t in ts
        )
        labels = [t["label"].lower() for t in ts]
        more = f" +{len(labels) - TAG_LABELS} more" if len(labels) > TAG_LABELS else ""
        out[view] = {"level": "strong" if strong else "some", "why": ", ".join(labels[:TAG_LABELS]) + more}
    return out


def signals(
    conn: sqlite3.Connection, alias: str, facts: list[Facts], game: str | None = None, *,
    tilt: Mapping | None = None,
) -> dict[str, dict]:
    """Every view's hint for `alias`: ``{view: {"level", "why"}}``, the views with
    nothing left out. `facts` are their hands in the spot, which timing and tilt
    read; the tags and shows read their whole record. `tilt` is the spot's
    `tilt_report` when the caller already has it. Raises ValueError on an unknown
    alias."""
    from .pool import pool_for
    from .shows import air_counts
    from .tags import tags_for

    whole = facts_cached(conn, alias, game)
    out = tag_signals(tags_for(whole, pool_for(conn, game), alias)["tags"])
    # Every player's shows in one pass, kept until the next write: each
    # player's hint reads the same pool.
    air = remembered(conn, ("shows-air", game), lambda: air_counts(conn, game))
    checks = {
        "timing": timing_signal(timing_report(facts, baseline=whole)),
        "tilt": tilt_signal(tilt if tilt is not None else tilt_report(facts)),
        "shows": shows_signal(air, alias),
    }
    # A view's own check speaks for it over a tag that happens to open it.
    for view, hint in checks.items():
        if hint is not None:
            out[view] = hint
    return out
