"""Load hands from SQLite, derive facts, aggregate.

Deliberately reads raw rows and derives in Python rather than expressing the
opportunity logic as SQL window functions. The bet-level walk and the c-bet
opportunity rules are sequential reasoning about a hand; written in SQL they are
correct-looking and unreviewable, and SPEC.md could no longer be checked against
them by eye.

If this ever gets slow, the escape hatch is the one the design already allows:
materialize `Facts` into a rollup table marked derived and disposable, rebuilt
from `actions`. Never make it the source of truth.
"""

from __future__ import annotations

import json
import math
import sqlite3
import threading
from collections import Counter, defaultdict
from collections.abc import Callable, Collection, Hashable, Iterable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from fractions import Fraction
from operator import attrgetter
from typing import Self

from ..db.conn import generation, path_of, reading
from ..logfmt.parser import position_name
from . import strength
from .derive import (
    ANALYSED_SQL,
    ANSWERS,
    SIZE_BUCKETS,
    Facts,
    HandAction,
    HandPlayerRow,
    HandRow,
    derive,
    pct,
)
from .lru import LRU
from .tilt import annotate


def load_hands(
    conn: sqlite3.Connection,
    game_id: str | None = None,
    pn_ids: Collection[str] | None = None,
    hand_ids: Collection[int] | None = None,
) -> list[HandRow]:
    """Load hands with their rosters and actions.

    `pn_ids` keeps only the hands those identities were dealt into -- and keeps
    each of those hands *whole*, every player and every action. That matters: a
    hand is derived as a unit (the bet-level walk needs everyone), so narrowing the
    roster would change the answer, while narrowing the set of hands does not.

    One player's figures therefore cost one player's hands, instead of the whole
    database re-derived and then discarded down to them.

    `hand_ids` narrows to exactly those hands, for a caller that has already picked
    its population in SQL (the all-in showdowns, say) and wants them whole.
    """
    strength.prime(conn)  # once per database: hand strengths stored by `warm`
    clauses, params = [], []
    if game_id:
        clauses.append("h.game_id = ?")
        params.append(game_id)
    if pn_ids is not None:
        ids = list(pn_ids)
        if not ids:
            return []
        clauses.append(
            "h.hand_id IN (SELECT hand_id FROM hand_players WHERE pn_id IN"
            f" ({','.join('?' * len(ids))}))"
        )
        params.extend(ids)
    if hand_ids is not None:
        wanted = list(hand_ids)
        if not wanted:
            return []
        clauses.append(f"h.hand_id IN ({','.join('?' * len(wanted))})")
        params.extend(wanted)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    params = tuple(params)

    hands: dict[int, HandRow] = {}
    for r in conn.execute(
        f"""SELECT h.hand_id, h.game_id, h.hand_number, h.n_dealt_in, h.dead_button,
                   h.blinds_irregular, h.went_to_showdown, h.board_json, h.ts,
                   h.complete, h.run_count, COALESCE(h.bb, g.bb) AS bb,
                   h.board_ords, h.clock_ms, h.variant, h.double_board
            FROM hands h LEFT JOIN games g ON g.game_id = h.game_id
            {where} ORDER BY h.ord""",
        params,
    ):
        runs = json.loads(r["board_json"] or "[]")
        # "saw a flop" == the first run has at least three cards
        saw_flop = bool(runs) and len(runs[0]) >= 3
        hands[r["hand_id"]] = HandRow(
            hand_id=r["hand_id"],
            game_id=r["game_id"],
            hand_number=r["hand_number"],
            n_dealt_in=r["n_dealt_in"],
            dead_button=bool(r["dead_button"]),
            blinds_irregular=bool(r["blinds_irregular"]),
            went_to_showdown=bool(r["went_to_showdown"]),
            saw_flop=saw_flop,
            complete=bool(r["complete"]),
            bb=r["bb"],
            ts=r["ts"],
            players={},
            actions=[],
            board=tuple(runs[0]) if runs else (),
            run_count=r["run_count"] or 1,
            board_ords=json.loads(r["board_ords"]) if r["board_ords"] else {},
            clock_ms=r["clock_ms"],
            variant=r["variant"],
            double_board=bool(r["double_board"]),
            board2=tuple(runs[1]) if r["double_board"] and len(runs) > 1 else (),
        )

    for r in conn.execute(
        f"""SELECT hp.* FROM hand_players hp JOIN hands h ON h.hand_id = hp.hand_id {where}""",
        params,
    ):
        h = hands.get(r["hand_id"])
        if h is not None:
            h.players[r["pn_id"]] = HandPlayerRow(
                pn_id=r["pn_id"],
                seat=r["seat"],
                seats_from_button=r["seats_from_button"],
                contributed=r["contributed"],
                collected=r["collected"],
                bounty=r["bounty"],
                nit=r["nit"],
                folded=bool(r["folded"]),
                hole_cards=r["hole_cards"],
                starting_stack=r["starting_stack"],
            )

    for r in conn.execute(
        f"""SELECT a.* FROM actions a JOIN hands h ON h.hand_id = a.hand_id {where}
            ORDER BY a.hand_id, a.seq""",
        params,
    ):
        h = hands.get(r["hand_id"])
        if h is not None:
            h.actions.append(
                HandAction(
                    seq=r["seq"],
                    street=r["street"],
                    pn_id=r["pn_id"],
                    kind=r["action_type"],
                    amount=r["amount"],
                    is_forced=bool(r["is_forced"]),
                    all_in=bool(r["all_in"]),
                    amount_to=r["amount_to"],
                    post_kind=r["post_kind"],
                    ord=r["ord"],
                )
            )

    return list(hands.values())


def identity_map(conn: sqlite3.Connection) -> dict[str, tuple[int, str]]:
    """pn_id -> (player_id, alias). Collapses multi-device identities into one person."""
    return {
        r["pn_id"]: (r["player_id"], r["alias"])
        for r in conn.execute(
            "SELECT pi.pn_id, pi.player_id, p.alias FROM player_identities pi"
            " JOIN players p ON p.player_id = pi.player_id"
        )
    }


def player_key(ident: Mapping[str, tuple[int, str]], pn_id: str) -> tuple[int | str, str]:
    """(player key, alias) of `pn_id` in an `identity_map`. An ID with no identity
    row (none today: a rebuild resolves every seat) is its own player, keyed and
    named by itself, never one stand-in shared by every such ID."""
    return ident.get(pn_id, (pn_id, pn_id))


def display_names(conn: sqlite3.Connection) -> dict[str, str]:
    """pn_id -> the name a drill-down should print.

    The canonical alias when there is one, otherwise the last name PokerNow showed
    for that ID -- the same rule the replay endpoint uses. Resolved at read time,
    so a merge or a rename shows up on the next request without re-deriving.
    """
    return {
        r["pn_id"]: r["alias"] or r["last_seen_name"] or r["pn_id"]
        for r in conn.execute(
            "SELECT pi.pn_id, pi.last_seen_name, p.alias FROM player_identities pi"
            " LEFT JOIN players p ON p.player_id = pi.player_id"
        )
    }


def wilson(num: int, den: int, z: float = 1.96) -> tuple[float, float] | None:
    """The Wilson score interval for `num` successes in `den` trials, as fractions.

    None when there are no trials: an empty sample has no interval, the way it
    has no rate. See SPEC.md, "Confidence intervals".
    """
    if den <= 0:
        return None
    p = num / den
    z2 = z * z
    centre = (p + z2 / (2 * den)) / (1 + z2 / den)
    half = z * math.sqrt(p * (1 - p) / den + z2 / (4 * den * den)) / (1 + z2 / den)
    return (max(0.0, centre - half), min(1.0, centre + half))


#: The trailing window a trend arrow compares against everything before it.
TREND_DAYS = 30
#: Each side of a trend needs this many chances before it can point anywhere:
#: the smallest sample the exploit tags fire on (SPEC.md, "Tags").
TREND_MIN = 10


def trend(recent: tuple[int, int], before: tuple[int, int], min_n: int = TREND_MIN) -> str:
    """Has a rate moved between two samples: "up", "down" or "flat".

    `recent` and `before` are each ``(num, den)``. It points only when both
    sides have at least `min_n` chances and their Wilson intervals do not
    overlap; anything less is "flat", the honest answer for a small sample.
    See SPEC.md, "Trends".
    """
    (rn, rd), (bn, bd) = recent, before
    if rd < min_n or bd < min_n:
        return "flat"
    r, b = wilson(rn, rd), wilson(bn, bd)
    if r[0] > b[1]:
        return "up"
    if r[1] < b[0]:
        return "down"
    return "flat"


#: Judging a player against the pool they play in (SPEC.md, "Pool baseline"). A
#: baseline is the median of the other players' rates, each player once, over the
#: players with the minimum sample; with fewer than POOL_MIN_PLAYERS of them there
#: is none. A player is off the pool when their 95% interval (POOL_Z) excludes the
#: pool's rate and the gap is at least POOL_GAP points. Defined here, beside
#: `wilson`, because `tags` imports this module; `tags` re-exports them.
POOL_MIN_PLAYERS = 5
POOL_Z = 1.96
POOL_GAP = 8
#: A player counts toward a stats-table baseline with this many chances on the rate.
POOL_MIN_N = 20


def pool_outlier(num: int, den: int, pool_pct: float, *, gap: float | None = None) -> dict | None:
    """Is `num` of `den` off the pool's `pool_pct` (points): None, or
    ``{"dir": "high"|"low", "pool": pool_pct, "ci": [lo, hi], "strong": bool}``.

    It is when the 95% Wilson interval excludes `pool_pct` and the gap is at
    least `gap` points (POOL_GAP by default); `strong` at twice the gap. `ci` is
    the interval in points. See SPEC.md, "Outliers against the pool".
    """
    if den <= 0:
        return None
    gap = POOL_GAP if gap is None else gap
    lo, hi = wilson(num, den, POOL_Z)
    rate = 100 * num / den
    if 100 * lo > pool_pct and rate - pool_pct >= gap:
        side = "high"
    elif 100 * hi < pool_pct and pool_pct - rate >= gap:
        side = "low"
    else:
        return None
    return {"dir": side, "pool": pool_pct, "ci": [round(100 * lo, 1), round(100 * hi, 1)],
            "strong": abs(rate - pool_pct) >= 2 * gap}


def pool_marks(
    counts_by_player: Mapping[Hashable, Mapping[str, tuple[int, int]]],
    players: Iterable[Hashable] | None = None,
) -> dict[Hashable, dict[str, dict]]:
    """Each of `players`' rates that stand out from the rest of the pool:
    ``{player: {key: pool_outlier(...) + {"players": n}}}``.

    `counts_by_player` is every player in the spot (key -> `rate_counts`), before
    any min-hands cut, so the cut never shrinks the pool. A rate's baseline is the
    median of the *other* players' rates over those with POOL_MIN_N chances on it,
    and needs POOL_MIN_PLAYERS of them; the player needs TREND_MIN chances. A
    player with nothing off the pool gets an empty dict. See SPEC.md, "Outliers
    against the pool".
    """
    import statistics

    # key -> [(player, rate)] over the players qualified on it.
    pool: dict[str, list[tuple[Hashable, float]]] = defaultdict(list)
    for who, counts in counts_by_player.items():
        for key, (num, den) in counts.items():
            if den >= POOL_MIN_N:
                pool[key].append((who, 100 * num / den))
    out: dict[Hashable, dict[str, dict]] = {}
    for who in counts_by_player if players is None else players:
        marks = out[who] = {}
        for key, (num, den) in counts_by_player.get(who, {}).items():
            if den < TREND_MIN:
                continue
            others = [r for p, r in pool.get(key, ()) if p != who]
            if len(others) < POOL_MIN_PLAYERS:
                continue
            mark = pool_outlier(num, den, round(statistics.median(others), 1))
            if mark is not None:
                marks[key] = {**mark, "players": len(others)}
    return out


def _ci(n: int, total: Fraction, sq: Fraction) -> float | None:
    """Half-width of a bb/100's 95% interval: 1.96 · sd / √n · 100, from the sample
    standard deviation of each hand's x in big blinds, given n, Σx and Σx². None
    under two hands."""
    if n < 2:
        return None
    var = (sq - total * total / n) / (n - 1)
    return round(1.96 * math.sqrt(max(float(var), 0.0)) / math.sqrt(n) * 100, 2)


#: Per-hand flags a player's row counts, and the per-street ones.
_FLAGS = (
    "vpip", "vpip_opp", "pfr", "pfr_opp", "three_bet", "three_bet_opp",
    "fold_to_3bet", "fold_to_3bet_opp", "wtsd", "wtsd_opp", "wsd",
    # SPEC.md: "Won when saw flop", "Steals and blind defense", "Squeeze and
    # cold-call", and the limp and preflop-jam families. Several are `Facts`
    # properties read from the stored facts.
    "won_pot", "wwsf", "wwsf_nsd",
    "steal", "steal_opp", "fold_to_steal", "fold_to_steal_opp", "three_bet_vs_steal",
    "squeeze", "squeeze_opp", "cold_call", "cold_call_opp",
    "limp", "limp_raise", "limp_call", "limp_fold",
    "jam_pf", "jam_pf_opp",
)
_STREETS = ("flop", "turn", "river")
_STREET_FLAGS = (
    "cbet", "cbet_opp", "fold_to_cbet", "fold_to_cbet_opp", "raise_cbet", "donk", "donk_opp",
    "check_raise", "check_raise_opp",
    # SPEC.md, "Delayed c-bet, probe and float".
    "delayed_cbet", "delayed_cbet_opp", "probe", "probe_opp",
    "fold_to_probe", "fold_to_probe_opp", "float_bet", "float_opp",
)
#: The streets each of those families exists on. Delayed c-bets and probes need
#: a postflop street before them; a float can follow the preflop raise.
_LATE_STREETS = ("turn", "river")
#: Per-street *action* counts rather than hand counts: one hand can add several.
_STREET_COUNTS = ("aggressive", "agg_denom")


#: The per-hand flags and per-street dicts, read off a `Facts` in one call each:
#: `Tally.add` runs once per player per hand, and one `getattr` per name was a
#: third of its time.
_flags_of = attrgetter(*_FLAGS)
_street_flags_of = attrgetter(*_STREET_FLAGS)
_street_counts_of = attrgetter(*_STREET_COUNTS)

#: The slots of `Tally.by_bb`: per big-blind size, integer sums in chips.
_NET, _NET_SQ, _POSTED, _VF_SQ, _IDLE = range(5)


class Tally:
    """Everything `aggregate` reports, kept as sums, so tallies add.

    A tally of two sets of hands is the sum of their tallies, which is what lets a
    lifetime report be assembled from per-game pieces: a rebuild then re-derives
    one game instead of every hand in the database. `rates` turns one into the
    stat row. bb/100 is exact, so the order the pieces are added in cannot move a
    figure by so much as a rounding step: chips are summed as integers per big
    blind size (`by_bb`), and only turned into big blinds -- as fractions -- when a
    figure is read. A database has a handful of blind sizes; it has many thousands
    of hands, and a Fraction added per hand was most of a report's time.
    """

    __slots__ = ("bb_n", "by_bb", "counts", "hands", "net")

    def __init__(self) -> None:
        self.hands = 0
        self.counts: Counter = Counter()
        self.net = 0
        self.bb_n = 0
        #: bb size -> [Σnet, Σnet², Σposted, Σ(net + posted)², Σidle net], in chips,
        #: over the complete hands with a known big blind. See the properties below.
        self.by_bb: dict[int, list[int]] = {}

    def _in_bb(self, slot: int, squared: bool = False) -> Fraction:
        return sum((Fraction(s[slot], bb * bb if squared else bb) for bb, s in self.by_bb.items()), Fraction(0))

    @property
    def bb_sum(self) -> Fraction:
        """Σ net / bb: each hand normalized by *its own* big blind. Blind levels
        move within a game, so dividing a whole session's net by one bb would
        silently rescale history."""
        return self._in_bb(_NET)

    @property
    def bb_sq(self) -> Fraction:
        """Σ (net / bb)² over the same hands as `bb_sum`: the spread behind bb/100's
        confidence interval. See SPEC.md, "Confidence intervals"."""
        return self._in_bb(_NET_SQ, squared=True)

    # bb/100 against folding (SPEC.md, "bb/100 against folding"), over the same
    # hands as `bb_sum`: Σ posted_bb where they had a decision (preflop, or postflop
    # in a bomb pot), Σ net_bb where they had none (a walk, which folding could not
    # change), and Σx² of each hand's net_bb + posted_bb, 0 on a hand with no decision.
    @property
    def posted(self) -> Fraction:
        return self._in_bb(_POSTED)

    @property
    def idle(self) -> Fraction:
        return self._in_bb(_IDLE)

    @property
    def vf_sq(self) -> Fraction:
        return self._in_bb(_VF_SQ, squared=True)

    def add(self, x: Facts) -> None:
        c = self.counts
        self.hands += 1
        for attr, on in zip(_FLAGS, _flags_of(x)):
            if on:
                c[attr] += 1
        net = x.net
        self.net += net
        bb = x.bb_size
        if bb and x.complete:
            s = self.by_bb.get(bb)
            if s is None:
                s = self.by_bb[bb] = [0, 0, 0, 0, 0]
            s[_NET] += net
            s[_NET_SQ] += net * net
            self.bb_n += 1
            # A decision: preflop, or -- in a bomb pot, which has none there --
            # on any postflop street (`line`). See SPEC.md, call 2 there.
            if x.vpip_opp or x.line:
                s[_POSTED] += x.posted
                s[_VF_SQ] += (net + x.posted) ** 2
            else:
                s[_IDLE] += net
        flags, counts = _street_flags_of(x), _street_counts_of(x)
        for street in _STREETS:
            for attr, by_street in zip(_STREET_FLAGS, flags):
                if by_street.get(street):
                    c[attr, street] += 1
            for attr, by_street in zip(_STREET_COUNTS, counts):
                c[attr, street] += by_street.get(street, 0)
            # How big their c-bets are, and how they answer each size of c-bet.
            if x.cbet.get(street):
                c["cbet_size", street, x.bet_size.get(street)] += 1
            b = x.faced_cbet_size.get(street)
            if b is not None:
                c["faced", street, b] += 1
                c["faced_fold", street, b] += bool(x.fold_to_cbet.get(street))
                c["faced_raise", street, b] += bool(x.raise_cbet.get(street))
            # Every first bet by its size, and what it got back; and every first
            # bet or raise faced, c-bet or not, by its size and what they did.
            b = x.bet_size.get(street)
            if b is not None:
                c["bet_n", street, b] += 1
                answer = x.bet_answer.get(street)
                if answer is not None:
                    c["bet_got", street, b, answer] += 1
            b = x.faced_bet_size.get(street)
            if b is not None:
                c["vs_bet", street, b] += 1
                c["vs_bet_did", street, b, x.faced_bet_action[street]] += 1

    def __iadd__(self, other: Tally) -> Self:
        self.hands += other.hands
        self.counts.update(other.counts)
        self.net += other.net
        self.bb_n += other.bb_n
        for bb, theirs in other.by_bb.items():
            mine = self.by_bb.get(bb)
            if mine is None:
                self.by_bb[bb] = list(theirs)
            else:
                for i, v in enumerate(theirs):
                    mine[i] += v
        return self


def _vs_fold(t: Tally) -> Fraction:
    """Σ (net_bb + posted_bb) over the hands with a decision: bb won against folding."""
    return t.bb_sum - t.idle + t.posted


def tally(facts: Iterable[Facts]) -> Tally:
    t = Tally()
    for x in facts:
        t.add(x)
    return t


def rates(t: Tally) -> dict:
    """A tally as the v1 stat set.

    Every rate returns None -- not 0 -- when the denominator is empty. A player
    with no 3-bet opportunities has an *unknown* 3-bet percentage, and showing 0%
    would be a claim we cannot support.
    """
    if not t.hands:
        return {"hands": 0}
    c = t.counts
    # Each sum read once: they are summed over the blind sizes on every read.
    bb_sum, vs_fold = t.bb_sum, _vs_fold(t)
    # Every plain rate is one (num, den) pair of `rate_counts`: the one table,
    # which the trend arrows read too.
    pairs = rate_counts(t)
    out = {
        "hands": t.hands,
        **{k: pct(n, d) for k, (n, d) in pairs.items()},
        "net": t.net,
        "bb_per_100": round(float(100 * bb_sum / t.bb_n), 2) if t.bb_n else None,
        # The total behind bb/100: each complete hand's net in its own big blinds.
        "net_bb": round(float(bb_sum), 2) if t.bb_n else None,
        "bb_per_100_ci": _ci(t.bb_n, bb_sum, t.bb_sq),
        # Against folding every hand: 0 is no better than folding. SPEC.md,
        # "bb/100 against folding".
        "bb_per_100_vs_fold": round(float(100 * vs_fold / t.bb_n), 2) if t.bb_n else None,
        "bb_per_100_vs_fold_ci": _ci(t.bb_n, vs_fold, t.vf_sq),
        # Each rate's sample, for the pages' 95% hover. The af_ ones are action
        # counts, not hands: one hand can contribute several (SPEC.md,
        # "Aggression Frequency").
        "_opp": {k: d for k, (_, d) in pairs.items() if not k.startswith(_NO_OPP)},
    }
    for street in _STREETS:
        # Every c-bet counts toward the share, including one whose size is unknown.
        n_cbets = sum(n for k, n in c.items() if k[:2] == ("cbet_size", street))
        out[f"cbet_{street}_sizes"] = {
            b: {"n": c["cbet_size", street, b], "pct": pct(c["cbet_size", street, b], n_cbets)}
            for b in SIZE_BUCKETS
        }
        out[f"vs_cbet_{street}_by_size"] = {
            b: {
                "faced": c["faced", street, b],
                "fold": pct(c["faced_fold", street, b], c["faced", street, b]),
                "raise": pct(c["faced_raise", street, b], c["faced", street, b]),
            }
            for b in SIZE_BUCKETS
        }
        # The bettor's side of fold equity: what each size of their first bet got.
        # Rates are of every bet that size, so an unanswered one counts in none.
        out[f"bet_{street}_answer_by_size"] = {
            b: {
                "n": c["bet_n", street, b],
                **{a: pct(c["bet_got", street, b, a], c["bet_n", street, b]) for a in ANSWERS},
            }
            for b in SIZE_BUCKETS
        }
        # The defender's: what they did facing each size of bet or raise, anyone's.
        out[f"vs_bet_{street}_by_size"] = {
            b: {
                "faced": c["vs_bet", street, b],
                **{a: pct(c["vs_bet_did", street, b, a], c["vs_bet", street, b]) for a in ANSWERS},
            }
            for b in SIZE_BUCKETS
        }
    return out


#: The rates `rates()["_opp"]` has never listed a sample for (the stats page
#: reads their hover from elsewhere): prefixes, as `str.startswith` takes them.
_NO_OPP = ("pfr", "wsd", "raise_cbet_")


def rate_counts(t: Tally) -> dict[str, tuple[int, int]]:
    """Every plain rate of `rates(t)` as its ``(num, den)``: what a trend compares.

    `rates` divides these very pairs and takes `_opp` from their denominators,
    so a rate added here is a rate there, with its arrow. The size mixes are left
    out: each bucket is a share, not a rate the page draws an arrow beside.
    """
    c = t.counts
    out = {
        "vpip": (c["vpip"], c["vpip_opp"]),
        "pfr": (c["pfr"], c["pfr_opp"]),
        "3bet": (c["three_bet"], c["three_bet_opp"]),
        "fold_to_3bet": (c["fold_to_3bet"], c["fold_to_3bet_opp"]),
        "wtsd": (c["wtsd"], c["wtsd_opp"]),
        "wsd": (c["wsd"], c["wtsd"]),
        "wwsf": (c["wwsf"], c["wtsd_opp"]),
        "wwsf_nsd": (c["wwsf_nsd"], c["wtsd_opp"]),
        "ats": (c["steal"], c["steal_opp"]),
        "fold_to_steal": (c["fold_to_steal"], c["fold_to_steal_opp"]),
        "3bet_vs_steal": (c["three_bet_vs_steal"], c["fold_to_steal_opp"]),
        "squeeze": (c["squeeze"], c["squeeze_opp"]),
        "cold_call": (c["cold_call"], c["cold_call_opp"]),
        "limp_reraise": (c["limp_raise"], c["limp_raise"] + c["limp_call"] + c["limp_fold"]),
        "jam_pf": (c["jam_pf"], c["jam_pf_opp"]),
    }
    for street in _LATE_STREETS:
        for key in ("delayed_cbet", "probe", "fold_to_probe"):
            out[f"{key}_{street}"] = (c[key, street], c[f"{key}_opp", street])
    for street in _STREETS:
        faced_cbet = c["fold_to_cbet_opp", street]
        out[f"float_{street}"] = (c["float_bet", street], c["float_opp", street])
        out[f"cbet_{street}"] = (c["cbet", street], c["cbet_opp", street])
        out[f"fold_to_cbet_{street}"] = (c["fold_to_cbet", street], faced_cbet)
        out[f"raise_cbet_{street}"] = (c["raise_cbet", street], faced_cbet)
        out[f"donk_{street}"] = (c["donk", street], c["donk_opp", street])
        out[f"af_{street}"] = (c["aggressive", street], c["agg_denom", street])
        out[f"check_raise_{street}"] = (c["check_raise", street], c["check_raise_opp", street])
    return out


def trend_of(recent: Tally, before: Tally) -> dict[str, dict]:
    """Each rate's `trend` between two tallies of one player, with both sides'
    rate and sample: ``{key: {dir, recent, recent_n, before, before_n}}``. A rate
    with no chance on either side is left out, as it has no rate to move. See
    SPEC.md, "Trends"."""
    new, old = rate_counts(recent), rate_counts(before)
    out = {}
    for key, (rn, rd) in new.items():
        bn, bd = old[key]
        if rd or bd:
            out[key] = {"dir": trend((rn, rd), (bn, bd)), "recent": pct(rn, rd), "recent_n": rd,
                        "before": pct(bn, bd), "before_n": bd}
    return out


def aggregate(facts: Iterable[Facts]) -> dict:
    """Collapse Facts rows into the v1 stat set: `rates(tally(facts))`."""
    return rates(tally(facts))


def facts_by_player(
    conn: sqlite3.Connection,
    game_id: str | None = None,
    pn_ids: Collection[str] | None = None,
) -> tuple[dict[int | str, list[Facts]], dict[int | str, str], list[HandRow]]:
    """Derive every hand and group the resulting facts by canonical player.
    The `play` scope, like `facts_cached`'s default: every caller reads play."""
    with reading(conn):  # one snapshot: a rebuild between the reads tears the hands
        hands = load_hands(conn, game_id, pn_ids)
        ident = identity_map(conn)
    grouped: dict[int | str, list[Facts]] = defaultdict(list)
    aliases: dict[int | str, str] = {}
    for hand in hands:
        for fact in derive(hand):
            pid, alias = player_key(ident, fact.pn_id)
            grouped[pid].append(fact)
            aliases[pid] = alias
    # The session facts (see tilt.py) are numbered over every hand, as a player's
    # own are in `facts_cached`, and only then are the hands not analysed left out.
    # A player with no analysed hand is left out altogether, as before.
    kept = {pid: [f for f in annotate(facts) if f.analysed] for pid, facts in grouped.items()}
    kept = {pid: facts for pid, facts in kept.items() if facts}
    return kept, {pid: a for pid, a in aliases.items() if pid in kept}, hands


#: The last unfiltered `report()` per (database, game), with the generation it was
#: computed at. One entry each, holding a handful of small dicts.
#:
#: This is the answer to the HUD asking the same whole-database question every 30
#: seconds and after every hand. It cannot go stale: `bump_generation` runs inside
#: the same transaction as every change that would invalidate it, so a hit means the
#: derivation behind it is still exactly current.
_REPORT_CACHE: LRU[tuple[str, str | None], tuple[int, list[dict]]] = LRU()

#: Per (database, game): each PokerNow ID's `Tally` in that game, with the game's
#: `derived_gen` stamp. What a report is assembled from on a miss. Counts, not
#: `Facts` -- the Facts of a 10,000-hand database run to ~90 MB, a tally to a few
#: hundred numbers -- so every game can be kept. A rebuild moves one game's stamp,
#: and only that game is derived again: after a hand ends, the lifetime report
#: costs one game rather than the whole history. Keyed by PokerNow ID, not player,
#: so a merge or a rename regroups the same tallies instead of discarding them.
_GAME_TALLIES: LRU[tuple[str, str], tuple[int, dict[str, Tally]]] = LRU()


@dataclass
class _PlayerFacts:
    gen: int
    ids: frozenset[str]
    #: Every hand, PLO's as money only: the `money` scope.
    facts: list[Facts]
    #: game_id -> (that game's derived_gen, this player's Facts in it)
    pieces: dict[str, tuple[int, list[Facts]]]
    #: The other two scopes, each made from `facts` the first time it is asked for.
    play: list[Facts] | None = None
    every: list[Facts] | None = None


#: Which of a player's hands a reader takes. `play`: every rate, range, tag and
#: tree, over the hands `derive.is_analysed` reads -- no PLO, no Double Board.
#: `money`: Results and the winnings graph, those hands' net included. `every`:
#: the hand lists, those hands derived in full to be listed like any other. See
#: SPEC.md, "Money".
SCOPES = ("play", "money", "every")


def play_facts(hands: Iterable[HandRow]) -> list[Facts]:
    """The `play` scope of `hands`, for the readers that derive many players' hands
    themselves: every hand derived, its session facts (tilt.py) numbered over all
    of them, then the hands not analysed left out -- what `facts_cached` gives
    for one player."""
    return [f for f in annotate([f for h in hands for f in derive(h)]) if f.analysed]


def pool_facts(
    conn: sqlite3.Connection,
    game_id: str | None = None,
    predicate: Callable[[Facts], bool] | None = None,
    games: str = "play",
) -> list[Facts]:
    """Every (hand, player) row in the database, or in one game, inside a spot: the
    pool the pool views count. A heads-up hand is two rows, one from each seat.

    The unfiltered pool is held while in use and let go when idle (`_held_pool`,
    `POOL_HOLD_SECONDS`); the predicate runs over it on every call, since a
    predicate cannot key a cache. The session facts come first, so a spot like
    `post_loss` reads whole sessions.

    `games` is the scope (`SCOPES`), as `facts_cached` takes it: the session facts
    are numbered over every hand in each, and `every` derives the hands not
    analysed in full.
    """
    if games not in SCOPES:
        raise ValueError(f"unknown scope: {games!r}")
    facts = _held_pool(conn, game_id, games)
    return [f for f in facts if predicate(f)] if predicate is not None else facts


#: The pool, derived, is a few hundred MB on a year of hands: too much to keep in
#: an always-on service, too slow (seconds) to derive for every click of a page
#: that asks again and again -- the Line explorer's table, its suggestions and its
#: chip counts are three asks per click. So one pool is held while it is in use
#: and let go after this many idle seconds. See SPEC.md, "Line explorer".
POOL_HOLD_SECONDS = 300


@dataclass
class _HeldPool:
    """The held pool: every row in the `money` scope, and the other two scopes cut
    from it the first time each is asked for -- `play` its analysed rows, `every`
    them with the hands not analysed derived in full, as `_scoped` cuts one
    player's. So moving between the all-in page (`money`) and the explorer
    (`play`) derives nothing, and the analysed rows are the same objects in all
    three."""

    money: list[Facts]
    play: list[Facts] | None = None
    every: list[Facts] | None = None


_POOL_HOLD: LRU[tuple, _HeldPool] = LRU(cap=1)
_pool_timer: threading.Timer | None = None
_pool_timer_lock = threading.Lock()


def _release_pool_later() -> None:
    """(Re)start the idle clock: the held pool goes POOL_HOLD_SECONDS after its
    last use."""
    global _pool_timer
    with _pool_timer_lock:
        if _pool_timer is not None:
            _pool_timer.cancel()
        _pool_timer = threading.Timer(POOL_HOLD_SECONDS, _POOL_HOLD.clear)
        _pool_timer.daemon = True
        _pool_timer.start()


def _derive_pool(conn: sqlite3.Connection, game_id: str | None, games: str) -> list[Facts]:
    with reading(conn):  # one snapshot: a rebuild between the reads tears the hands
        hands = load_hands(conn, game_id)
    if games == "play":
        return play_facts(hands)
    return annotate([f for h in hands for f in derive(h, every_game=games == "every")])


#: Hand ids per `load_hands(hand_ids=...)` query: well inside SQLite's limit on
#: bound parameters, which the pool's hands not analysed could pass.
_IDS_PER_QUERY = 900


def _pool_scope(conn: sqlite3.Connection, held: _HeldPool, games: str) -> list[Facts]:
    """`held` in the scope `games` asks for: what `_derive_pool` gives for it."""
    if games == "money":
        return held.money
    if games == "play":
        if held.play is None:
            held.play = [f for f in held.money if f.analysed]
        return held.play
    if held.every is None:
        other = sorted({f.hand_id for f in held.money if not f.analysed})
        if not other:
            held.every = held.money
        else:
            with reading(conn):
                hands = [h for i in range(0, len(other), _IDS_PER_QUERY)
                         for h in load_hands(conn, hand_ids=other[i:i + _IDS_PER_QUERY])]
            full = {(f.hand_id, f.pn_id): f for hand in hands for f in derive(hand, every_game=True)}
            held.every = annotate([full.get((f.hand_id, f.pn_id), f) for f in held.money])
    return held.every


def _held_pool(conn: sqlite3.Connection, game_id: str | None, games: str) -> list[Facts]:
    """Every row of the pool in `games`, from the hold when it is current.

    Keyed like `facts_cached`, on the generation counter, so a hit is exactly
    current; an in-memory database or an unknowable generation is never held.
    Callers must not mutate the rows."""
    gen, path = generation(conn), path_of(conn)
    if gen is None or not path:
        return _derive_pool(conn, game_id, games)
    key = (path, gen, game_id)
    with _POOL_HOLD.making(key):
        held = _POOL_HOLD.get(key)
        if held is None:
            held = _HeldPool(_derive_pool(conn, game_id, "money"))
            _POOL_HOLD[key] = held
        facts = _pool_scope(conn, held, games)
    _release_pool_later()
    return facts


def _scoped(conn: sqlite3.Connection, entry: _PlayerFacts, games: str) -> list[Facts]:
    """`entry` in the scope `games` asks for. Only the hands not analysed are
    derived again for `every`: on most tables there are none, and the analysed
    rows are the same objects as in the other scopes."""
    if games == "money":
        return entry.facts
    if games == "play":
        if entry.play is None:
            entry.play = [f for f in entry.facts if f.analysed]
        return entry.play
    if games != "every":
        raise ValueError(f"unknown scope: {games!r}")
    if entry.every is None:
        other = {f.hand_id for f in entry.facts if not f.analysed}
        if not other:
            entry.every = entry.facts
        else:
            full = {
                (f.hand_id, f.pn_id): f
                for hand in load_hands(conn, hand_ids=other)
                for f in derive(hand, every_game=True)
            }
            entry.every = annotate([full.get((f.hand_id, f.pn_id), f) for f in entry.facts])
    return entry.every


#: One player's `Facts`, per (database, alias, game). This one *is* a cache of
#: Facts, which the tallies refuse to be -- but for a handful of players, not the
#: whole database: the live view asks for everyone at the table on every poll, and
#: a table seats ten -- and the chart, on every tab, for one player across all
#: games or one session. Capped so an evening across several tables cannot grow it
#: without bound; the least recently used goes first, so paging through sessions
#: on the chart does not push out the whole-history entries the HUD keeps asking
#: for. Kept per game underneath, like the tallies, so a rebuild costs the one
#: game it touched.
_FACTS_CACHE_MAX = 32
_FACTS_CACHE: LRU[tuple[str, str, str | None], _PlayerFacts] = LRU(_FACTS_CACHE_MAX)

#: While `deriving_once` is open on a thread: per (database, game, the game's
#: stamp), each hand derived so far, by hand id, with every player's Facts.
_ONCE = threading.local()


@contextmanager
def deriving_once() -> Iterator[None]:
    """Inside this block, each hand is derived once for every reader on this
    thread: `facts_cached`'s misses, `pool.pool_for`'s and whoever else derives
    through `derived_once`. For a question that reads many players at once --
    review's villains, Tendencies' regulars, a table's HUD -- each of which used
    to derive the same hands again, once per player (a review of 20k hands
    derived them eight times).

    Pure Python and per thread, so it runs as is on the extension's Pyodide.
    Keyed on each game's stamp, so a game rebuilt meanwhile is derived again. The
    hands derived are let go when the outermost block ends: memory for one
    question, never between them. A nested block shares the outer one's."""
    if getattr(_ONCE, "memo", None) is not None:
        yield
        return
    _ONCE.memo = {}
    try:
        yield
    finally:
        _ONCE.memo = None


def _once_for(path: str | None, game_id: str, stamp: int | None) -> dict[int, list[Facts]] | None:
    """The hands of `game_id` at `stamp` derived inside `deriving_once`; None
    outside one, or with nothing to key a game on."""
    memo = getattr(_ONCE, "memo", None)
    if memo is None or not path or stamp is None:
        return None
    return memo.setdefault((path, game_id, stamp), {})


def derived_once(hand: HandRow, seen: dict[int, list[Facts]] | None) -> list[Facts]:
    """`derive(hand)`, from `seen` (`_once_for`) when it was derived already.
    The same Facts are then shared by every reader: none may change them, which
    `annotate` does not -- it writes the same values each time."""
    if seen is None:
        return derive(hand)
    got = seen.get(hand.hand_id)
    if got is None:
        got = seen[hand.hand_id] = derive(hand)
    return got


#: Whole answers of the read-only questions that take a second or more and are
#: asked again unchanged -- a filtered /stats, Results, Tilt, Tendencies -- per
#: database, generation and arguments (`remembered`). Small dicts and lists, so a
#: few dozen cost little; older generations' entries just age out.
_ANSWERS: LRU[tuple, object] = LRU(32)
#: One player's stats, range and sizing in a spot: a fraction of a second each
#: (a second on the phone's VM) but asked on every chart click, so kept apart --
#: in `_ANSWERS` a few dozen clicks would push out the answers that cost seconds.
#: A range answer lists every cell's hands, about 0.3 MB for 16k hands.
SPOT_ANSWERS: LRU[tuple, object] = LRU(48)
#: Each HUD seat's lifetime tags (`/hud`): judging a player's sessions one by one
#: cost ~0.45 s a table on every poll and every hand. Kept apart, like SPOT_ANSWERS.
TAG_ANSWERS: LRU[tuple, object] = LRU(32)


def remembered(conn: sqlite3.Connection, key: tuple, compute, answers: LRU[tuple, object] = _ANSWERS):
    """`compute()`, or the answer it gave for `key` at this generation.

    The generation moves inside every write that changes a derived fact -- a
    rebuild, merge, split or rename -- so a hit is exactly current. Whatever else
    the answer depends on -- a `tag=` filter's tags, the hero picked -- belongs in
    `key`. The caller must not change what it gets back: it is shared.
    """
    gen = generation(conn)
    path = path_of(conn)
    if gen is None or not path:
        return compute()
    full = (path, gen, *key)
    hit = answers.get(full)
    if hit is None:
        with answers.making(full):
            hit = answers.get(full)
            if hit is None:
                hit = compute()
                answers[full] = hit
    return hit


def clear_caches() -> None:
    """Forget every memoized result. For tests, and for anything that edits the
    database behind this module's back."""
    from . import pool, tree  # both import this module
    from .review import _REVIEW_CACHE  # review imports this module

    pool.clear()
    tree._TREE_CACHE.clear()

    _REPORT_CACHE.clear()
    _GAME_TALLIES.clear()
    _GAME_NOT_ANALYSED.clear()
    _FACTS_CACHE.clear()
    _REVIEW_CACHE.clear()
    _ANSWERS.clear()
    SPOT_ANSWERS.clear()
    TAG_ANSWERS.clear()


def _game_stamps(conn: sqlite3.Connection, game_id: str | None = None) -> dict[str, int] | None:
    """Every game with hands, oldest first, with its derivation stamp.

    None when the database has no stamps to read (opened with `init=False` from
    before they existed): the caller then derives without caching, which is slow
    but never wrong.
    """
    where = "WHERE h.game_id = ?" if game_id else ""
    try:
        rows = conn.execute(
            "SELECT h.game_id, COALESCE(g.derived_gen, 0) AS stamp FROM hands h"
            f" LEFT JOIN games g ON g.game_id = h.game_id {where}"
            " GROUP BY h.game_id ORDER BY MIN(h.ord)",
            (game_id,) if game_id else (),
        ).fetchall()
    except sqlite3.OperationalError:
        return None
    return {r["game_id"]: r["stamp"] for r in rows}


def _tally_by_id(hands: Iterable[HandRow], seen: dict[int, list[Facts]] | None = None) -> dict[str, Tally]:
    """Each PokerNow ID's tally over `hands`, in order of first appearance.
    `seen`: the hands' game derived so far (`_once_for`)."""
    out: dict[str, Tally] = {}
    for hand in hands:
        for fact in derived_once(hand, seen):
            if not fact.analysed:  # PLO and Double Board count in Results and the hand lists only
                continue
            t = out.get(fact.pn_id)
            if t is None:
                t = out[fact.pn_id] = Tally()
            t.add(fact)
    return out


def _whole_hands(conn: sqlite3.Connection, game_id: str | None) -> list[HandRow]:
    """`load_hands`, its three queries against one snapshot, so a rebuild landing
    between them cannot leave a game's hands with no players or actions. The
    snapshot ends with the reads; deriving the hands needs none."""
    with reading(conn):
        return load_hands(conn, game_id)


def _tallies(conn: sqlite3.Connection, game_id: str | None) -> list[dict[str, Tally]]:
    """Per-game tallies, oldest game first, derived only where a game's stamp moved.

    A game rebuilt after its stamp was read is tallied from its new hands under
    the old stamp: the stamp has moved, so the next call derives it again."""
    path = path_of(conn)
    stamps = _game_stamps(conn, game_id) if path else None
    if stamps is None:
        return [_tally_by_id(_whole_hands(conn, game_id))]
    out = []
    for gid, stamp in stamps.items():
        hit = _GAME_TALLIES.get((path, gid))
        if hit is None or hit[0] != stamp:
            with _GAME_TALLIES.making((path, gid)):
                hit = _GAME_TALLIES.get((path, gid))
                if hit is None or hit[0] != stamp:
                    seen = _once_for(path, gid, stamp)  # shared inside `deriving_once`
                    hit = _GAME_TALLIES[path, gid] = (stamp, _tally_by_id(_whole_hands(conn, gid), seen))
        out.append(hit[1])
    if game_id is None:  # a game deleted since is forgotten with it
        _GAME_TALLIES.prune(lambda k: k[0] == path and k[1] not in stamps)
    return out


def facts_cached(
    conn: sqlite3.Connection, alias: str, game_id: str | None = None, games: str = "play"
) -> list[Facts]:
    """`facts_for`, remembered until the derivation generation moves.

    `games` is the scope (`SCOPES`): `play` unless a caller asks otherwise.

    The same contract as `report()`'s cache: keyed on the generation counter,
    which every write that changes a derived fact bumps inside its own
    transaction, so a hit is exactly current. Ingesting raw lines does not bump
    it, which is the point -- live capture writes every few seconds and the
    answer does not change until the hand is rebuilt. On a miss, only the games
    whose stamp moved are derived again. Callers must not mutate the rows they
    get back.

    Every read is made against one snapshot. A game rebuilt mid-call gets new
    hand ids, and a cached piece kept on the stamp read before the rebuild would
    not match the hand order read after it.
    """
    with reading(conn):
        return _scoped(conn, _facts_cached(conn, alias, game_id), games)


def _facts_cached(conn: sqlite3.Connection, alias: str, game_id: str | None) -> _PlayerFacts:
    gen = generation(conn)
    path = path_of(conn)
    key = (path, alias, game_id)
    hit = _FACTS_CACHE.get(key) if gen is not None and path else None
    # Before the stamps: they are a GROUP BY over every hand, and a hit at this
    # generation needs none of them -- a write that moves a stamp moves it too.
    if hit is not None and hit.gen == gen:
        return hit
    # Every request a page makes names its player: one derives, the rest wait.
    with _FACTS_CACHE.making(key):
        hit = _FACTS_CACHE.get(key) if gen is not None and path else None
        if hit is not None and hit.gen == gen:
            return hit
        return _refresh_facts(conn, alias, game_id, gen, path, hit)


def _refresh_facts(
    conn: sqlite3.Connection, alias: str, game_id: str | None, gen: int | None, path: str,
    hit: _PlayerFacts | None,
) -> _PlayerFacts:
    """`_facts_cached`'s miss: the games whose stamp moved derived again."""
    key = (path, alias, game_id)
    stamps = _game_stamps(conn, game_id) if gen is not None and path else None
    if stamps is None:
        return _PlayerFacts(0, frozenset(), facts_for(conn, alias, game_id, "money"), {})

    ids = identities_of(conn, alias)
    wanted = frozenset(ids)
    # A merge or split changes whose hands these are: start over rather than patch.
    pieces = hit.pieces if hit is not None and hit.ids == wanted else {}
    order: dict[int, tuple[int, int]] = {}
    games: dict[str, list[int]] = defaultdict(list)  # game -> its hands of theirs
    if ids:
        marks = ",".join("?" * len(ids))
        where = " AND h.game_id = ?" if game_id else ""
        for r in conn.execute(
            "SELECT h.hand_id, h.ord, h.game_id FROM hands h WHERE h.hand_id IN"
            f" (SELECT hand_id FROM hand_players WHERE pn_id IN ({marks})){where}",
            (*ids, game_id) if game_id else tuple(ids),
        ):
            order[r["hand_id"]] = (r["ord"], r["hand_id"])
            games[r["game_id"]].append(r["hand_id"])
    fresh: dict[str, tuple[int, list[Facts]]] = {}
    for gid, in_game in games.items():
        piece = pieces.get(gid)
        if piece is None or piece[0] != stamps.get(gid):
            stamp = stamps.get(gid, 0)
            seen = _once_for(path, gid, stamp)
            if seen is not None and all(h in seen for h in in_game):
                # Every hand already derived for another reader: no hands to load.
                derived = [f for h in in_game for f in seen[h]]
            else:
                derived = [f for hand in load_hands(conn, gid, ids) for f in derived_once(hand, seen)]
            piece = (stamp, [f for f in derived if f.pn_id in wanted])
        fresh[gid] = piece
    # facts_for's order: by hand, oldest first, and within a hand as derived.
    facts = sorted((f for _, piece in fresh.values() for f in piece), key=lambda f: order[f.hand_id])
    # The session facts, per game: a reused piece is filled again, to the same values.
    annotate(facts)

    entry = _FACTS_CACHE[key] = _PlayerFacts(gen, wanted, facts, fresh)
    return entry


#: Per (database, game): each PokerNow ID's count of hands not analysed in that
#: game, with the game's `derived_gen` stamp, as `_GAME_TALLIES` keeps tallies. The
#: HUD asks for the lifetime count on every /hud, and live capture rebuilds a game
#: at every hand's end: kept per game, that costs the one game rebuilt.
_GAME_NOT_ANALYSED: LRU[tuple[str, str], tuple[int, dict[str, int]]] = LRU()


def _not_analysed_in(conn: sqlite3.Connection, game_id: str) -> dict[str, int]:
    """pn_id -> its hands in `game_id` that are not analysed."""
    return {
        r["pn_id"]: r["n"]
        for r in conn.execute(
            "SELECT hp.pn_id, COUNT(*) AS n FROM hands h"
            " JOIN hand_players hp ON hp.hand_id = h.hand_id"
            f" WHERE h.game_id = ? AND NOT {ANALYSED_SQL} GROUP BY hp.pn_id",
            (game_id,),
        )
    }


def not_analysed(conn: sqlite3.Connection, game_id: str | None = None) -> dict[str, int]:
    """alias -> the hands `report()` leaves out of every stat because their play is
    never read: PLO and Double Board, which count for money only. Counted as
    report counts hands, one per seat dealt in. A player with none is absent, and
    so is a PokerNow ID with no player.

    So a table where every hand was PLO can say "312 hands, not analysed" rather
    than "0 hands". Remembered per generation, as a rebuild is what changes it,
    and counted per game underneath, so a rebuild re-counts only its game."""

    def count() -> dict[str, int]:
        path = path_of(conn)
        with reading(conn):  # the stamps, the counts and the names from one snapshot
            stamps = _game_stamps(conn, game_id) if path else None
            if stamps is None:  # nothing to key a game's count on: count them all
                where = " WHERE game_id = ?" if game_id else ""
                gids = [r[0] for r in conn.execute(
                    f"SELECT DISTINCT game_id FROM hands{where}", (game_id,) if game_id else ()
                )]
                per_game = [_not_analysed_in(conn, gid) for gid in gids]
            else:
                per_game = []
                for gid, stamp in stamps.items():
                    hit = _GAME_NOT_ANALYSED.get((path, gid))
                    if hit is None or hit[0] != stamp:
                        hit = _GAME_NOT_ANALYSED[path, gid] = (stamp, _not_analysed_in(conn, gid))
                    per_game.append(hit[1])
                if game_id is None:  # a game deleted since is forgotten with it
                    _GAME_NOT_ANALYSED.prune(lambda k: k[0] == path and k[1] not in stamps)
            ident = identity_map(conn)
        out: dict[str, int] = {}
        for counts in per_game:
            for pn_id, n in counts.items():
                who = ident.get(pn_id)
                if who is not None:
                    out[who[1]] = out.get(who[1], 0) + n
        return out

    return remembered(conn, ("not_analysed", game_id), count)


def report(
    conn: sqlite3.Connection,
    game_id: str | None = None,
    min_hands: int = 1,
    predicate=None,
) -> list[dict]:
    """Stats per player, most hands first.

    `predicate` is an optional `Facts -> bool` filter -- this is the Holdem-Manager
    move: restrict to the hands where a player reached some specific spot, then
    report their behaviour within it.

    Each game's hands are read against one snapshot (`_whole_hands`): `load_hands`
    is three queries, and a game rebuilt between them reads as hands with no
    players or actions. Only the reads: a snapshot held across a cold derivation,
    a minute on a big database, would keep WAL from checkpointing all that time.
    """
    if predicate is not None:
        # A predicate is an arbitrary callable -- not something that can key a cache
        # -- and a spot query is asked once by a person, where the unfiltered one
        # is asked on a timer. So it is derived afresh, every time.
        grouped, aliases, _ = facts_by_player(conn, game_id)
        rows = []
        for pid, facts in grouped.items():
            facts = [f for f in facts if predicate(f)]
            if len(facts) >= min_hands:
                rows.append({"player": aliases.get(pid, "?"), **aggregate(facts)})
        rows.sort(key=lambda r: -r["hands"])
        return rows

    # Cacheable only when the result can be keyed and invalidated with certainty:
    # a database on disk (an in-memory one has no path to tell it apart from
    # another), whose generation counter can be read.
    gen = generation(conn)
    path = path_of(conn)
    cacheable = gen is not None and bool(path)
    key = (path, game_id)
    cached = _REPORT_CACHE.get(key) if cacheable else None
    if cached is None or cached[0] != gen:
        with _REPORT_CACHE.making(key):
            cached = _REPORT_CACHE.get(key) if cacheable else None
            if cached is None or cached[0] != gen:
                cached = _full_report(conn, game_id, gen, cacheable, key)
    # Copied out so a caller that edits a row cannot corrupt the next reader.
    return [dict(r) for r in cached[1] if r["hands"] >= min_hands]


def _full_report(
    conn: sqlite3.Connection, game_id: str | None, gen: int | None, cacheable: bool, key: tuple
) -> tuple[int | None, list[dict]]:
    """`report()`'s miss: every player's rates, derived where a game's stamp moved."""
    ident = identity_map(conn)
    grouped_t: dict[int | str, Tally] = {}
    names: dict[int | str, str] = {}
    for per_id in _tallies(conn, game_id):
        for pn_id, t in per_id.items():
            pid, alias = player_key(ident, pn_id)
            g = grouped_t.get(pid)
            if g is None:
                g = grouped_t[pid] = Tally()
            g += t
            names[pid] = alias
    full = [{"player": names.get(pid, "?"), **rates(t)} for pid, t in grouped_t.items()]
    full.sort(key=lambda r: -r["hands"])
    cached = (gen, full)
    if cacheable:
        # Stored before min_hands is applied, so a stricter or looser threshold
        # is served from the same derivation.
        _REPORT_CACHE[key] = cached
    return cached


def split_report(
    conn: sqlite3.Connection,
    game_id: str | None,
    min_hands: int,
    predicate,
    groups: list,
    recent: Callable[[Facts], bool] | None = None,
    marks: bool = False,
) -> tuple[list[dict], list[list[dict]]]:
    """`report` over the spot, and the same report within each of `groups` (each
    a predicate ANDed onto the spot), from one derivation of every hand.

    The stats page's Split asks for up to eleven sub-spots at once; asked one
    filtered `report` at a time, each would derive the whole database again. A
    group row is kept only for a player who makes the spot's `min_hands` and has a
    hand in that group.

    With `recent`, each spot row also carries `trend` (`trend_of`): the spot's
    hands that `recent` keeps against the rest, from the same facts. The group
    rows carry none.

    With `marks`, each spot row also carries `pool` (`pool_marks`): its rates
    that stand out from every other player in the spot, `min_hands` or not.
    """
    grouped, aliases, _ = facts_by_player(conn, game_id)
    rows: list[dict] = []
    parts: list[list[dict]] = [[] for _ in groups]
    # The pool for `marks`: every player with a hand in the spot, by player key.
    pool: dict[int | str, dict[str, tuple[int, int]]] = {}
    keyed: list[tuple[int | str, dict]] = []
    for pid, facts in grouped.items():
        if predicate is not None:
            facts = [f for f in facts if predicate(f)]
        if len(facts) < min_hands:
            if marks and facts:
                pool[pid] = rate_counts(tally(facts))
            continue
        alias = aliases.get(pid, "?")
        if recent is None:
            whole = tally(facts)
            row = {"player": alias, **rates(whole)}
        else:
            # One pass: the two halves, and the row from their sum (tallies add
            # exactly, see Tally).
            new, old = Tally(), Tally()
            for f in facts:
                (new if recent(f) else old).add(f)
            whole = Tally()
            whole += new
            whole += old
            row = {"player": alias, **rates(whole), "trend": trend_of(new, old)}
        if marks:
            pool[pid] = rate_counts(whole)
            keyed.append((pid, row))
        rows.append(row)
        for part, group in zip(parts, groups):
            sub = [f for f in facts if group(f)]
            if sub:
                part.append({"player": alias, **aggregate(sub)})
    if marks:
        got = pool_marks(pool, [pid for pid, _ in keyed])
        for pid, row in keyed:
            row["pool"] = got[pid]
    for out in (rows, *parts):
        out.sort(key=lambda r: -r["hands"])
    return rows, parts


def identities_of(conn: sqlite3.Connection, alias: str) -> list[str]:
    """Every PokerNow ID merged under one alias. Raises on an alias that does not exist."""
    rows = conn.execute(
        "SELECT pi.pn_id FROM players p JOIN player_identities pi"
        " ON pi.player_id = p.player_id WHERE p.alias = ?",
        (alias,),
    ).fetchall()
    if not rows:
        if not conn.execute("SELECT 1 FROM players WHERE alias = ?", (alias,)).fetchone():
            raise ValueError(f"unknown alias: {alias!r}")
        return []  # a real player, with no identities yet
    return [r["pn_id"] for r in rows]


def facts_for(
    conn: sqlite3.Connection, alias: str, game_id: str | None = None, games: str = "play"
) -> list[Facts]:
    """Every Facts row for one canonical player, across all merged identities.

    The alias is resolved against the identity tables rather than against a full
    derivation, so only that player's hands are read and derived. On a database
    where one player has a fraction of the hands, that is the same fraction of the
    work -- and an unknown alias now costs a single indexed lookup rather than the
    whole history.
    """
    ids = identities_of(conn, alias)
    if not ids:
        return []
    wanted = set(ids)
    facts = annotate([f for hand in load_hands(conn, game_id, ids) for f in derive(hand) if f.pn_id in wanted])
    return _scoped(conn, _PlayerFacts(0, frozenset(wanted), facts, {}), games)


def hand_list(facts: Iterable[Facts], names: Mapping[str, str] | None = None) -> list[dict]:
    """One compact row per hand, newest first: what a drill-down lists before a replay.

    `names` resolves opponent pn_ids for display; without it they come through raw.
    """
    lookup = names or {}

    def name(pn_id: str) -> str:
        return lookup.get(pn_id, pn_id)

    def named(ids: Iterable[str]) -> list[str]:
        # Deliberately not deduped. Within one hand a pn_id is a seat, so two merged
        # identities under one alias are two seats and two opponents -- collapsing
        # them by name would drop a real one and make the count disagree with
        # `pos_players`. It happens: one player sat twice in hand 54 of pgl8vNV4WURe.
        return [name(i) for i in ids]

    rows = []
    for f in sorted(facts, key=lambda x: (x.ts or "", x.hand_id), reverse=True):
        # Same rule as positional_report: no label when the button or a blind is dead.
        labelled = f.seats_from_button is not None and not f.dead_button and not f.blinds_irregular
        rows.append(
            {
                "hand_id": f.hand_id,
                "game_id": f.game_id,
                "hand_number": f.hand_number,
                "ts": f.ts,
                "position": position_name(f.seats_from_button, f.n_dealt_in) if labelled else None,
                "players": f.n_dealt_in,
                "hole_cards": f.cards,
                "board": list(f.board),
                # Double Board's second board, listed under the first.
                "board2": list(f.board2),
                "net_bb": round(f.net / f.bb_size, 1) if f.bb_size else None,
                # Chips, plus this hand's blind so a row can print the pot in bb too.
                "pot": f.pot,
                "bb": f.bb_size,
                "wtsd": f.wtsd,
                # Whether they played the hand at all: the session view hides the
                # hands that were only a preflop fold.
                "vpip": f.vpip,
                "saw_flop": f.saw_flop,
                "bet_size": dict(f.bet_size),
                # Their own actions per postflop street, `xc` and the like, and the
                # whole street from their seat, theirs in capitals: `xBrF`.
                "line": dict(f.line),
                "seq": dict(f.seq),
                # Who the hand was against, and whether they closed the action.
                # `position` above is the absolute seat and stays in the payload;
                # the drill-down shows `ip` instead. See SPEC.md.
                "ip": f.in_position,
                "pos_order": f.pos_order,
                "pos_players": f.pos_players,
                "vs": named(f.opponents),
                "vs_cbet": {s: name(p) for s, p in f.faced_cbet_by.items()},
                "led_into": {s: name(p) for s, p in f.donk_into.items()},
            }
        )
    return rows


def sat_out_list(
    conn: sqlite3.Connection, alias: str, game_id: str, names: Mapping[str, str] | None = None
) -> list[dict]:
    """The hands of one game a player was not dealt into, newest first.

    The session view lists them beside `hand_list`'s rows, so they carry the same
    keys -- with nothing of the player's own (no cards, no seat, no result) and
    `sat_out` set. `vs` is everyone who was dealt in, and `winner` whoever took
    the most from the pot. Raises ValueError on an unknown alias.
    """
    ids = set(identities_of(conn, alias))
    lookup = names or {}
    rows = []
    for h in load_hands(conn, game_id):
        if ids & h.players.keys():
            continue
        # Seat order from the button, so the names read the way the table sat.
        seated = sorted(h.players.values(), key=lambda p: (p.seats_from_button is None, p.seats_from_button or 0))
        top = max(seated, key=lambda p: p.collected - p.contributed, default=None)
        won = top.collected - top.contributed if top else 0
        rows.append(
            {
                "hand_id": h.hand_id,
                "game_id": h.game_id,
                "hand_number": h.hand_number,
                "ts": h.ts,
                "position": None,
                "players": h.n_dealt_in,
                "hole_cards": None,
                "board": list(h.board),
                "board2": list(h.board2),
                "net_bb": None,
                "pot": sum(p.contributed for p in h.players.values()),
                "bb": h.bb,
                "wtsd": False,
                "vpip": False,
                "saw_flop": h.saw_flop,
                "bet_size": {},
                "line": {},
                "seq": {},
                "ip": None,
                "pos_order": None,
                "pos_players": None,
                "vs": [lookup.get(p.pn_id, p.pn_id) for p in seated],
                "vs_cbet": {},
                "led_into": {},
                "sat_out": True,
                "winner": lookup.get(top.pn_id, top.pn_id) if top and won > 0 else None,
                "winner_bb": round(won / h.bb, 1) if top and won > 0 and h.bb else None,
            }
        )
    rows.sort(key=lambda r: (r["ts"] or "", r["hand_id"]), reverse=True)
    return rows


def player_games(conn: sqlite3.Connection, alias: str) -> list[dict]:
    """Every game one player was dealt into, newest first: the sessions to pick from.

    A plain join, like the players page's hand counts -- nothing here needs a
    derived statistic. Raises ValueError on an unknown alias.
    """
    ids = identities_of(conn, alias)
    if not ids:
        return []
    q = ",".join("?" * len(ids))
    return [
        dict(r)
        for r in conn.execute(
            "SELECT h.game_id, g.started_at, MIN(h.ts) AS first_ts, MAX(h.ts) AS last_ts,"
            " COUNT(DISTINCT h.hand_id) AS hands, g.sb, g.bb"
            " FROM hands h JOIN hand_players hp ON hp.hand_id = h.hand_id"
            " LEFT JOIN games g ON g.game_id = h.game_id"
            f" WHERE hp.pn_id IN ({q})"
            " GROUP BY h.game_id ORDER BY MAX(h.ord) DESC",
            ids,
        )
    ]


def positional_report(conn: sqlite3.Connection, alias: str, pool: bool = True) -> list[dict]:
    """Break one player's stats down by position.

    Table size is *pooled at query time* from raw `n_dealt_in`, never pre-bucketed
    in storage -- pooling later is always possible, unpooling is not.
    """
    buckets: dict[str, list[Facts]] = defaultdict(list)
    for f in facts_for(conn, alias):
        if f.seats_from_button is None or f.dead_button or f.blinds_irregular:
            # Positions are best-effort when the button or a blind is dead, so
            # they are left out of positional splits entirely. See SPEC.md.
            continue
        key = position_name(f.seats_from_button, f.n_dealt_in)
        if not pool:
            key = f"{key} ({f.n_dealt_in}-handed)"
        buckets[key].append(f)

    return sorted(
        ({"position": k, **aggregate(v)} for k, v in buckets.items()),
        key=lambda r: -r["hands"],
    )
