"""Paths: SnapMDA's notation for a player's own postflop line (SPEC.md, "Paths").

A path reads `Facts.line`, flop first, one street per `-`::

    B-B-B        bet flop, turn and river
    XC-XC-XF     check-called two streets, check-folded the river
    --B          any river bet, whatever came before
    B-X-[XB]     bet, checked the turn, checked or bet the river
    BM-BM-BL     bet ½-¾ pot twice, then ¾ pot to pot
    XR100        check-raised the flop pot-sized
    --BA         jammed the river: A, after a B or R, is all in

Each street's letters are a *prefix* of its line, so `B` is a bet then anything
(`b`, `bc`, `bf`, `br`) and `BF` a bet that folded to a raise. A size is the
street's (`street_size`): their bet, else their raise, else the bet they faced.
An `A` after a B or R is all in: the street's `Facts.jam`, a voluntary all-in bet
or raise (SPEC.md, "Jams"). A street takes one size and one A, in either order.

A path is also a frequency. `opportunity` is the denominator: the path up to its
last letter, then any decision of that letter's kind there. `B-B-B` is out of
`B-B-[XB]`, and `XC-XC-XF` out of `XC-XC-X[FCR]`.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

from .derive import POSTFLOP_STREETS, SIZE_BUCKETS, Facts, size_bucket

#: The action letters, in the order `to_term` writes alternatives.
LETTERS = "xbcfr"
#: A decision with no bet in front, and one facing a bet. Exclusive, and every
#: letter is one of them: a letter's *kind*, which `opportunity` reads.
UNBET = frozenset("xb")
FACING = frozenset("cfr")
#: The size letters, one per SIZE_BUCKETS bucket: blocker, small, medium, large, overbet.
SIZE_LETTERS = dict(zip("tsmlo", SIZE_BUCKETS, strict=True))
_LETTER_OF = {bucket: letter for letter, bucket in SIZE_LETTERS.items()}
#: All in, written after a B or R (or a bracket holding one): the street's jam.
JAM_LETTER = "a"
#: What `size_sequence` writes for a street with no size.
NO_SIZE = "·"


class PathError(ValueError):
    """A path that does not parse. A ValueError, as every bad filter term is, so
    the server answers it with a 400; `pos` is the 0-based index of the bad
    character in the text given."""

    def __init__(self, text: str, pos: int, why: str):
        self.text, self.pos = text, pos
        at = f" at character {pos + 1}" if 0 <= pos < len(text) else ""
        super().__init__(f"bad path {text!r}{at}: {why}")


@dataclass(frozen=True, slots=True)
class Street:
    """One street of a path. `letters` is each position's alternatives, lower
    case; empty is a blank street, which matches anything, not acting included.
    `size` is a SIZE_BUCKETS bucket for the street's size, and `size_at` the
    position it was written after (-1 with no size). `jam` asks for the street's
    jam (`Facts.jam`), and `jam_at` is the position the A was written after."""

    letters: tuple[frozenset[str], ...] = ()
    size: str | None = None
    size_at: int = -1
    jam: bool = False
    jam_at: int = -1

    @property
    def blank(self) -> bool:
        return not self.letters


@dataclass(frozen=True, slots=True)
class Path:
    """Up to three streets, flop first. Never empty, and never ends on a blank
    street: `B--` is `B`, so the last street always has a last letter."""

    streets: tuple[Street, ...]


def _bucket_of_percent(text: str, start: int, digits: str) -> str:
    try:
        pct = float(digits)
    except ValueError:
        raise PathError(text, start, f"{digits!r} is not a number") from None
    # A bet of `pct` chips into a pot of 100: `size_bucket`'s own edges, so 75 is
    # large, 50 medium and 20 small, as the bet buttons are.
    return size_bucket(pct, 100)  # type: ignore[arg-type]


def parse_path(text: str) -> Path:
    """Read a path (SPEC.md, "Paths"). Case and spaces are forgiven; anything
    else that is not the grammar raises PathError with the bad character's place."""
    streets: list[Street] = []
    letters: list[frozenset[str]] = []
    size: str | None = None
    size_at = -1
    jam_at = -1
    i, n = 0, len(text)

    def close() -> None:
        nonlocal letters, size, size_at, jam_at
        streets.append(Street(tuple(letters), size, size_at, jam_at >= 0, jam_at))
        letters, size, size_at, jam_at = [], None, -1, -1

    def add(group: frozenset[str], at: int) -> None:
        shown = "/".join(c.upper() for c in LETTERS if c in group)
        if letters:
            if group <= UNBET:
                raise PathError(
                    text, at,
                    f"{shown} cannot follow another action on the street: only C, F or R can, "
                    f"since acting again means facing a bet (a - starts the next street)",
                )
            if letters[-1] == {"f"}:
                raise PathError(text, at, "nothing follows a fold on the same street")
        letters.append(group)

    while i < n:
        ch = text[i]
        low = ch.lower()
        if ch.isspace():
            i += 1
        elif ch == "-":
            # A fourth street is refused unless it, and any after it, is blank:
            # trailing blanks drop off, so `B-B-B-` is `B-B-B` as `B--` is `B`.
            if len(streets) == len(POSTFLOP_STREETS) - 1 and not all(c == "-" or c.isspace() for c in text[i:]):
                raise PathError(text, i, "a path has three streets at most, flop-turn-river")
            close()
            i += 1
        elif low in LETTERS:
            add(frozenset(low), i)
            i += 1
        elif ch == "[":
            start = i
            group: set[str] = set()
            i += 1
            while i < n and text[i] != "]":
                c = text[i].lower()
                if text[i].isspace():
                    pass
                elif c in LETTERS:
                    group.add(c)
                elif c == "[":
                    raise PathError(text, i, "brackets do not nest")
                elif c in SIZE_LETTERS or c.isdigit():
                    raise PathError(text, i, "a size goes after the ], not inside it: [XB]M")
                else:
                    raise PathError(text, i, f"{text[i]!r} is not a letter: use X B C F R inside [ ]")
                i += 1
            if i == n:
                raise PathError(text, start, "a [ that is never closed")
            if not group:
                raise PathError(text, start, "empty [ ]: put the letters it allows inside, [XB]")
            add(frozenset(group), start)
            i += 1
        elif ch == "]":
            raise PathError(text, i, "a ] with no [ before it")
        elif low == JAM_LETTER:
            if not letters:
                raise PathError(text, i, "an A goes after a bet or a raise: BA, XRA")
            if not letters[-1] & {"b", "r"}:
                raise PathError(text, i, "an A goes after a B or an R: a call or a fold all in is not a jam")
            if jam_at >= 0:
                raise PathError(text, i, "one A per street: a street has one jam")
            jam_at = len(letters) - 1
            i += 1
        elif low in SIZE_LETTERS or ch.isdigit() or ch == ".":
            start = i
            if low in SIZE_LETTERS:
                bucket = SIZE_LETTERS[low]
                i += 1
            else:
                j = i
                while j < n and (text[j].isdigit() or text[j] == "."):
                    j += 1
                bucket = _bucket_of_percent(text, i, text[i:j])
                i = j
            if not letters:
                raise PathError(text, start, "a size goes after a letter: BM, B33")
            if size is not None:
                raise PathError(text, start, "one size per street: the street has a single size")
            size, size_at = bucket, len(letters) - 1
        else:
            raise PathError(
                text, i,
                f"{ch!r} is not part of a path: use X B C F R, [ ] for either, - between "
                f"streets, a size T S M L O or a % of pot after a letter, and A for all in",
            )
    close()
    while streets and streets[-1].blank:
        streets.pop()
    if not streets:
        raise PathError(text, -1, "a path needs at least one letter, e.g. B-B-B or --B")
    return Path(tuple(streets))


def street_sized(f: Facts, street: str) -> tuple[str, float | None] | None:
    """The size a path's size letter tests on `street`, as its SIZE_BUCKETS
    bucket and its pot fraction: their own bet if the line has one, else their
    own (first) raise, else the bet they faced (so `xf` is the size they folded
    to). None with none of them; the fraction alone can be None. The one place this choice is made: the size
    letters, the size-sequence rows and the explorer's sizes all read it."""
    line = f.line.get(street, "")
    if "b" in line:
        bucket, frac = f.bet_size.get(street), f.bet_pot.get(street)
    elif "r" in line:
        bucket, frac = f.raise_size.get(street), f.raise_pot.get(street)
    elif f.faced_bet.get(street):
        bucket, frac = f.faced_bet_size.get(street), f.faced_bet_pot.get(street)
    else:
        return None
    return None if bucket is None else (bucket, frac)


def street_size(f: Facts, street: str) -> str | None:
    """`street_sized`'s bucket alone."""
    sized = street_sized(f, street)
    return sized[0] if sized else None


def size_letter(f: Facts, street: str) -> str:
    """`street_size` on `street` as T S M L O, or `·` with none."""
    bucket = street_size(f, street)
    return NO_SIZE if bucket is None else _LETTER_OF[bucket].upper()


def size_sequence(f: Facts, streets: Iterable[str] = POSTFLOP_STREETS) -> str:
    """`size_letter` on each of `streets`, joined by `-`: "M-M-L"."""
    return "-".join(size_letter(f, s) for s in streets)


def _street_ok(spec: Street, line: str | None, f: Facts, street: str, last: frozenset[str] | None = None,
               sized: bool = True, jammed: bool = True) -> bool:
    """`spec` on one street's line. `last`, when given, replaces the last
    position's letters (the opportunity's kind); `sized` False skips the size,
    and `jammed` False the A."""
    if spec.blank:
        return True
    if line is None or len(line) < len(spec.letters):
        return False
    for k, group in enumerate(spec.letters):
        want = last if last is not None and k == len(spec.letters) - 1 else group
        if line[k] not in want:
            return False
    if jammed and spec.jam and not f.jam.get(street):
        return False
    return not (sized and spec.size is not None and street_size(f, street) != spec.size)


def matches(path: Path, f: Facts) -> bool:
    """Every street of `path` is a prefix of that street's line, and its size, if
    it has one, is `street_size` there."""
    return all(
        _street_ok(spec, f.line.get(s), f, s) for spec, s in zip(path.streets, POSTFLOP_STREETS)
    )


def kind_of(group: frozenset[str]) -> frozenset[str]:
    """Every letter of the same kind as any in `group`: X B, F C R, or all five
    for a bracket that mixes them."""
    out: frozenset[str] = frozenset()
    if group & UNBET:
        out |= UNBET
    if group & FACING:
        out |= FACING
    return out


def opportunity(path: Path, f: Facts) -> bool:
    """The denominator of `path` as a frequency: the path up to its last letter,
    then a decision of that letter's kind there. A size or an A written on the
    last letter is dropped; one written earlier on that street stays."""
    *before, end = path.streets
    for spec, s in zip(before, POSTFLOP_STREETS):
        if not _street_ok(spec, f.line.get(s), f, s):
            return False
    street = POSTFLOP_STREETS[len(before)]
    sized = end.size is not None and end.size_at != len(end.letters) - 1
    jammed = end.jam and end.jam_at != len(end.letters) - 1
    return _street_ok(end, f.line.get(street), f, street, last=kind_of(end.letters[-1]), sized=sized,
                      jammed=jammed)


def next_decision(path: Path, f: Facts) -> str | None:
    """Their own next action after the path's last letter, on the same street, as
    an upper-case letter; None when the path does not match or they never acted
    again there."""
    if not matches(path, f):
        return None
    street = POSTFLOP_STREETS[len(path.streets) - 1]
    line = f.line.get(street, "")
    k = len(path.streets[-1].letters)
    return line[k].upper() if len(line) > k else None


def to_term(path: Path) -> str:
    """The canonical text of `path`: upper case, alternatives in X B C F R order,
    sizes as letters, trailing blank streets dropped. `parse_path` reads it back
    to the same Path."""
    out = []
    for spec in path.streets:
        parts = []
        for k, group in enumerate(spec.letters):
            ordered = "".join(c for c in LETTERS if c in group).upper()
            parts.append(ordered if len(ordered) == 1 else f"[{ordered}]")
            if k == spec.size_at and spec.size is not None:
                parts.append(_LETTER_OF[spec.size].upper())
            if k == spec.jam_at and spec.jam:
                parts.append(JAM_LETTER.upper())
        out.append("".join(parts))
    return "-".join(out)
