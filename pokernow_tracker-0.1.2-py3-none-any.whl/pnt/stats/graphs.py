"""The Line explorer's graphs: fold equity, stabs, river ranges and c-bets.

SnapMDA draws what a bet of each size gets as a picture, because a curve reads
faster than a table. These are the numbers behind the four graphs on `/postflop`,
over facts the caller has already narrowed to the spot (one player's, or the
pool's without the hero), the way `explore.explore` takes them:

- **Fold equity by bet size**: per street and size bucket, how often their bet
  took the pot (everyone folded, `bet_answer`) and how often they folded to a
  bet (`faced_bet_action`), each against a pure bluff's break-even ``s / (1 + s)``.
  The rows are `fold_equity`'s own, with a Wilson interval added.
- **Stab fold by texture**: the same bettor's fold rate for one kind of flop bet,
  the stab (`is_stab`), by flop texture and split by size where the sample allows.
- **River bluffs by bet size**: the shown share of bluffs behind each river bet
  size, against the share a bluff-catcher needs to call, ``s / (1 + 2s)``.
- **C-bets by flop texture**: how often the flop c-bet was made, by texture, and
  at what size.

Each graph carries a one-line takeaway, computed here so it says only what its
intervals support. See SPEC.md, "Line explorer graphs".
"""

from __future__ import annotations

from collections.abc import Collection, Iterable
from statistics import median

from .bluffs import classify
from .derive import POSTFLOP_STREETS, SIZE_BUCKETS, Facts, pct
from .fold_equity import MIN_SAMPLE, _bets, _faced, break_even
from .groupby import Context, check_dims
from .queries import wilson
from .strength import strength_at

#: The size letters the explorer's lines use, by bucket (SPEC.md, "Paths").
LETTER = {"blocker": "T", "small": "S", "medium": "M", "large": "L", "overbet": "O"}

#: A flop stab as a filter: `is_stab` exactly (tests/test_graphs.py holds the two
#: equal). A raised pot's is the float; an unraised pot's a bet after a check.
STAB_TERM = "float_flop|(limped,action_flop=x*B*)"

#: The flop textures, a partition of every flop (`groupby`'s `flop_texture`).
_TEXTURE = check_dims(["flop_texture"])[0]
TEXTURES = _TEXTURE.order
TEXTURE_WORD = {"paired": "paired", "monotone": "monotone", "twotone": "two-tone", "rainbow": "rainbow"}


def flop_texture(f: Facts) -> str | None:
    """The flop's one texture of TEXTURES, or None with no flop."""
    return _TEXTURE.key(f, Context())


def texture_term(texture: str) -> str:
    return _TEXTURE.term(texture)


def _join(*terms: str | None) -> str:
    """Terms ANDed: a term with a `|` in it goes in brackets, so the comma binds
    around it and not inside it."""
    return ",".join(f"({t})" if "|" in t else t for t in terms if t)


def _ci(num: int, den: int) -> list[float] | None:
    """The Wilson interval in percent, one decimal, or None with no trials."""
    w = wilson(num, den)
    return None if w is None else [round(100 * w[0], 1), round(100 * w[1], 1)]


def _verdict(lo: float | None, hi: float | None, line: float | None) -> int:
    """+1 when the whole interval is above `line`, -1 when below, else 0."""
    if lo is None or hi is None or line is None:
        return 0
    return 1 if lo > line else -1 if hi < line else 0


def is_stab(f: Facts) -> bool:
    """A flop stab: a bet into a check by a player who did not raise preflop.

    In a raised pot it is the flop **float** (`float_bet`): a preflop caller who
    bets after the raiser checked to them, with every player before them checking
    too. In a limped pot, which has no raiser, it is a flop bet after at least one
    check (`seq` is checks, then their bet). A lead into a raiser who has yet to
    act is a donk, not a stab; a bomb pot (`pot_level` 0) has neither.
    """
    if f.pot_level >= 2:
        return bool(f.float_bet.get("flop"))
    if f.pot_level == 1:
        seq = f.seq.get("flop", "")
        at = seq.find("B")
        return at > 0 and set(seq[:at]) == {"x"}
    return False


# --- fold equity by bet size ----------------------------------------------------


def _with_ci(row: dict) -> dict:
    """A `fold_equity` row with its size letter and the fold rate's interval."""
    return row | {"letter": LETTER[row["size"]], "ci": _ci(row["folds"], row["n"])}


def fold_by_size(facts: list[Facts], street: str, skip: Collection[tuple[int, str]] = ()) -> dict:
    """Graph 1 for `street`: `bets` (their first bets, and how often everyone
    folded) and `faced` (their first decisions facing a bet, and how often they
    folded), a row per size bucket as `fold_equity` has it, with `ci`. `skip`
    leaves out of `bets` the (hand_id, street) pairs whose bet the hero answered,
    as `explore`'s `got` does: the hero's answers are not the pool's.

    Each side has its takeaway. The defender's reads only the hands heads-up on
    the flop (`players_flop` 2): multiway, one player's fold is not the bluff's win."""
    mine = [f for f in facts if (f.hand_id, street) not in skip] if skip else facts
    bets = [_with_ci(r) for r in _bets(mine, street, False)]
    # What the filter lists: every bet of the size, the hero's answers too.
    for r in bets:
        r["listed"] = sum(1 for f in facts if f.bet_size.get(street) == r["size"])
    faced = [_with_ci(r) for r in _faced(facts, street, False)]
    hu = [_with_ci(r) for r in _faced([f for f in facts if f.players_flop == 2], street, False)]
    return {
        "bets": bets,
        "faced": faced,
        "bets_takeaway": _fold_takeaway(bets, "bets"),
        "faced_takeaway": _fold_takeaway(hu, "faced"),
    }


def _fold_takeaway(rows: list[dict], side: str) -> str | None:
    """The size whose fold rate is furthest from break-even, of the judged rows
    whose whole interval is on one side of it; or that none is; None with no
    judged row."""
    judged = [r for r in rows if r["judged"]]
    gap = "edge" if side == "bets" else "overfold"
    sig = [(abs(r[gap]), v, r) for r in judged if (v := _verdict(*r["ci"], r["break_even"]))]
    if not sig:
        return "every size within noise of break-even" if judged else None
    _, v, r = max(sig, key=lambda t: t[0])
    fold, be, size = f"{r['fold']:.0f}%", f"{r['break_even']:.0f}%", r["letter"]
    if side == "bets":
        return f"{size} bets took it {fold} vs {be} needed: " + ("pure bluffs profit" if v > 0 else "pure bluffs lose")
    return f"heads-up they fold {fold} to {size} vs {be}: " + ("bluff them there" if v > 0 else "bluff them less")


# --- stab fold by texture ---------------------------------------------------------


def _stab_row(key: str, rows: list[Facts], *, size: str | None, filter_: str, listed: int) -> dict:
    """A fold row over stabs: everyone folded, of every stab answered or not, as
    `fold_equity` counts a bet; its break-even the mean of each bet's own.
    `listed` is how many stabs its filter finds, the ones the hero answered too."""
    n = len(rows)
    folds = sum(1 for f in rows if f.bet_answer.get("flop") == "fold")
    sizes = [f.bet_pot["flop"] for f in rows if "flop" in f.bet_pot]
    be = round(100 * sum(map(break_even, sizes)) / len(sizes), 1) if sizes else None
    fold = pct(folds, n)
    return {
        "key": key,
        "size": size,
        "letter": LETTER.get(size or "", None),
        "n": n,
        "folds": folds,
        "fold": fold,
        "ci": _ci(folds, n),
        "break_even": be,
        "edge": round(fold - be, 1) if fold is not None and be is not None else None,
        "median_size": round(median(sizes), 3) if sizes else None,
        "judged": n >= MIN_SAMPLE,
        "filter": filter_,
        "listed": listed,
    }


def stab_by_texture(facts: list[Facts], skip: Collection[tuple[int, str]] = ()) -> dict:
    """Graph 2: every flop stab they made (`is_stab`), what it got, by flop texture.

    `all` is every stab; each texture row has its `sizes`, one per size bucket
    with at least MIN_SAMPLE stabs (the split the sample allows), and `small`,
    how many stabs sit in the buckets left out. `skip` as in `fold_by_size`."""
    every_stab = [f for f in facts if "flop" in f.bet_size and is_stab(f)]
    stabs = [f for f in every_stab if (f.hand_id, "flop") not in skip]
    out = []
    for tex in TEXTURES:
        rows = [f for f in stabs if flop_texture(f) == tex]
        listed = [f for f in every_stab if flop_texture(f) == tex]
        base = _join(STAB_TERM, texture_term(tex))
        row = _stab_row(tex, rows, size=None, filter_=base, listed=len(listed))
        row["label"] = TEXTURE_WORD[tex]
        row["sizes"] = []
        row["small"] = 0
        for size in SIZE_BUCKETS:
            sized = [f for f in rows if f.bet_size["flop"] == size]
            if len(sized) >= MIN_SAMPLE:
                row["sizes"].append(_stab_row(
                    f"{tex}:{size}", sized, size=size, filter_=_join(base, f"bet_flop={size}"),
                    listed=sum(1 for f in listed if f.bet_size["flop"] == size)))
            else:
                row["small"] += len(sized)
        out.append(row)
    every = _stab_row("all", stabs, size=None, filter_=STAB_TERM, listed=len(every_stab))
    every["label"] = "every flop"
    return {"all": every, "textures": out, "takeaway": _stab_takeaway(every, out)}


def _stab_takeaway(every: dict, textures: list[dict]) -> str | None:
    if not every["judged"]:
        return None
    v = _verdict(*every["ci"], every["break_even"])
    head = (f"stabs took it {every['fold']:.0f}% vs {every['break_even']:.0f}% needed: "
            + ("pure-bluff stabs profit" if v > 0 else "pure-bluff stabs lose" if v < 0 else "about break-even"))
    # A texture apart from the rest only when its interval clears another's.
    judged = [t for t in textures if t["judged"]]
    if len(judged) >= 2:
        hi = max(judged, key=lambda t: t["fold"])
        lo = min(judged, key=lambda t: t["fold"])
        if hi["ci"][0] > lo["ci"][1]:
            head += f"; most folds on {hi['label']} ({hi['fold']:.0f}%), fewest on {lo['label']} ({lo['fold']:.0f}%)"
    return head


# --- river bluffs by bet size ------------------------------------------------------


def catcher_break_even(size: float) -> float:
    """The bluff share at which calling a bet of `size` pots with a hand that
    beats exactly the bluffs breaks even: ``s / (1 + 2s)``. It wins the pot and
    the bet, 1 + s, as often as they bluff, and loses the call, s, otherwise --
    the zero of `explore.call_ev`. A third for a pot-sized bet, a quarter for half."""
    return size / (1.0 + 2.0 * size)


def river_range_by_size(facts: list[Facts]) -> dict:
    """Graph 3: of their first river bets of each size, the hands shown, by
    Value:bluff class as the explorer reads a river bet (`bluffs.classify`,
    aggressive), and `bluff_pct` of them against `break_even`, the mean of each
    shown bet's own `catcher_break_even`. `edge` is bluff % minus it: positive,
    calling with a bluff-catcher profits."""
    rows = []
    for size in SIZE_BUCKETS:
        bets = [f for f in facts if f.bet_size.get("river") == size]
        mix = {"value": 0, "marginal": 0, "semi_bluff": 0, "bluff": 0}
        sizes = []
        for f in bets:
            if not f.hole_cards:
                continue
            cls = classify(strength_at(f.hole_cards, f.board, "river"), "river", aggressive=True)
            if cls is None:
                continue
            mix[cls] += 1
            sizes.append(f.bet_pot["river"])
        shown = sum(mix.values())
        bluffs = mix["semi_bluff"] + mix["bluff"]
        be = round(100 * sum(map(catcher_break_even, sizes)) / len(sizes), 1) if sizes else None
        bp = pct(bluffs, shown)
        rows.append({
            "size": size,
            "letter": LETTER[size],
            "n": len(bets),
            "shown": shown,
            "coverage": pct(shown, len(bets)),
            "mix": mix,
            "bluffs": bluffs,
            "bluff_pct": bp,
            "ci": _ci(bluffs, shown),
            "break_even": be,
            "edge": round(bp - be, 1) if bp is not None and be is not None else None,
            "median_size": round(median(sizes), 3) if sizes else None,
            "judged": shown >= MIN_SAMPLE,
            "filter": f"bet_river={size},cards_known",
        })
    return {"rows": rows, "takeaway": _river_takeaway(rows)}


def _river_takeaway(rows: list[dict]) -> str | None:
    judged = [r for r in rows if r["judged"]]
    if not judged:
        return None
    call = [r["letter"] for r in judged if _verdict(*r["ci"], r["break_even"]) > 0]
    fold = [r["letter"] for r in judged if _verdict(*r["ci"], r["break_even"]) < 0]
    if not call and not fold:
        return "every size within noise of a catcher's break-even"
    parts = []
    if call:
        parts.append(f"call {' '.join(call)} with a bluff-catcher")
    if fold:
        parts.append(f"fold it to {' '.join(fold)}")
    return ", ".join(parts) + " (shown hands lean to value)"


# --- c-bets by flop texture ----------------------------------------------------------


def cbet_by_texture(facts: list[Facts]) -> dict:
    """Graph 4: per flop texture, their flop c-bet chances (`cbet_opp`), how often
    they took one (`freq`, with `ci`), and the chances split by the c-bet's size
    bucket (`sizes`: count and share of the chances; `unsized` a bet whose size
    is unknown). `big` is the share of c-bets sized large or over."""
    out = []
    for tex in TEXTURES:
        opp = [f for f in facts if f.cbet_opp.get("flop") and flop_texture(f) == tex]
        bets = [f for f in opp if f.cbet.get("flop")]
        term = texture_term(tex)
        sizes = []
        for size in SIZE_BUCKETS:
            k = sum(1 for f in bets if f.bet_size.get("flop") == size)
            sizes.append({"size": size, "letter": LETTER[size], "n": k, "share": pct(k, len(opp)),
                          "filter": _join("cbet_flop_opp", term, f"cbet_flop={size}")})
        sized = sum(s["n"] for s in sizes)
        big = sum(s["n"] for s in sizes if s["size"] in ("large", "overbet"))
        pots = [f.bet_pot["flop"] for f in bets if "flop" in f.bet_pot]
        out.append({
            "key": tex,
            "label": TEXTURE_WORD[tex],
            "opp": len(opp),
            "n": len(bets),
            "freq": pct(len(bets), len(opp)),
            "ci": _ci(len(bets), len(opp)),
            "sizes": sizes,
            "unsized": len(bets) - sized,
            "big": pct(big, sized),
            "big_ci": _ci(big, sized),
            "median_size": round(median(pots), 3) if pots else None,
            "judged": len(opp) >= MIN_SAMPLE,
            "filter": _join("cbet_flop_opp", term),
            "check_filter": _join("cbet_flop_opp", "!cbet_flop", term),
        })
    return {"rows": out, "takeaway": _cbet_takeaway(out)}


def _cbet_takeaway(rows: list[dict]) -> str | None:
    judged = [r for r in rows if r["judged"]]
    if len(judged) < 2:
        return None
    parts = []
    hi = max(judged, key=lambda r: r["freq"])
    lo = min(judged, key=lambda r: r["freq"])
    if hi["ci"][0] > lo["ci"][1]:
        parts.append(f"c-bet {hi['label']} {hi['freq']:.0f}%, {lo['label']} only {lo['freq']:.0f}%")
    sized = [r for r in judged if r["big_ci"] and r["n"] >= MIN_SAMPLE]
    if len(sized) >= 2:
        hi = max(sized, key=lambda r: r["big"])
        lo = min(sized, key=lambda r: r["big"])
        if hi["big_ci"][0] > lo["big_ci"][1]:
            parts.append(f"sized L or O most on {hi['label']} ({hi['big']:.0f}% vs {lo['big']:.0f}% {lo['label']})")
    return "; ".join(parts) if parts else "no texture stands out (the intervals overlap)"


# --- all four ----------------------------------------------------------------------


def graphs(facts: Iterable[Facts], skip: Collection[tuple[int, str]] = ()) -> dict:
    """Every graph's numbers over an already-filtered set of Facts. `skip` is the
    (hand_id, street) pairs whose bet the hero answered, left out of what a bet
    got (graphs 1 and 2) on any table but the hero's own."""
    facts = list(facts)
    skip = frozenset(skip)
    return {
        "hands": len(facts),
        "min_sample": MIN_SAMPLE,
        "fold_by_size": {s: fold_by_size(facts, s, skip) for s in POSTFLOP_STREETS},
        "stab": stab_by_texture(facts, skip),
        "river_range": river_range_by_size(facts),
        "cbet_texture": cbet_by_texture(facts),
    }
