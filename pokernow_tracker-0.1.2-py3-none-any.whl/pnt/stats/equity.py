"""Showdown equity: who wins how much of each pot, over the boards still to come.

The all-in EV figures are built on three pure functions:

- ``rank7``              the strength of the best five of five to seven cards,
                         as a tuple that compares the way hands compare.
- ``side_pots``          the main and side pots of a hand, from what each player
                         put in and who was still in at the end.
- ``expected_collected`` how many chips each player collects on average over the
                         boards that could still be dealt, given those pots.

Exact when two or fewer cards are to come -- 990 turn-and-river pairs after a
flop all-in, 44 rivers after a turn one, a single board on the river. Preflop
there are 1.7 million boards heads-up, which pure Python cannot enumerate in a
time anyone will wait for, so preflop is **sampled**: 50,000 deals from a
generator seeded by the cards and pots themselves, which makes the answer
reproducible, with a standard error of about 0.2% of the pot -- a few chips on
the biggest pots. Every result says which of the two it was.

PLO is ranked by Omaha's rule -- two cards from the hand, three from the board --
through a lookup table (`omaha_strength`), since `rank_omaha`'s hundred `rank7`
calls a hand would make a sampled PLO5 all-in take a minute. A Double Board
completes both boards from one deck and pays half of every pot on each.

Nothing here touches the database; ``allin.py`` does the reading and caching.
"""

from __future__ import annotations

import functools
import hashlib
import itertools
import math
import random
from collections.abc import Collection, Iterable, Mapping, Sequence

from .cards import Card, parse_cards

#: Deals sampled for a preflop all-in. Tests lower this to stay fast.
SAMPLES = 50_000

#: Every card there is, so the ones still to come are these minus the known ones.
FULL_DECK: tuple[Card, ...] = tuple(Card(v, s) for v in range(2, 15) for s in "cdhs")

#: Boards to come with exactly this many enumerated are done exactly; more are
#: sampled. 990 is the flop case (45 choose 2); the next size up, preflop, is
#: 1,712,304 heads-up and never worth enumerating in pure Python.
EXACT_LIMIT = 2000


def _straight_high(bits: int) -> int:
    """Highest card of a straight in a rank bitmask (bit v set for value v), or 0."""
    if bits & (1 << 14):
        bits |= 1 << 1  # the ace plays low
    for high in range(14, 4, -1):
        if (bits >> (high - 4)) & 0b11111 == 0b11111:
            return high
    return 0


def rank7(cards: Sequence[Card]) -> tuple[int, ...]:
    """The best five-card hand in `cards`, as a tuple that orders hands correctly.

    First element is the category -- 8 straight flush down to 0 high card, the
    same order as ``cards.MADE_CLASSES`` -- followed by the tie-breakers in the
    order they are compared: quads then kicker, trips then pair, the flush cards
    high to low, and so on. Two tuples compare equal exactly when the hands chop.
    """
    counts: dict[int, int] = {}
    by_suit: dict[str, int] = {}
    bits = 0
    for v, s in cards:
        counts[v] = counts.get(v, 0) + 1
        by_suit[s] = by_suit.get(s, 0) | (1 << v)
        bits |= 1 << v

    flush_bits = next((b for b in by_suit.values() if b.bit_count() >= 5), 0)
    if flush_bits:
        high = _straight_high(flush_bits)
        if high:
            return (8, high)

    # Distinct values grouped by how often they appear, biggest group first and
    # higher value first within a group.
    groups = sorted(counts.items(), key=lambda kv: (-kv[1], -kv[0]))
    (v0, n0), *rest = groups
    if n0 == 4:
        kicker = max((v for v in counts if v != v0), default=0)  # 0: four cards, no kicker
        return (7, v0, kicker)
    if n0 == 3 and rest and rest[0][1] >= 2:
        return (6, v0, rest[0][0])
    if flush_bits:
        top5 = sorted((v for v in range(2, 15) if flush_bits & (1 << v)), reverse=True)[:5]
        return (5, *top5)
    high = _straight_high(bits)
    if high:
        return (4, high)
    if n0 == 3:
        kickers = sorted((v for v in counts if v != v0), reverse=True)[:2]
        return (3, v0, *kickers)
    if n0 == 2 and rest and rest[0][1] == 2:
        v1 = rest[0][0]
        kicker = max((v for v in counts if v not in (v0, v1)), default=0)
        return (2, v0, v1, kicker)
    if n0 == 2:
        kickers = sorted((v for v in counts if v != v0), reverse=True)[:3]
        return (1, v0, *kickers)
    return (0, *sorted(counts, reverse=True)[:5])


def rank_omaha(hole: Sequence[Card], board: Sequence[Card]) -> tuple[int, ...]:
    """`rank7` under Omaha's rule: exactly two hole cards and three from the board."""
    return max(
        rank7(two + three)
        for two in itertools.combinations(hole, 2)
        for three in itertools.combinations(board, 3)
    )


#: A prime per card value, so five values multiply to a number naming their multiset.
_PRIMES = dict(zip(range(2, 15), (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41), strict=True))


@functools.cache
def _five_card_tables() -> tuple[dict[int, int], dict[int, int]]:
    """Every five-card hand's strength as one int, keyed by its values' prime product.

    ``(unsuited, flush)``: the first holds every multiset of five values (no
    value five times), the second the 1,287 sets of five distinct values a
    flush can be. The ints order hands exactly as `rank7`'s tuples do -- they
    are those tuples' places in sorted order -- so a lookup stands in for a
    call. Built once, from `rank7` itself, in a few milliseconds.
    """
    unsuited: dict[int, tuple[int, ...]] = {}
    flush: dict[int, tuple[int, ...]] = {}
    for values in itertools.combinations_with_replacement(range(2, 15), 5):
        if any(values.count(v) > 4 for v in values):
            continue
        # Suits dealt round the four in turn: no five share one, so no flush.
        cards = [Card(v, "cdhs"[i % 4]) for i, v in enumerate(values)]
        unsuited[math.prod(_PRIMES[v] for v in values)] = rank7(cards)
    for values in itertools.combinations(range(2, 15), 5):
        flush[math.prod(_PRIMES[v] for v in values)] = rank7([Card(v, "s") for v in values])
    order = {r: i for i, r in enumerate(sorted({*unsuited.values(), *flush.values()}))}
    return {k: order[r] for k, r in unsuited.items()}, {k: order[r] for k, r in flush.items()}


def omaha_parts(cards: Sequence[Card], k: int) -> list[tuple[int, str | None]]:
    """Each `k` of `cards` as (prime product, their suit when they all share one)."""
    return [
        (math.prod(_PRIMES[c.value] for c in combo), combo[0].suit if len({c.suit for c in combo}) == 1 else None)
        for combo in itertools.combinations(cards, k)
    ]


def omaha_strength(pairs: Sequence[tuple[int, str | None]], triples: Sequence[tuple[int, str | None]]) -> int:
    """`rank_omaha` as an int, from ``omaha_parts(hole, 2)`` and ``omaha_parts(board, 3)``.

    The best of every two-from-the-hand, three-from-the-board five, read from
    `_five_card_tables` rather than ranked: many times faster, which is what
    makes a sampled PLO5 all-in seconds of work rather than minutes. Only
    comparable with other `omaha_strength`s.
    """
    unsuited, flush = _five_card_tables()
    # A plain loop: `max()` over a generator makes a sampled all-in half as slow again.
    best = -1
    for pp, ps in pairs:
        for tp, ts in triples:
            v = flush[pp * tp] if ps is not None and ps == ts else unsuited[pp * tp]
            if v > best:  # noqa: PLR1730
                best = v
    return best


_RANK_WORDS = {14: "ace", 13: "king", 12: "queen", 11: "jack", 10: "ten", 9: "nine", 8: "eight",
               7: "seven", 6: "six", 5: "five", 4: "four", 3: "three", 2: "two"}


def rank_name(rank: Sequence[int]) -> str:
    """A `rank7` tuple in words: ``two pair, kings and nines``, ``flush, ace high``,
    ``full house, sixes full of eights``. Kickers are left out."""
    word = _RANK_WORDS.__getitem__

    def many(v: int) -> str:
        return "sixes" if v == 6 else word(v) + "s"

    cat, *v = rank
    if cat == 8:
        return "royal flush" if v[0] == 14 else f"straight flush, {word(v[0])} high"
    return (
        f"four of a kind, {many(v[0])}" if cat == 7
        else f"full house, {many(v[0])} full of {many(v[1])}" if cat == 6
        else f"flush, {word(v[0])} high" if cat == 5
        else f"straight, {word(v[0])} high" if cat == 4
        else f"three of a kind, {many(v[0])}" if cat == 3
        else f"two pair, {many(v[0])} and {many(v[1])}" if cat == 2
        else f"pair of {many(v[0])}" if cat == 1
        else f"{word(v[0])} high"
    )


def best_of(hands: Mapping[str, str], board: Sequence[str]) -> tuple[str, ...]:
    """Who holds the best hand on a complete board: more than one on a chop.

    `hands` maps a player to their hole cards; `board` has five cards. Keys come
    back in the order given.
    """
    if not hands:
        return ()
    board_cards = parse_cards(list(board))
    ranks = {pid: rank7(parse_cards(cards) + board_cards) for pid, cards in hands.items()}
    top = max(ranks.values())
    return tuple(pid for pid, r in ranks.items() if r == top)


def side_pots(
    contributed: Mapping[str, int], live: Collection[str]
) -> list[tuple[int, tuple[str, ...]]]:
    """Main and side pots: ``[(chips, eligible players), ...]``, smallest level first.

    Every chip contributed is in some pot -- a folded player's chips included, they
    are just not eligible for any of them. The layers are the distinct amounts the
    live players put in: the players who put in at least a layer's amount can win
    it. The sizes sum to the total contributed, which is how `Facts.pot` is defined,
    so the two agree by construction.

    `contributed` should already exclude uncalled returns (``hand_players.contributed``
    does). When it does not -- PokerNow occasionally lets a caller put in a few chips
    more than the all-in and returns nothing (hand #73 of `pgl8vNV4WURe`: 915 called
    against 910, and the winner collected all 1,945) -- the top layer has a single
    eligible player and every chip in it is theirs. Such a layer is folded into the
    pot below it, because that is where PokerNow paid it: to the winner, not back
    to its owner. A one-player layer that someone who folded also paid into is a
    real side pot -- two deep stacks bet past the all-in, then one gave up -- and
    stays a pot of its own, which its one eligible player always wins.
    """
    alive = [p for p in live if p in contributed]
    levels = sorted({contributed[p] for p in alive})
    pots: list[tuple[int, tuple[str, ...]]] = []
    floor = 0
    for level in levels:
        chips = sum(max(0, min(c, level) - floor) for c in contributed.values())
        eligible = tuple(p for p in alive if contributed[p] >= level)
        if chips > 0:
            own = min(contributed[eligible[0]], level) - floor if len(eligible) == 1 else None
            if own == chips and pots:
                below, below_eligible = pots[-1]
                pots[-1] = (below + chips, below_eligible)
            else:
                pots.append((chips, eligible))
        floor = level
    return pots


def cache_key(
    hands: Sequence[str],
    board: Sequence[str],
    pots: Sequence[tuple[int, Sequence[int]]],
    board2: Sequence[str] | None = None,
) -> str:
    """One string naming a computation: hands in player order, the board, the pots.

    Player order is part of the key because the result is a list in that order.
    A Double Board's second board follows the first after a ``+``; a key with
    none is spelled as it always was, so the cache already filled stays good.
    The game needs no part of its own: the hands' card counts already say it.
    """
    pot_text = ";".join(f"{chips}:{','.join(map(str, elig))}" for chips, elig in pots)
    boards = "".join(board) if board2 is None else f"{''.join(board)}+{''.join(board2)}"
    return f"{'|'.join(hands)}/{boards}/{pot_text}"


def _seed(key: str) -> int:
    """A seed fixed by the key, so the same all-in samples the same deals every time
    (``hash()`` of a string changes between Python processes; this does not)."""
    return int(hashlib.sha256(key.encode()).hexdigest()[:16], 16)


def expected_collected(
    hands: Sequence[str],
    board: Sequence[str],
    pots: Sequence[tuple[int, Sequence[int]]],
    *,
    board2: Sequence[str] | None = None,
    samples: int | None = None,
    seed: int | None = None,
) -> tuple[list[float], str, int]:
    """Chips each player collects on average, over the boards still to come.

    `hands` are the live players' hole cards, `board` the cards dealt when the
    betting stopped, and `pots` ``(chips, eligible player indices)`` as
    ``side_pots`` produces. Returns ``(expected per player, method, n)``: `method`
    is ``exact`` when every remaining deal was enumerated and ``sampled`` when
    `n` random deals stood in for them. Each pot goes to the best eligible hand on
    each board, split equally on a chop.

    Hands of more than two cards are Omaha's: exactly two from the hand and three
    from the board (`omaha_strength`). `board2` is a Double Board's second board
    as dealt by then: both are completed from one deck, and every pot is split
    in half between them, each half to that board's best eligible hand.
    """
    holes = [parse_cards(h) for h in hands]
    omaha = any(len(h) > 2 for h in holes)
    known = [parse_cards(list(board))] + ([] if board2 is None else [parse_cards(list(board2))])
    dead = {c for b in known for c in b}
    for h in holes:
        dead.update(h)
    deck = [c for c in FULL_DECK if c not in dead]
    to_come = [5 - len(b) for b in known]
    if min(to_come) < 0:
        raise ValueError(f"a board has at most five cards, not {max(len(b) for b in known)}")

    pots = [(chips, tuple(elig)) for chips, elig in pots]
    per_board = len(known)
    won = [0.0] * len(holes)
    pairs = [omaha_parts(h, 2) for h in holes] if omaha else []

    def settle(extra: Sequence[Card]) -> None:
        dealt = 0
        for b, need in zip(known, to_come, strict=True):
            full = b + list(extra[dealt : dealt + need])
            dealt += need
            if omaha:
                triples = omaha_parts(full, 3)
                ranks = [omaha_strength(p, triples) for p in pairs]
            else:
                ranks = [rank7(h + full) for h in holes]
            for chips, elig in pots:
                best = max(ranks[i] for i in elig)
                winners = [i for i in elig if ranks[i] == best]
                share = chips / per_board / len(winners)
                for i in winners:
                    won[i] += share

    n_deals = 1
    left = len(deck)
    for need in to_come:
        n_deals *= _choose(left, need)
        left -= need
    if n_deals <= EXACT_LIMIT:
        for extra in _deals(deck, to_come):
            settle(extra)
        n = n_deals
        method = "exact"
    else:
        n = samples if samples is not None else SAMPLES
        rng = random.Random(_seed(cache_key(hands, board, pots, board2)) if seed is None else seed)
        for _ in range(n):
            settle(rng.sample(deck, sum(to_come)))
        method = "sampled"

    return [w / n for w in won], method, n


def _deals(deck: Sequence[Card], to_come: Sequence[int]) -> Iterable[tuple[Card, ...]]:
    """Every way to complete the boards: each one's cards, in board order."""
    if not to_come:
        yield ()
        return
    need, rest = to_come[0], to_come[1:]
    for first in itertools.combinations(deck, need):
        left = [c for c in deck if c not in first] if rest else deck
        for more in _deals(left, rest):
            yield first + more


def _choose(n: int, k: int) -> int:
    out = 1
    for i in range(k):
        out = out * (n - i) // (i + 1)
    return out
