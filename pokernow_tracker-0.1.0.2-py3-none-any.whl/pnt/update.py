"""`pnt update`: replace the installed code, restart the server, let the extension follow.

Updating by hand took three steps in an order that mattered: stop the service,
reinstall, start it again, then reload the extension at chrome://extensions. Done
the other way round, a reinstall meets the running server's interpreter -- which
Windows will not delete -- and a restart without the reinstall keeps the old code.

* **pip inside the install's own environment, not pipx.** A `pipx reinstall`
  deletes the venv, interpreter and all, and the service runs that interpreter.
  pip replaces only the package, leaving the interpreter the task names in place.
* **`--force-reinstall`.** Releases bump the version, but `--from` a folder or
  an archive may not, and without the flag pip calls that up to date and changes
  nothing.
* **The server restarts in a fresh process**, so the restart is the new code's.
* **The extension reloads itself.** The server reports a hash of the extension's
  files in `/health` (`extension_build`); a loaded extension that sees the hash
  change under it reloads (background.js), and Chrome reads the new files from
  the same folder, which a reinstall does not move.
* **The server says when there is one.** A release knows its place on main
  (`build_info`); the server reads the download site's `latest.json` every few
  hours and reports how many changes it lacks in `/health` (`update_behind`),
  which the front page and the side panel show as a banner.
* **Releases, not the source.** The repository is private. Every push to main
  builds a wheel (scripts/release.py) and publishes it, with `latest.json`, to
  the public download site; `pnt update` installs the wheel that names.
"""

from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import json
import os
import plistlib
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable
from pathlib import Path

DIST = "pokernow-tracker"
#: The public download site (GitHub Pages of a repo holding no source): the
#: current wheel and `latest.json`, which names it. Needs no git to install from.
#: PNT_DIST_URL points it elsewhere: a local copy of the site, to test a release.
DIST_URL = os.environ.get("PNT_DIST_URL", "https://jaaaayden.github.io/pnt-dist/").rstrip("/") + "/"
LATEST_URL = urllib.parse.urljoin(DIST_URL, "latest.json")
PACKAGE_DIR = Path(__file__).parent
EXTENSION_DIR = PACKAGE_DIR / "extension"
#: Written into each release by scripts/release.py: its version, commit and
#: place on main. A checkout has none.
BUILD_FILE = PACKAGE_DIR / "_build.json"
#: Holds `$Format:%H$`, which GitHub's archives replace with the commit
#: (.gitattributes: export-subst). Only installs from the old public main.zip
#: rely on it; a checkout keeps the placeholder.
COMMIT_FILE = PACKAGE_DIR / "_commit.txt"


class UpdateError(RuntimeError):
    """Something the user can act on: shown as a one-line CLI error."""


def extension_build(folder: Path = EXTENSION_DIR) -> str:
    """A short hash of the files Chrome loads from the extension folder.

    The manifest version is no use here: nobody bumps it. The tests beside the
    scripts are left out, since Chrome never loads them and a change to one
    should not reload anybody's extension.

    background.js hashes its own copy the same way, so the order is the plain
    string order of the paths, which JavaScript's sort() also gives.
    """
    h = hashlib.sha256()
    for rel in sorted(extension_files(folder)):
        h.update(rel.encode() + b"\0" + (folder / rel).read_bytes() + b"\0")
    return h.hexdigest()[:12]


def extension_files(folder: Path = EXTENSION_DIR) -> list[str]:
    """The files the build covers, as paths relative to the folder."""
    rels = (p.relative_to(folder).as_posix() for p in folder.rglob("*") if p.is_file())
    return [rel for rel in rels if not rel.endswith(".test.mjs")]


def checkout_root(package_dir: Path = PACKAGE_DIR) -> Path | None:
    """The source checkout this code runs from, or None for an installed copy.

    A checkout has pyproject.toml beside the package; site-packages never does.
    """
    root = package_dir.parent
    return root if (root / "pyproject.toml").exists() else None


def installed_commit(path: Path = COMMIT_FILE) -> str | None:
    """The commit this copy was installed from, or None when it cannot know.

    Only an install from a GitHub archive knows: a checkout, or pip building from
    one (`git+`), keeps the placeholder.
    """
    try:
        sha = path.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return sha if re.fullmatch(r"[0-9a-f]{40}", sha) else None


def build_info(path: Path = BUILD_FILE) -> dict | None:
    """This release's `{"version", "commit", "count"}`, or None for a checkout
    or an install from the old main.zip. `count` is the commit's place on main
    (`git rev-list --count`), so two releases subtract to the changes between."""
    try:
        info = json.loads(path.read_text(encoding="utf-8"))
        return info if isinstance(info.get("count"), int) else None
    except (OSError, ValueError, AttributeError):
        return None


def install_version() -> str:
    """What `pnt --version` prints: a release's version, or where else this runs from.

    `0.1.0.7` for a release, `source checkout at 1a2b3c4` for a checkout (the
    extension repo has no release build, so this is what it shows), and for an
    install from the old main.zip the package's own version and its commit.
    """
    build = build_info()
    if build is not None and isinstance(build.get("version"), str):
        return build["version"]
    root = checkout_root()
    if root is not None:
        try:
            head = subprocess.run(
                ["git", "-C", str(root), "rev-parse", "--short", "HEAD"],
                capture_output=True, text=True, timeout=5, check=False,
            )  # fmt: skip
        except (OSError, subprocess.SubprocessError):
            head = None
        sha = head.stdout.strip() if head is not None and head.returncode == 0 else ""
        return f"source checkout at {sha}" if sha else "source checkout"
    try:
        version = importlib.metadata.version(DIST)
    except importlib.metadata.PackageNotFoundError:
        version = "unknown"
    commit = installed_commit()
    return f"{version} (main.zip at {commit[:7]})" if commit else version


def _get_json(url: str, timeout: float = 5) -> dict:
    # GitHub Pages' CDN keeps a copy for up to 10 minutes and ignores both the
    # query string and a no-cache header, so this can read a copy that old. The
    # `?t=` is harmless and kept for a host that does honour it; release.py does
    # not rely on it (it reads the gh-pages branch, see previous_wheels).
    fresh = f"{url}{'&' if '?' in url else '?'}t={int(time.time())}"
    req = urllib.request.Request(fresh, headers={"User-Agent": "pnt", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def _read_latest(fetch: Callable[[str], dict]) -> dict:
    """The download site's `latest.json`, or an UpdateError saying why not."""
    try:
        latest = fetch(LATEST_URL)
    # Offline, timed out or an HTTP error (all OSError) is the connection or the site.
    except OSError as exc:
        raise UpdateError(f"could not read {LATEST_URL} ({exc}); check your connection and try again") from exc
    # Not JSON: the site answered, with something release.py does not write.
    except ValueError as exc:
        raise UpdateError(f"the release info at {LATEST_URL} is malformed (not JSON); try again in 10 minutes") from exc
    if not (
        isinstance(latest, dict)
        and isinstance(latest.get("count"), int)
        and isinstance(latest.get("wheel"), str)
        and isinstance(latest.get("commit"), str)
        and isinstance(latest.get("version"), str)
    ):
        raise UpdateError(f"the release info at {LATEST_URL} is malformed; try again in 10 minutes")
    return latest


def latest_release(*, fetch: Callable[[str], dict] = _get_json) -> dict | None:
    """The download site's `latest.json`, or None when it cannot be read
    (offline, timed out, not the shape release.py writes)."""
    try:
        return _read_latest(fetch)
    except UpdateError:
        return None


def changes_behind(latest: dict | None, build: dict | None, commit: str | None) -> int | None:
    """How many commits on main this install lacks: 0 when it has them all, None
    when it cannot say.

    An install from the old main.zip knows only its commit (`commit`), not its
    place on main, so it is 1 behind whenever that is not the latest: enough to
    show the banner that moves it onto releases.
    """
    if latest is None:
        return None
    if build is not None:
        return max(0, latest["count"] - build["count"])
    if commit is not None:
        return 0 if commit == latest["commit"] else 1
    return None


def newest(*, fetch: Callable[[str], dict] = _get_json) -> dict:
    """`latest_release`, for `pnt update`: there, unreadable is an error that says
    whether it was the connection or the file."""
    return _read_latest(fetch)


def wheel_url(latest: dict) -> str:
    """The URL of the wheel `latest.json` names, for `pnt update` to install."""
    return urllib.parse.urljoin(LATEST_URL, latest["wheel"])


def check_wheel(url: str, *, urlopen: Callable = urllib.request.urlopen) -> None:
    """Raise an UpdateError unless the wheel at `url` can be downloaded.

    A 404 is a release going out: the site's cache can still serve a latest.json
    naming a wheel the new deploy has dropped (release.py keeps three). Asked
    before the server stops, so pip never meets it.
    """
    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "pnt"})
    try:
        with urlopen(req, timeout=30):
            pass
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise UpdateError(
                f"{url.rsplit('/', 1)[-1]} is not on the download site yet: a release is going out."
                " Try again in 10 minutes."
            ) from exc
        raise UpdateError(f"could not download {url} ({exc}); try again later") from exc
    except OSError as exc:
        raise UpdateError(f"could not download {url} ({exc}); check your connection and try again") from exc


def service_interpreter() -> Path | None:
    """The interpreter the background server (`pnt service`) runs, or None when
    there is none or it cannot be read.

    The task name and the launch agent's label are the same for every install on
    the machine, so this is how `pnt update` tells its own service from another
    install's (a developer's checkout, a wheel being tried out).
    """
    from . import service as svc

    if sys.platform == "darwin":
        try:
            program = plistlib.loads(svc.AGENT_PLIST.read_bytes())["ProgramArguments"]
            return Path(program[0])
        except (OSError, ValueError, KeyError, IndexError, TypeError):
            return None
    if sys.platform != "win32":
        return None
    quoted = svc.TASK_NAME.replace("'", "''")
    try:
        result = subprocess.run(
            [
                "powershell", "-NoProfile", "-NonInteractive", "-Command",
                f"(Get-ScheduledTask -TaskName '{quoted}' -ErrorAction SilentlyContinue).Actions[0].Execute",
            ],
            capture_output=True, text=True, errors="replace", timeout=30, check=False,
        )  # fmt: skip
    except (OSError, subprocess.SubprocessError):
        return None
    command = (result.stdout or "").strip().strip('"')
    return Path(command) if command else None


def runs_this_install(interpreter: Path | None, executable: str | None = None) -> bool:
    """Whether a service running `interpreter` runs this install's code.

    The task names `-m pnt.cli`, so its environment decides which code runs:
    the same folder as this interpreter's, whether `python` or `pythonw`.
    Not resolved: a venv's interpreter can be a link to the base Python, which
    every venv on the machine shares.
    """
    if interpreter is None:
        return False

    def env(path: str) -> str:
        return os.path.normcase(os.path.abspath(os.path.dirname(path)))

    return env(str(interpreter)) == env(executable or sys.executable)


def requirements(dist: str = DIST) -> list[str]:
    """The installed package's runtime dependencies, read fresh from disk."""
    importlib.invalidate_caches()
    reqs = importlib.metadata.requires(dist) or []
    return [r for r in reqs if "extra ==" not in r]


def pip(*args: str) -> None:
    """Run pip in this environment, its output going straight to the terminal."""
    result = subprocess.run([sys.executable, "-m", "pip", *args], check=False)
    if result.returncode != 0:
        raise UpdateError(f"pip failed (exit code {result.returncode}); see its output above")


def install(source: str, *, pip: Callable[..., None] = pip) -> None:
    """Replace the package from `source`, then add any dependency it newly needs.

    On Windows pip warns that it could not remove a temporary directory: the old
    `pnt.exe`, which is running this, can be moved aside but not deleted. Harmless.

    Two steps so the dependencies are not reinstalled too: `--force-reinstall`
    would apply to all of them, a dozen downloads for what is usually a change to
    this package alone. The second step only installs what is missing.
    """
    pip("install", "--quiet", "--force-reinstall", "--no-deps", "--no-cache-dir", source)
    reqs = requirements()
    if reqs:
        pip("install", "--quiet", *reqs)
